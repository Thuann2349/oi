"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowLeft, RefreshCw, Trash2, Globe2, Users, Smartphone, Monitor,
  ExternalLink, Clock3, ShieldCheck, Copy, Check, PanelTop,
} from "lucide-react";

type Visit = {
  id: number;
  visitorId: string;
  ipAddress: string;
  path: string;
  appMode: string;
  deviceName: string;
  deviceType: string;
  browserName: string;
  browserVersion: string;
  osName: string;
  osVersion: string;
  consentedAt: string;
  createdAt: string;
};

type Analytics = {
  rangeDays: number;
  page: number;
  pageSize: number;
  total: number;
  pages: number;
  uniqueVisitors: number;
  uniqueIps: number;
  appVisits: number;
  siteVisits: number;
  browsers: Array<{ name: string; value: number }>;
  devices: Array<{ name: string; value: number }>;
  visits: Visit[];
  retentionDays: number;
};

function formatDate(value: string) {
  return new Date(value).toLocaleString("pt-BR", {
    day: "2-digit", month: "2-digit", year: "numeric",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
  });
}

function initials(name: string) {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((s) => s[0]).join("").toUpperCase();
}

export default function AdminVisitsPanel() {
  const router = useRouter();
  const [days, setDays] = useState(7);
  const [page, setPage] = useState(1);
  const [data, setData] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [message, setMessage] = useState("");
  const [copied, setCopied] = useState<number | null>(null);

  const load = useCallback(async (quiet = false) => {
    if (!quiet) setLoading(true);
    try {
      const r = await fetch(`/api/admin/visits?days=${days}&page=${page}`, { cache: "no-store" });
      if (r.status === 401) { router.push("/admin/login"); return; }
      if (!r.ok) throw new Error("Não foi possível carregar os acessos.");
      setData(await r.json());
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Erro ao carregar.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [days, page, router]);

  useEffect(() => { void load(); }, [load]);
  useEffect(() => {
    const t = setInterval(() => void load(true), 30000);
    return () => clearInterval(t);
  }, [load]);

  const deleteAll = async () => {
    const ok = window.confirm("Apagar permanentemente todos os registros de acesso consentidos? Esta ação não pode ser desfeita.");
    if (!ok) return;
    setRefreshing(true);
    try {
      const r = await fetch("/api/admin/visits", { method: "DELETE" });
      if (r.status === 401) { router.push("/admin/login"); return; }
      const d = await r.json();
      setMessage(`${d.deleted ?? 0} registros apagados.`);
      setPage(1);
      await load(true);
    } catch {
      setMessage("Falha ao apagar o histórico.");
      setRefreshing(false);
    }
  };

  const copyIp = async (ip: string, id: number) => {
    try {
      await navigator.clipboard.writeText(ip);
      setCopied(id);
      setTimeout(() => setCopied(null), 1400);
    } catch { setMessage("Não foi possível copiar o IP."); }
  };

  const maxBrowser = Math.max(1, ...(data?.browsers.map((b) => b.value) ?? []));
  const maxDevice = Math.max(1, ...(data?.devices.map((d) => d.value) ?? []));

  return (
    <div className="mx-auto max-w-[1500px] px-4 py-6 sm:px-6">
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <Link href="/admin" className="flex h-10 w-10 items-center justify-center rounded-lg bg-zinc-800 text-zinc-200 hover:bg-zinc-700" aria-label="Voltar ao painel">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <div className="mr-auto">
          <h1 className="text-2xl font-black tracking-tight">Acessos consentidos</h1>
          <p className="text-sm text-zinc-400">IP, tipo de aparelho, navegador e páginas — somente visitantes que permitiram analytics.</p>
        </div>
        <Link href="/privacidade" className="rounded-md bg-zinc-800 px-3 py-2 text-xs font-bold text-zinc-200 hover:bg-zinc-700">
          Política de privacidade
        </Link>
        <button
          onClick={() => { setRefreshing(true); void load(); }}
          disabled={refreshing || loading}
          className="flex items-center gap-2 rounded-md bg-zinc-800 px-3 py-2 text-xs font-bold text-zinc-200 hover:bg-zinc-700 disabled:opacity-50"
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`} /> Atualizar
        </button>
        <button
          onClick={deleteAll}
          disabled={!data?.total || refreshing}
          className="flex items-center gap-2 rounded-md bg-red-950 px-3 py-2 text-xs font-bold text-red-300 hover:bg-red-900 disabled:opacity-50"
        >
          <Trash2 className="h-4 w-4" /> Apagar histórico
        </button>
      </div>

      <div className="mb-4 flex flex-wrap items-center gap-3 rounded-xl border border-amber-900/50 bg-amber-950/20 px-4 py-3 text-xs text-amber-100/80">
        <ShieldCheck className="h-5 w-5 shrink-0 text-amber-400" />
        <p className="flex-1 leading-relaxed">
          <strong className="text-amber-200">Dados pessoais — acesso restrito.</strong> O IP é o endereço observado pelo proxy e pode representar uma rede compartilhada, não uma pessoa específica. Só registramos
          depois do consentimento, não guardamos o user-agent bruto e apagamos automaticamente após {data?.retentionDays ?? 30} dias.
          “Nome do aparelho” é uma estimativa do modelo/tipo que o navegador informa; o nome pessoal do dispositivo não é acessível ao site.
        </p>
        <label className="flex shrink-0 items-center gap-2 font-bold text-zinc-200">
          Período
          <select
            value={days}
            onChange={(e) => { setDays(Number(e.target.value)); setPage(1); }}
            className="rounded border border-zinc-700 bg-zinc-950 px-2 py-1.5 text-xs text-white outline-none"
          >
            <option value={1}>24 horas</option>
            <option value={7}>7 dias</option>
            <option value={30}>30 dias</option>
          </select>
        </label>
      </div>

      {message && (
        <div className="mb-4 flex items-center justify-between rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-zinc-200">
          {message}<button onClick={() => setMessage("")} className="px-2 text-zinc-500 hover:text-white" aria-label="Fechar mensagem">×</button>
        </div>
      )}

      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-5">
        {[
          { label: "Acessos registrados", value: data?.total ?? "—", icon: Globe2, color: "text-cyan-400" },
          { label: "Navegadores únicos*", value: data?.uniqueVisitors ?? "—", icon: Users, color: "text-emerald-400" },
          { label: "IPs distintos", value: data?.uniqueIps ?? "—", icon: ShieldCheck, color: "text-amber-400" },
          { label: "Modo app instalado", value: data?.appVisits ?? "—", icon: Smartphone, color: "text-violet-400" },
          { label: "Modo site", value: data?.siteVisits ?? "—", icon: PanelTop, color: "text-sky-400" },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
            <Icon className={`h-5 w-5 ${color}`} />
            <p className="mt-2 text-2xl font-black tabular-nums">{value}</p>
            <p className="text-[11px] font-bold uppercase tracking-wide text-zinc-500">{label}</p>
          </div>
        ))}
      </div>

      <div className="mb-4 grid gap-4 lg:grid-cols-2">
        <section className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
          <h2 className="text-xs font-black uppercase tracking-wider text-zinc-300">Navegadores mais usados</h2>
          <div className="mt-3 flex flex-col gap-2.5">
            {(data?.browsers ?? []).map((b) => (
              <div key={b.name}>
                <div className="flex justify-between text-xs"><span>{b.name}</span><strong className="tabular-nums">{b.value}</strong></div>
                <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-zinc-800"><div className="h-full rounded-full bg-cyan-400" style={{ width: `${(b.value / maxBrowser) * 100}%` }} /></div>
              </div>
            ))}
            {!loading && !data?.browsers.length && <p className="text-xs text-zinc-500">Sem dados no período.</p>}
          </div>
        </section>
        <section className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
          <h2 className="text-xs font-black uppercase tracking-wider text-zinc-300">Tipos de aparelho</h2>
          <div className="mt-3 flex flex-col gap-2.5">
            {(data?.devices ?? []).map((d) => (
              <div key={d.name}>
                <div className="flex justify-between text-xs"><span className="flex items-center gap-2">{d.name === "Computador" ? <Monitor className="h-3.5 w-3.5" /> : <Smartphone className="h-3.5 w-3.5" />}{d.name}</span><strong className="tabular-nums">{d.value}</strong></div>
                <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-zinc-800"><div className="h-full rounded-full bg-violet-400" style={{ width: `${(d.value / maxDevice) * 100}%` }} /></div>
              </div>
            ))}
            {!loading && !data?.devices.length && <p className="text-xs text-zinc-500">Sem dados no período.</p>}
          </div>
        </section>
      </div>

      <section className="overflow-hidden rounded-xl border border-zinc-800">
        <div className="flex items-center justify-between border-b border-zinc-800 bg-zinc-900/70 px-4 py-3">
          <h2 className="text-sm font-black uppercase tracking-wide">Últimos acessos</h2>
          <span className="text-xs text-zinc-500">{data?.total ?? 0} registro(s) no período</span>
        </div>
        <div className="nice-scroll overflow-x-auto">
          <table className="w-full min-w-[1000px] text-left text-xs">
            <thead className="bg-zinc-950 text-[10px] uppercase tracking-wide text-zinc-500">
              <tr>
                <th className="px-3 py-3">Entrada</th><th className="px-3 py-3">IP</th><th className="px-3 py-3">Dispositivo</th>
                <th className="px-3 py-3">Navegador</th><th className="px-3 py-3">Sistema</th><th className="px-3 py-3">Modo</th><th className="px-3 py-3">Página</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800 bg-zinc-950/60">
              {(data?.visits ?? []).map((v) => (
                <tr key={v.id} className="hover:bg-zinc-900/70">
                  <td className="whitespace-nowrap px-3 py-3 text-zinc-300"><span className="flex items-center gap-1.5"><Clock3 className="h-3.5 w-3.5 text-zinc-500" />{formatDate(v.createdAt)}</span></td>
                  <td className="whitespace-nowrap px-3 py-3">
                    <button onClick={() => void copyIp(v.ipAddress, v.id)} className="flex items-center gap-1.5 rounded bg-zinc-900 px-2 py-1 font-mono font-bold text-amber-300 hover:bg-zinc-800" title="Copiar IP">
                      {v.ipAddress}{copied === v.id ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3 text-zinc-500" />}
                    </button>
                  </td>
                  <td className="px-3 py-3"><span className="font-bold text-zinc-200">{v.deviceName}</span><span className="ml-1.5 text-zinc-500">({v.deviceType})</span></td>
                  <td className="px-3 py-3 text-zinc-300">{v.browserName}{v.browserVersion ? ` ${v.browserVersion.split(".")[0]}` : ""}</td>
                  <td className="px-3 py-3 text-zinc-400">{v.osName}{v.osVersion ? ` ${v.osVersion}` : ""}</td>
                  <td className="px-3 py-3"><span className={`rounded-full px-2 py-1 text-[10px] font-black uppercase ${v.appMode === "app" ? "bg-violet-500/15 text-violet-300" : "bg-sky-500/15 text-sky-300"}`}>{v.appMode === "app" ? "App" : "Site"}</span></td>
                  <td className="max-w-[220px] px-3 py-3"><Link href={v.path} className="flex items-center gap-1 truncate text-cyan-300 hover:underline" title={v.path}>{v.path}<ExternalLink className="h-3 w-3 shrink-0" /></Link></td>
                </tr>
              ))}
              {!loading && !data?.visits.length && (
                <tr><td colSpan={7} className="px-4 py-12 text-center text-zinc-500">Nenhum acesso consentido no período. O visitante precisa aceitar analytics no banner de privacidade.</td></tr>
              )}
              {loading && <tr><td colSpan={7} className="px-4 py-12 text-center text-zinc-500">Carregando acessos…</td></tr>}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between border-t border-zinc-800 bg-zinc-900/50 px-4 py-3">
          <p className="text-[11px] text-zinc-500">* Identificador anônimo guardado apenas no navegador, não é nome nem conta pessoal.</p>
          <div className="flex items-center gap-2">
            <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1 || loading} className="rounded bg-zinc-800 px-3 py-1.5 text-xs font-bold disabled:opacity-40">Anterior</button>
            <span className="text-xs tabular-nums text-zinc-400">{page} / {data?.pages ?? 1}</span>
            <button onClick={() => setPage((p) => Math.min(data?.pages ?? p, p + 1))} disabled={page >= (data?.pages ?? 1) || loading} className="rounded bg-zinc-800 px-3 py-1.5 text-xs font-bold disabled:opacity-40">Próxima</button>
          </div>
        </div>
      </section>
    </div>
  );
}
