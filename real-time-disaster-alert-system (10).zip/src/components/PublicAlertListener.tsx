"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Siren, MapPin, X, ShieldAlert, CheckCircle2, Megaphone } from "lucide-react";
import { severityMeta, typeLabel, haversineKm } from "@/lib/meta";
import type { AlertRow } from "@/db/schema";

export type AreaPref = {
  name: string;
  state?: string;
  latitude: number;
  longitude: number;
  radiusKm: number;
  minSeverity: number;
  types: string[];
};

export const AREAS_KEY = "vigia:areas:v1";

export function readAreas(): AreaPref[] {
  try {
    const raw = localStorage.getItem(AREAS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

/** A região da pessoa confere com o alerta? Decisão 100% local, no aparelho dela. */
function matchesArea(alert: AlertRow, areas: AreaPref[]): boolean {
  return areas.some((area) => {
    if (alert.severity < area.minSeverity) return false;
    if (area.types.length > 0 && !area.types.includes(alert.type)) return false;
    const dist = haversineKm(area.latitude, area.longitude, alert.latitude, alert.longitude);
    return dist <= area.radiusKm;
  });
}

const SAFETY_TIPS: Record<string, string[]> = {
  enchente: ["Saia imediatamente de áreas ribeirinhas e baixadas", "Nunca atravesse ruas ou pontes alagadas", "Se a água entrar em casa, desligue a energia e suba para o ponto mais alto"],
  tempestade: ["Abrigue-se em construção sólida, longe de janelas", "Não fique sob árvores, postes ou estruturas metálicas", "Evite sair de carro durante rajadas e granizo"],
  terremoto: ["Proteja a cabeça e abrigue-se sob mesa resistente", "Fique longe de vidros, estantes e objetos que possam cair", "Após o tremor, saia com calma e não use elevadores"],
  tsunami: ["Corra imediatamente para áreas altas, longe da costa", "Não retorne antes do sinal oficial de liberação", "Se o mar recuar de forma estranha, afaste-se na hora"],
  incendio: ["Afaste-se na direção contrária ao vento e à fumaça", "Cubra nariz e boca com pano úmido", "Feche portas e janelas se a fumaça se aproximar de casa"],
  deslizamento: ["Saia de casa ao notar rachaduras, água barrenta ou estalos", "Não atravesse áreas com terra ou pedras em movimento", "Avise vizinhos e autoridades locais"],
  vulcao: ["Use máscara contra cinzas e proteja os olhos", "Fique em ambientes fechados durante a queda de cinzas", "Siga as rotas oficiais de evacuação"],
  ciclone: ["Reforce portas e janelas e guarde objetos soltos", "Evite áreas costeiras e margens de rios", "Tenha água, lanterna e documentos à mão"],
};

type PublicPayload = { alert: AlertRow; reached?: number; dispatchMs?: number };

export default function PublicAlertListener() {
  const [current, setCurrent] = useState<PublicPayload | null>(null);
  const [banner, setBanner] = useState<PublicPayload | null>(null);
  const queueRef = useRef<PublicPayload[]>([]);
  const audioRef = useRef<AudioContext | null>(null);
  const bannerTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const siren = () => {
      try {
        audioRef.current ??= new AudioContext();
        const ctx = audioRef.current;
        if (ctx.state !== "running") return;
        [0, 0.3, 0.6].forEach((off) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "square";
          osc.frequency.setValueAtTime(720, ctx.currentTime + off);
          osc.frequency.linearRampToValueAtTime(980, ctx.currentTime + off + 0.25);
          gain.gain.setValueAtTime(0.0001, ctx.currentTime + off);
          gain.gain.exponentialRampToValueAtTime(0.06, ctx.currentTime + off + 0.03);
          gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + off + 0.28);
          osc.connect(gain).connect(ctx.destination);
          osc.start(ctx.currentTime + off);
          osc.stop(ctx.currentTime + off + 0.3);
        });
      } catch { /* áudio indisponível */ }
    };

    const es = new EventSource("/api/stream");
    const reportStatus = (connected: boolean) => {
      (window as unknown as { __vigiaConnected?: boolean }).__vigiaConnected = connected;
      window.dispatchEvent(new CustomEvent("vigia:status", { detail: { connected } }));
    };
    es.onopen = () => reportStatus(true);
    es.onerror = () => reportStatus(false);
    es.onmessage = (msg) => {
      try {
        const event = JSON.parse(msg.data) as { kind: string; data: PublicPayload };
        // Compartilha o canal com o restante da interface (1 conexão por aba).
        window.dispatchEvent(new CustomEvent("vigia:stream", { detail: event }));
        if (event.kind !== "public-alert") return;
        const payload = event.data;

        // Privacidade total: a decisão é tomada aqui, no aparelho da pessoa.
        // A região protegida nunca sai deste navegador.
        const areas = readAreas();
        const forMe = areas.length === 0 || matchesArea(payload.alert, areas);
        const inAdmin = window.location.pathname.startsWith("/admin");

        if (forMe && !inAdmin) {
          setCurrent((cur) => {
            if (cur) {
              queueRef.current.push(payload);
              return cur;
            }
            return payload;
          });
          siren();
          if (typeof Notification !== "undefined" && Notification.permission === "granted") {
            new Notification("ALERTA PÚBLICO VIGIA", { body: payload.alert.title });
          }
        } else {
          // Fora da região da pessoa: aviso discreto, sem interromper.
          setBanner(payload);
          if (bannerTimer.current) clearTimeout(bannerTimer.current);
          bannerTimer.current = setTimeout(() => setBanner(null), 20000);
        }
      } catch { /* heartbeat */ }
    };
    return () => es.close();
  }, []);

  const dismiss = () => {
    const next = queueRef.current.shift() ?? null;
    setCurrent(next);
  };

  const bannerAlert = banner?.alert;
  const bannerSev = bannerAlert ? severityMeta(bannerAlert.severity) : null;

  return (
    <>
      {/* aviso discreto: alerta fora da sua região */}
      {banner && bannerAlert && bannerSev && !current && (
        <div
          className="toast-enter fixed right-4 top-20 z-[250] flex w-[min(380px,90vw)] gap-3 rounded-xl border bg-zinc-900 p-3.5 shadow-2xl"
          style={{ borderColor: bannerSev.color }}
        >
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg" style={{ background: `${bannerSev.color}22`, color: bannerSev.color }}>
            <Megaphone className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] font-black uppercase tracking-wider" style={{ color: bannerSev.color }}>
              Alerta público fora da sua região
            </p>
            <p className="mt-0.5 truncate text-sm font-semibold" title={bannerAlert.title}>{bannerAlert.title}</p>
            <p className="text-xs text-zinc-500">{bannerAlert.locationName}</p>
          </div>
          <button onClick={() => setBanner(null)} className="self-start rounded p-1 text-zinc-500 hover:bg-zinc-800 hover:text-white" aria-label="Fechar aviso">
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* modal de emergência: alerta na sua região (ou sem região definida) */}
      {current && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center bg-zinc-950/85 p-4 backdrop-blur-sm">
          <div
            className="toast-enter w-full max-w-lg overflow-hidden rounded-2xl border-2 bg-zinc-900 shadow-2xl"
            style={{ borderColor: severityMeta(current.alert.severity).color, boxShadow: `0 0 60px ${severityMeta(current.alert.severity).color}55` }}
          >
            <div className="flex items-center gap-3 px-5 py-4" style={{ background: `${severityMeta(current.alert.severity).color}26` }}>
              <span className="relative flex h-12 w-12 shrink-0 items-center justify-center rounded-full text-white" style={{ background: severityMeta(current.alert.severity).color }}>
                <Siren className="h-7 w-7 animate-pulse" />
              </span>
              <div className="min-w-0">
                <p className="text-[11px] font-black uppercase tracking-widest" style={{ color: severityMeta(current.alert.severity).color }}>
                  Alerta público • {typeLabel(current.alert.type)} • Severidade {severityMeta(current.alert.severity).label}
                </p>
                <p className="flex items-center gap-1.5 text-xs text-zinc-400">
                  <MapPin className="h-3.5 w-3.5" /> {current.alert.locationName || "Área de risco"}
                </p>
              </div>
              <button onClick={dismiss} className="ml-auto rounded p-1 text-zinc-400 hover:bg-zinc-800 hover:text-white" aria-label="Fechar alerta">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="px-5 py-4">
              <h2 className="text-xl font-black leading-snug">{current.alert.title}</h2>
              <p className="mt-2 text-sm leading-relaxed text-zinc-300">{current.alert.description}</p>

              <div className="mt-4 rounded-lg border border-zinc-700 bg-zinc-950 p-3">
                <p className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-zinc-300">
                  <ShieldAlert className="h-4 w-4 text-yellow-400" /> O que fazer agora
                </p>
                <ul className="mt-2 space-y-1.5">
                  {(SAFETY_TIPS[current.alert.type] ?? SAFETY_TIPS.tempestade).map((tip) => (
                    <li key={tip} className="flex gap-2 text-sm text-zinc-300">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" /> {tip}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  onClick={dismiss}
                  className="flex-1 rounded-md px-4 py-3 text-sm font-black uppercase tracking-wide text-white"
                  style={{ background: severityMeta(current.alert.severity).color }}
                >
                  Entendido, vou me proteger
                </button>
                <Link
                  href="/"
                  onClick={dismiss}
                  className="rounded-md bg-zinc-800 px-4 py-3 text-sm font-bold text-zinc-100 hover:bg-zinc-700"
                >
                  Ver no mapa
                </Link>
              </div>

              <p className="mt-3 text-center text-[11px] leading-snug text-zinc-500">
                Você recebeu este alerta <strong className="text-zinc-300">sem cadastro e sem informar nenhum dado pessoal</strong>.
                {typeof current.dispatchMs === "number" && current.dispatchMs > 0 && (
                  <> Disparo concluído em <strong className="text-emerald-400">{current.dispatchMs} ms</strong>.</>
                )}{" "}
                Emergência real: ligue 193 / 199.
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
