import { Sun, CloudSun, Cloud, CloudFog, CloudLightning, Snowflake, CloudRain } from "lucide-react";
import { WMO } from "@/lib/weather";

export function codeLabel(code: number | null | undefined): string {
  if (code == null) return "—";
  return WMO[code] ?? "—";
}

export function CodeIcon({ code, className }: { code: number | null | undefined; className?: string }) {
  const cls = className ?? "h-6 w-6";
  if (code == null) return <Cloud className={cls} />;
  if (code === 0) return <Sun className={cls} />;
  if (code <= 2) return <CloudSun className={cls} />;
  if (code === 3) return <Cloud className={cls} />;
  if (code === 45 || code === 48) return <CloudFog className={cls} />;
  if (code >= 95) return <CloudLightning className={cls} />;
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return <Snowflake className={cls} />;
  if (code >= 51) return <CloudRain className={cls} />;
  return <Cloud className={cls} />;
}
