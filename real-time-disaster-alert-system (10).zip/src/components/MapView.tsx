"use client";

import { useEffect, useRef, useState } from "react";
import "leaflet/dist/leaflet.css";
import type { Map as LeafletMap, TileLayer, LayerGroup, Marker } from "leaflet";
import { Play, Pause, Layers } from "lucide-react";
import { severityMeta } from "@/lib/meta";
import { escapeHtml } from "@/lib/security";
import type { AlertRow } from "@/db/schema";

type RadarFrame = { time: number; path: string };
type WindGrid = { west: number; east: number; south: number; north: number; cols: number; rows: number; u: number[]; v: number[] };

type Props = {
  alerts: AlertRow[];
  selectedId: number | null;
  onSelect: (alert: AlertRow) => void;
  onMapClick: (lat: number, lon: number) => void;
};

const BASE_LAYERS = {
  satellite: {
    label: "Satélite",
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    attribution: "Tiles &copy; Esri, Maxar, Earthstar Geographics",
    maxZoom: 19,
  },
  streets: {
    label: "Ruas detalhadas",
    url: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    maxZoom: 19,
  },
  terrain: {
    label: "Terreno / relevo",
    url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
    attribution: "&copy; OpenTopoMap (CC-BY-SA)",
    maxZoom: 17,
  },
  dark: {
    label: "Escuro (noturno)",
    url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
    attribution: "&copy; OSM &copy; CARTO",
    maxZoom: 19,
  },
} as const;

type BaseKey = keyof typeof BASE_LAYERS;

function windColor(speedKmh: number): string {
  if (speedKmh < 10) return "#38bdf8";
  if (speedKmh < 25) return "#34d399";
  if (speedKmh < 40) return "#facc15";
  if (speedKmh < 60) return "#fb923c";
  return "#ef4444";
}

export default function MapView({ alerts, selectedId, onSelect, onMapClick }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const baseLayerRef = useRef<TileLayer | null>(null);
  const markersRef = useRef<LayerGroup | null>(null);
  const radarRef = useRef<TileLayer | null>(null);
  const satelliteRef = useRef<TileLayer | null>(null);
  const clickMarkerRef = useRef<Marker | null>(null);
  const leafletRef = useRef<typeof import("leaflet") | null>(null);
  const windCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const windGridRef = useRef<WindGrid | null>(null);
  const callbacksRef = useRef({ onSelect, onMapClick });
  callbacksRef.current = { onSelect, onMapClick };

  const [ready, setReady] = useState(false);
  const [baseKey, setBaseKey] = useState<BaseKey>("dark");
  const [radarOn, setRadarOn] = useState(true);
  const [satelliteOn, setSatelliteOn] = useState(false);
  const [windOn, setWindOn] = useState(false);
  const [frames, setFrames] = useState<RadarFrame[]>([]);
  const [satFrames, setSatFrames] = useState<RadarFrame[]>([]);
  const [frameIdx, setFrameIdx] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [panelOpen, setPanelOpen] = useState(true);

  /* ------------------------- inicializa o mapa ------------------------- */
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const L = (await import("leaflet")).default;
      if (cancelled || !containerRef.current || mapRef.current) return;
      leafletRef.current = L;
      const map = L.map(containerRef.current, {
        center: [-14, -52],
        zoom: 4,
        minZoom: 2,
        maxZoom: 18,
        worldCopyJump: true,
        zoomControl: false,
        preferCanvas: true,
        zoomAnimation: true,
        fadeAnimation: true,
        wheelDebounceTime: 40,
      });
      L.control.zoom({ position: "bottomright" }).addTo(map);
      L.control.scale({ position: "bottomleft", imperial: false }).addTo(map);
      markersRef.current = L.layerGroup().addTo(map);

      const canvas = document.createElement("canvas");
      canvas.style.cssText = "position:absolute;top:0;left:0;z-index:450;pointer-events:none;";
      map.getContainer().appendChild(canvas);
      windCanvasRef.current = canvas;
      const fitCanvas = () => {
        const el = map.getContainer();
        canvas.width = el.clientWidth;
        canvas.height = el.clientHeight;
      };
      fitCanvas();
      map.on("resize", fitCanvas);

      map.on("click", (e: { latlng: { lat: number; lng: number } }) => {
        if (clickMarkerRef.current) clickMarkerRef.current.remove();
        clickMarkerRef.current = L.marker(e.latlng, {
          icon: L.divIcon({
            className: "",
            html: `<div style="width:14px;height:14px;border-radius:9999px;background:#22d3ee;border:2px solid #fff;box-shadow:0 0 10px #22d3ee"></div>`,
            iconSize: [14, 14],
            iconAnchor: [7, 7],
          }),
        }).addTo(map);
        callbacksRef.current.onMapClick(e.latlng.lat, e.latlng.lng);
      });
      mapRef.current = map;
      setReady(true);
    })();
    return () => { cancelled = true; };
  }, []);

  /* ----------------------------- mapa base ----------------------------- */
  useEffect(() => {
    const L = leafletRef.current, map = mapRef.current;
    if (!L || !map || !ready) return;
    const cfg = BASE_LAYERS[baseKey];
    if (baseLayerRef.current) baseLayerRef.current.remove();
    baseLayerRef.current = L.tileLayer(cfg.url, {
      attribution: cfg.attribution,
      maxZoom: cfg.maxZoom,
      zIndex: 1,
      updateWhenIdle: false,
      keepBuffer: 4,
    }).addTo(map);
  }, [baseKey, ready]);

  /* -------------------------- frames de radar -------------------------- */
  useEffect(() => {
    const load = () =>
      fetch("/api/radar")
        .then((r) => r.json())
        .then((d) => {
          const all = [...(d.radarPast ?? []), ...(d.radarNowcast ?? [])];
          setFrames(all);
          setFrameIdx((prev) => (prev === 0 ? Math.max(0, (d.radarPast?.length ?? 1) - 1) : prev));
          setSatFrames(d.satellite ?? []);
        })
        .catch(() => {});
    load();
    const t = setInterval(load, 5 * 60 * 1000);
    return () => clearInterval(t);
  }, []);

  /* --------------- radar com crossfade + pré-carregamento --------------- */
  useEffect(() => {
    const L = leafletRef.current, map = mapRef.current;
    if (!L || !map || !ready) return;

    const frameUrl = (f: RadarFrame) => `https://tilecache.rainviewer.com${f.path}/256/{z}/{x}/{y}/2/1_1.png`;

    // Pré-carrega os tiles do PRÓXIMO frame na viewport atual → troca instantânea, sem piscar
    const preload = (f: RadarFrame) => {
      try {
        const z = map.getZoom();
        if (z > 9) return;
        const b = map.getBounds();
        const n = 2 ** z;
        const lon2x = (lon: number) => Math.floor(((lon + 180) / 360) * n);
        const lat2y = (lat: number) => {
          const rad = (lat * Math.PI) / 180;
          return Math.floor(((1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2) * n);
        };
        const x0 = Math.max(0, lon2x(b.getWest())), x1 = Math.min(n - 1, lon2x(b.getEast()));
        const y0 = Math.max(0, lat2y(b.getNorth())), y1 = Math.min(n - 1, lat2y(b.getSouth()));
        if ((x1 - x0 + 1) * (y1 - y0 + 1) > 30) return;
        for (let x = x0; x <= x1; x++) {
          for (let y = y0; y <= y1; y++) {
            const img = new Image();
            img.src = `https://tilecache.rainviewer.com${f.path}/256/${z}/${x}/${y}/2/1_1.png`;
          }
        }
      } catch { /* pré-carregamento é opcional */ }
    };

    if (radarOn && frames.length) {
      const idx = Math.min(frameIdx, frames.length - 1);
      const next = frames[idx];
      preload(frames[(idx + 1) % frames.length]);

      const url = frameUrl(next);
      if (!radarRef.current) {
        radarRef.current = L.tileLayer(url, { opacity: 0.62, zIndex: 5, updateWhenIdle: false, keepBuffer: 2 }).addTo(map);
      } else if ((radarRef.current as unknown as { _url: string })._url !== url) {
        // Crossfade: nova camada surge sobre a antiga, que sai sem deixar buraco
        const old = radarRef.current;
        const fresh = L.tileLayer(url, { opacity: 0, zIndex: 5, updateWhenIdle: false, keepBuffer: 2 }).addTo(map);
        radarRef.current = fresh;
        let done = false;
        const swap = () => {
          if (done) return;
          done = true;
          fresh.setOpacity(0.62);
          setTimeout(() => old.remove(), 220);
        };
        fresh.once("load", swap);
        setTimeout(swap, 650);
      }
    } else if (radarRef.current) {
      radarRef.current.remove();
      radarRef.current = null;
    }
  }, [radarOn, frames, frameIdx, ready]);

  /* ------------------------- camada de satélite ------------------------- */
  useEffect(() => {
    const L = leafletRef.current, map = mapRef.current;
    if (!L || !map || !ready) return;
    if (satelliteOn && satFrames.length) {
      const frame = satFrames[satFrames.length - 1];
      const url = `https://tilecache.rainviewer.com${frame.path}/256/{z}/{x}/{y}/0/0_0.png`;
      if (!satelliteRef.current) {
        satelliteRef.current = L.tileLayer(url, { opacity: 0.55, zIndex: 4 }).addTo(map);
      } else {
        satelliteRef.current.setUrl(url);
      }
    } else if (satelliteRef.current) {
      satelliteRef.current.remove();
      satelliteRef.current = null;
    }
  }, [satelliteOn, satFrames, ready]);

  /* ------------------------- animação do radar ------------------------- */
  useEffect(() => {
    if (!playing || !radarOn || frames.length < 2) return;
    const t = setInterval(() => setFrameIdx((i) => (i + 1) % frames.length), 700);
    return () => clearInterval(t);
  }, [playing, radarOn, frames]);

  /* ------------------- vento animado (partículas Windy) ------------------- */
  useEffect(() => {
    const map = mapRef.current, canvas = windCanvasRef.current;
    if (!map || !canvas || !ready) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    if (!windOn) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      return;
    }

    let raf = 0;
    let stopped = false;
    type Particle = { lat: number; lon: number; age: number; ttl: number };
    const particles: Particle[] = [];

    const spawn = (): Particle => {
      const b = map.getBounds();
      return {
        lat: b.getSouth() + Math.random() * (b.getNorth() - b.getSouth()),
        lon: b.getWest() + Math.random() * (b.getEast() - b.getWest()),
        age: 0,
        ttl: 90 + Math.random() * 120,
      };
    };
    for (let i = 0; i < 650; i++) {
      const p = spawn();
      p.age = Math.random() * p.ttl;
      particles.push(p);
    }

    const sample = (lat: number, lon: number): { u: number; v: number } | null => {
      const g = windGridRef.current;
      if (!g) return null;
      const fx = ((lon - g.west) / (g.east - g.west)) * (g.cols - 1);
      const fy = ((lat - g.south) / (g.north - g.south)) * (g.rows - 1);
      if (fx < 0 || fy < 0 || fx > g.cols - 1 || fy > g.rows - 1) return null;
      const x0 = Math.floor(fx), y0 = Math.floor(fy);
      const x1 = Math.min(g.cols - 1, x0 + 1), y1 = Math.min(g.rows - 1, y0 + 1);
      const tx = fx - x0, ty = fy - y0;
      const idx = (x: number, y: number) => y * g.cols + x;
      const bilin = (arr: number[]) =>
        arr[idx(x0, y0)] * (1 - tx) * (1 - ty) + arr[idx(x1, y0)] * tx * (1 - ty) +
        arr[idx(x0, y1)] * (1 - tx) * ty + arr[idx(x1, y1)] * tx * ty;
      return { u: bilin(g.u), v: bilin(g.v) };
    };

    const fetchGrid = async () => {
      try {
        const b = map.getBounds();
        const r = await fetch(
          `/api/windgrid?south=${b.getSouth()}&west=${b.getWest()}&north=${b.getNorth()}&east=${b.getEast()}`,
        );
        if (r.ok) windGridRef.current = (await r.json()) as WindGrid;
      } catch { /* mantém grade anterior */ }
    };
    fetchGrid();
    let debounce: ReturnType<typeof setTimeout> | null = null;
    const onMoveEnd = () => {
      if (debounce) clearTimeout(debounce);
      debounce = setTimeout(fetchGrid, 700);
    };
    map.on("moveend", onMoveEnd);

    const DT_HOURS = 0.085; // avanço temporal por frame da animação
    const step = () => {
      if (stopped) return;
      ctx.globalCompositeOperation = "destination-out";
      ctx.fillStyle = "rgba(0,0,0,0.16)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.globalCompositeOperation = "source-over";
      ctx.lineWidth = 1.3;
      ctx.lineCap = "round";

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        const w = sample(p.lat, p.lon);
        if (!w || p.age > p.ttl) {
          particles[i] = spawn();
          continue;
        }
        const prev = map.latLngToContainerPoint([p.lat, p.lon]);
        const cosLat = Math.max(0.2, Math.cos((p.lat * Math.PI) / 180));
        p.lon += (w.u * DT_HOURS) / (111.32 * cosLat);
        p.lat += (w.v * DT_HOURS) / 110.57;
        p.age++;
        const next = map.latLngToContainerPoint([p.lat, p.lon]);
        if (next.x < -60 || next.y < -60 || next.x > canvas.width + 60 || next.y > canvas.height + 60) {
          particles[i] = spawn();
          continue;
        }
        const speed = Math.hypot(w.u, w.v);
        ctx.strokeStyle = windColor(speed);
        ctx.globalAlpha = 0.8;
        ctx.beginPath();
        ctx.moveTo(prev.x, prev.y);
        ctx.lineTo(next.x, next.y);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);

    return () => {
      stopped = true;
      cancelAnimationFrame(raf);
      map.off("moveend", onMoveEnd);
      if (debounce) clearTimeout(debounce);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    };
  }, [windOn, ready]);

  /* ------------------------- marcadores de alertas ------------------------- */
  useEffect(() => {
    const L = leafletRef.current, group = markersRef.current;
    if (!L || !group || !ready) return;
    group.clearLayers();
    for (const alert of alerts) {
      const meta = severityMeta(alert.severity);
      const size = alert.severity === 4 ? 20 : alert.severity === 3 ? 16 : alert.severity === 2 ? 12 : 10;
      const icon = L.divIcon({
        className: "",
        html: `<div class="vigia-marker ${alert.id === selectedId ? "selected" : ""}" style="width:${size}px;height:${size}px;background:${meta.color};color:${meta.color}"></div>`,
        iconSize: [size, size],
        iconAnchor: [size / 2, size / 2],
      });
      const marker = L.marker([alert.latitude, alert.longitude], { icon });
      marker.on("click", () => callbacksRef.current.onSelect(alert));
      marker.bindTooltip(
        `<strong>${escapeHtml(alert.title)}</strong><br/>Severidade: ${meta.label}`,
        { direction: "top", offset: [0, -8] },
      );
      marker.addTo(group);
    }
  }, [alerts, selectedId, ready]);

  /* --------------------- voa até o alerta selecionado --------------------- */
  useEffect(() => {
    const map = mapRef.current;
    if (!map || selectedId == null) return;
    const alert = alerts.find((a) => a.id === selectedId);
    if (alert) map.flyTo([alert.latitude, alert.longitude], Math.max(map.getZoom(), 5), { duration: 1.1 });
  }, [selectedId]); // eslint-disable-line react-hooks/exhaustive-deps

  const frameTime = frames.length
    ? new Date(frames[Math.min(frameIdx, frames.length - 1)].time * 1000).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
    : null;

  const isNowcast = frames.length > 0 && frameIdx >= frames.length - 3 && frames.length > 12;

  const toggleBtn = (active: boolean) =>
    `rounded px-2.5 py-1.5 text-left text-xs font-medium transition-colors ${active ? "bg-cyan-500/20 text-cyan-300" : "text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200"}`;
  const baseBtn = (active: boolean) =>
    `rounded px-2.5 py-1.5 text-left text-xs font-medium transition-colors ${active ? "bg-emerald-500/20 text-emerald-300" : "text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200"}`;

  return (
    <div className="relative h-full w-full overflow-hidden rounded-xl border border-zinc-800">
      <div ref={containerRef} className="h-full w-full" />

      {/* painel de camadas */}
      <div className="nice-scroll absolute right-3 top-3 z-[500] max-h-[85%] w-52 overflow-y-auto rounded-lg border border-zinc-700/80 bg-zinc-950/90 shadow-xl backdrop-blur">
        <button
          onClick={() => setPanelOpen((v) => !v)}
          className="flex w-full items-center gap-2 px-3 py-2 text-xs font-bold uppercase tracking-wider text-zinc-200"
        >
          <Layers className="h-4 w-4 text-cyan-400" /> Mapa & camadas
        </button>
        {panelOpen && (
          <div className="px-2 pb-2">
            <p className="px-1.5 pb-1 pt-0.5 text-[10px] font-bold uppercase tracking-wider text-zinc-500">Mapa base</p>
            <div className="flex flex-col gap-0.5">
              {(Object.keys(BASE_LAYERS) as BaseKey[]).map((k) => (
                <button key={k} className={baseBtn(baseKey === k)} onClick={() => setBaseKey(k)}>
                  {BASE_LAYERS[k].label} {baseKey === k ? "• ativo" : ""}
                </button>
              ))}
            </div>
            <p className="px-1.5 pb-1 pt-2.5 text-[10px] font-bold uppercase tracking-wider text-zinc-500">Camadas ao vivo</p>
            <div className="flex flex-col gap-0.5">
              <button className={toggleBtn(radarOn)} onClick={() => setRadarOn((v) => !v)}>
                Radar de chuva {radarOn ? "• ligado" : ""}
              </button>
              <button className={toggleBtn(windOn)} onClick={() => setWindOn((v) => !v)}>
                Vento animado (Windy) {windOn ? "• ligado" : ""}
              </button>
              <button className={toggleBtn(satelliteOn)} onClick={() => setSatelliteOn((v) => !v)}>
                Satélite infravermelho {satelliteOn ? "• ligado" : ""}
              </button>
            </div>
            <p className="px-1.5 pt-2 text-[10px] leading-snug text-zinc-500">
              Clique em qualquer ponto do mapa para ver vento, chuva, previsão e o índice de confiança local.
            </p>
          </div>
        )}
      </div>

      {/* legenda */}
      <div className="absolute bottom-9 left-3 z-[500] rounded-lg border border-zinc-700/80 bg-zinc-950/90 px-3 py-2 backdrop-blur">
        <p className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-zinc-400">Severidade</p>
        <div className="flex flex-col gap-1">
          {[4, 3, 2, 1].map((s) => (
            <span key={s} className="flex items-center gap-2 text-[11px] text-zinc-300">
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: severityMeta(s).color }} />
              {severityMeta(s).label}
            </span>
          ))}
        </div>
        {windOn && (
          <div className="mt-2 border-t border-zinc-800 pt-2">
            <p className="mb-1 text-[10px] font-bold uppercase tracking-wider text-zinc-400">Vento (km/h)</p>
            <div
              className="h-2 w-32 rounded"
              style={{ background: "linear-gradient(90deg,#38bdf8,#34d399,#facc15,#fb923c,#ef4444)" }}
            />
            <div className="mt-0.5 flex w-32 justify-between text-[9px] tabular-nums text-zinc-500">
              <span>0</span><span>20</span><span>40</span><span>60+</span>
            </div>
          </div>
        )}
      </div>

      {/* controle da animação do radar */}
      {radarOn && frames.length > 0 && (
        <div className="absolute bottom-9 left-1/2 z-[500] flex w-[min(460px,74%)] -translate-x-1/2 items-center gap-2 rounded-lg border border-zinc-700/80 bg-zinc-950/90 px-3 py-2 backdrop-blur">
          <button
            onClick={() => setPlaying((v) => !v)}
            className="flex h-7 w-7 shrink-0 items-center justify-center rounded bg-cyan-600 text-white hover:bg-cyan-500"
            aria-label={playing ? "Pausar radar" : "Reproduzir radar"}
          >
            {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </button>
          <input
            type="range"
            min={0}
            max={frames.length - 1}
            value={Math.min(frameIdx, frames.length - 1)}
            onChange={(e) => { setFrameIdx(Number(e.target.value)); setPlaying(false); }}
            className="w-full accent-cyan-400"
          />
          <span className="shrink-0 text-xs font-semibold tabular-nums text-cyan-300">
            {frameTime}{isNowcast ? " (previsão)" : ""}
          </span>
        </div>
      )}
    </div>
  );
}
