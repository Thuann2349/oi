import {
  Activity, Flame, CloudLightning, CloudRainWind, Mountain, Waves,
  CloudSun, Snowflake, ThermometerSun, TriangleAlert, type LucideIcon,
} from "lucide-react";

const MAP: Record<string, LucideIcon> = {
  terremoto: Activity,
  tsunami: Waves,
  vulcao: Mountain,
  incendio: Flame,
  tempestade: CloudLightning,
  enchente: CloudRainWind,
  deslizamento: TriangleAlert,
  ciclone: CloudRainWind,
  seca: CloudSun,
  neve: Snowflake,
  calor: ThermometerSun,
  outro: TriangleAlert,
};

export function typeIcon(type: string): LucideIcon {
  return MAP[type] ?? TriangleAlert;
}

export function TypeIcon({ type, className }: { type: string; className?: string }) {
  const Icon = typeIcon(type);
  return <Icon className={className} />;
}
