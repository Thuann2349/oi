"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ShieldCheck, X, Eye, EyeOff } from "lucide-react";

const CONSENT_KEY = "vigia:access-consent:v1";
const VISITOR_KEY = "vigia:anonymous-visitor:v1";

type Consent = "granted" | "denied" | null;

declare global {
  interface Navigator {
    standalone?: boolean;
  }
}

function newVisitorId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    return (c === "x" ? r : (r & 0x3 | 0x8)).toString(16);
  });
}

function visitorId(): string {
  let id = localStorage.getItem(VISITOR_KEY);
  if (!id) {
    id = newVisitorId();
    localStorage.setItem(VISITOR_KEY, id);
  }
  return id;
}

function appMode(): "app" | "site" {
  return window.matchMedia("(display-mode: standalone)").matches || navigator.standalone ? "app" : "site";
}

export default function ConsentBanner() {
  const pathname = usePathname();
  const [consent, setConsent] = useState<Consent>(null);
  const [visible, setVisible] = useState(false);
  const sentRef = useRef("");

  useEffect(() => {
    const readSaved = () => {
      const saved = localStorage.getItem(CONSENT_KEY);
      if (saved === "granted" || saved === "denied") {
        setConsent(saved);
        setVisible(false);
      } else {
        setConsent(null);
        setVisible(true);
      }
    };
    const onConsentChange = (event: Event) => {
      const value = (event as CustomEvent<{ value?: string }>).detail?.value;
      if (value === "granted" || value === "denied") {
        setConsent(value);
        setVisible(false);
      } else readSaved();
    };
    readSaved();
    window.addEventListener("vigia:consent-changed", onConsentChange);
    window.addEventListener("storage", readSaved);
    return () => {
      window.removeEventListener("vigia:consent-changed", onConsentChange);
      window.removeEventListener("storage", readSaved);
    };
  }, []);

  const sendVisit = useCallback(async (path: string) => {
    if (consent !== "granted" || !path || path.startsWith("/admin") || path.startsWith("/api")) return;
    const key = `${path}:${appMode()}`;
    if (sentRef.current === key) return;
    sentRef.current = key;
    try {
      await fetch("/api/analytics/visit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        keepalive: true,
        body: JSON.stringify({ consent: true, visitorId: visitorId(), path, appMode: appMode() }),
      });
    } catch {
      sentRef.current = "";
    }
  }, [consent]);

  useEffect(() => {
    if (consent === "granted") void sendVisit(pathname);
  }, [consent, pathname, sendVisit]);

  const choose = (value: Exclude<Consent, null>) => {
    localStorage.setItem(CONSENT_KEY, value);
    setConsent(value);
    setVisible(false);
    if (value === "denied") sentRef.current = "";
  };

  if (!visible) return null;

  return (
    <aside
      aria-label="Preferências de privacidade"
      className="fixed inset-x-3 bottom-3 z-[600] mx-auto max-w-3xl rounded-xl border border-zinc-700 bg-zinc-950/98 p-4 shadow-2xl backdrop-blur sm:inset-x-6"
    >
      <button
        onClick={() => choose("denied")}
        aria-label="Fechar aviso e recusar analytics"
        className="absolute right-3 top-3 rounded p-1 text-zinc-500 hover:bg-zinc-800 hover:text-white"
      >
        <X className="h-4 w-4" />
      </button>
      <div className="flex gap-3 pr-6">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-cyan-500/10 text-cyan-300">
          <ShieldCheck className="h-5 w-5" />
        </span>
        <div>
          <h2 className="text-sm font-black">Privacidade: escolha sobre analytics</h2>
          <p className="mt-1 text-xs leading-relaxed text-zinc-400">
            Se permitir, registraremos <strong className="text-zinc-200">IP, páginas visitadas, tipo/modelo detectável do aparelho,
            navegador e sistema operacional</strong> para o painel administrativo. Não coletamos nome, telefone, localização GPS
            nem o nome pessoal configurado no dispositivo. O user-agent bruto não é guardado; os registros são apagados após 30 dias.
            Recusar não altera o uso do mapa ou dos alertas. Leia a <Link href="/privacidade" className="underline text-cyan-300">política de privacidade</Link>.
          </p>
        </div>
      </div>
      <div className="mt-3 flex flex-wrap items-center justify-end gap-2">
        <button onClick={() => choose("denied")} className="flex items-center gap-1.5 rounded-md bg-zinc-800 px-3 py-2 text-xs font-bold text-zinc-200 hover:bg-zinc-700">
          <EyeOff className="h-3.5 w-3.5" /> Recusar
        </button>
        <button onClick={() => choose("granted")} className="flex items-center gap-1.5 rounded-md bg-cyan-600 px-3 py-2 text-xs font-bold text-white hover:bg-cyan-500">
          <Eye className="h-3.5 w-3.5" /> Permitir analytics
        </button>
      </div>
    </aside>
  );
}
