"use client";

import { useMemo, useState } from "react";
import { Search, Radio } from "lucide-react";
import { severityMeta, typeLabel, timeAgoPt } from "@/lib/meta";
import { TypeIcon } from "./TypeIcon";
import type { AlertRow } from "@/db/schema";

type Props = {
  alerts: AlertRow[];
  selectedId: number | null;
  freshIds: Set<number>;
  onSelect: (alert: AlertRow) => void;
};

const TYPE_FILTERS = [
  { value: "", label: "Todos" },
  { value: "terremoto", label: "Terremotos" },
  { value: "enchente", label: "Enchentes" },
  { value: "tempestade", label: "Tempestades" },
  { value: "incendio", label: "Incêndios" },
  { value: "vulcao", label: "Vulcões" },
  { value: "deslizamento", label: "Deslizamentos" },
];

export default function AlertFeed({ alerts, selectedId, freshIds, onSelect }: Props) {
  const [type, setType] = useState("");
  const [onlyHigh, setOnlyHigh] = useState(false);
  const [q, setQ] = useState("");

  const filtered = useMemo(
    () =>
      alerts.filter((a) => {
        if (type && a.type !== type) return false;
        if (onlyHigh && a.severity < 3) return false;
        if (q && !`${a.title} ${a.locationName}`.toLowerCase().includes(q.toLowerCase())) return false;
        return true;
      }),
    [alerts, type, onlyHigh, q],
  );

  return (
    <div className="flex h-full flex-col rounded-xl border border-zinc-800 bg-zinc-900/60">
      <div className="border-b border-zinc-800 p-3">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider">
            <Radio className="h-4 w-4 text-red-500" /> Alertas ao vivo
          </h2>
          <span className="rounded bg-zinc-800 px-2 py-0.5 text-xs font-semibold tabular-nums text-zinc-300">
            {filtered.length}
          </span>
        </div>
        <div className="relative mb-2">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar cidade, evento..."
            className="w-full rounded-md border border-zinc-700 bg-zinc-950 py-2 pl-9 pr-3 text-sm outline-none placeholder:text-zinc-600 focus:border-cyan-500"
          />
        </div>
        <div className="flex flex-wrap gap-1">
          {TYPE_FILTERS.map((f) => (
            <button
              key={f.value}
              onClick={() => setType(f.value)}
              className={`rounded-full px-2.5 py-1 text-[11px] font-medium transition-colors ${
                type === f.value ? "bg-cyan-500 text-zinc-950" : "bg-zinc-800 text-zinc-400 hover:text-zinc-100"
              }`}
            >
              {f.label}
            </button>
          ))}
          <button
            onClick={() => setOnlyHigh((v) => !v)}
            className={`rounded-full px-2.5 py-1 text-[11px] font-bold transition-colors ${
              onlyHigh ? "bg-red-600 text-white" : "bg-zinc-800 text-red-400 hover:text-zinc-100"
            }`}
          >
            Só graves
          </button>
        </div>
      </div>

      <div className="nice-scroll min-h-0 flex-1 overflow-y-auto">
        {filtered.length === 0 && (
          <p className="p-4 text-sm text-zinc-500">Nenhum alerta encontrado com esses filtros. O monitoramento continua ativo.</p>
        )}
        {filtered.map((alert) => {
          const sev = severityMeta(alert.severity);
          const selected = alert.id === selectedId;
          return (
            <button
              key={alert.id}
              onClick={() => onSelect(alert)}
              className={`flex w-full gap-3 border-b border-zinc-800/70 px-3 py-3 text-left transition-colors hover:bg-zinc-800/50 ${
                selected ? "bg-zinc-800/80" : ""
              } ${freshIds.has(alert.id) ? "alert-enter" : ""}`}
            >
              <span className="mt-0.5 w-1 shrink-0 rounded-full" style={{ background: sev.color }} />
              <span
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg"
                style={{ background: `${sev.color}22`, color: sev.color }}
              >
                <TypeIcon type={alert.type} className="h-5 w-5" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-semibold leading-snug text-zinc-100" title={alert.title}>
                  {alert.title}
                </span>
                <span className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-zinc-500">
                  <span>{typeLabel(alert.type)}</span>
                  <span aria-hidden>•</span>
                  <span>{timeAgoPt(alert.eventTime)}</span>
                  <span aria-hidden>•</span>
                  <span className="font-medium" style={{ color: sev.color }}>{sev.label}</span>
                </span>
                <span className="mt-1 flex flex-wrap gap-1">
                  <span className="rounded bg-zinc-800 px-1.5 py-0.5 text-[10px] font-medium text-zinc-400">{alert.source}</span>
                  {alert.leadMinutes > 0 && (
                    <span className="rounded bg-emerald-500/15 px-1.5 py-0.5 text-[10px] font-bold text-emerald-400">
                      {alert.leadMinutes} min antes do alerta oficial
                    </span>
                  )}
                </span>
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
