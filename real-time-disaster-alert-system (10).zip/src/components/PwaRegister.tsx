"use client";

import { useEffect } from "react";

export default function PwaRegister() {
  useEffect(() => {
    if (!("serviceWorker" in navigator)) return;
    const secure = window.isSecureContext || location.hostname === "localhost";
    if (!secure) return;
    navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch((error) => {
      console.warn("VIGIA: não foi possível ativar o modo instalável/offline.", error);
    });
  }, []);
  return null;
}
