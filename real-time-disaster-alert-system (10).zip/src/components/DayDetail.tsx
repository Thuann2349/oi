"use client";

import { useEffect, useMemo, useRef } from "react";
import { ChevronLeft, ChevronRight, X, CloudRain, Wind, ShieldCheck } from "lucide-react";
import { CodeIcon, codeLabel } from "./WeatherIcon";

export type HourRow = {
  time: string;
  temp: number | null;
  tempMin: number | null;
  tempMax: number | null;
  feels: number | null;
  humidity: number | null;
  rainProb: number | null;
  rainChance: number | null;
  rainMm: number | null;
  wind: number | null;
  gust: number | null;
  cloud: number | null;
  code: number | null;
  isDay: boolean;
  confidence: number | null;
  modelAgreement: number | null;
};

export type DayRow = {
  date: string;
  code: number | null;
  max: number | null;
  min: number | null;
  rain: number | null;
  rainProbMax: number | null;
  windMax: number | null;
  gustMax: number | null;
  rainChanceEnsemble: number | null;
  confidence: number | null;
  confidenceLabel?: string;
  models: Record<string, { max: number | null; min: number | null }>;
};

type Props = {
  day: DayRow;
  hours: HourRow[];
  nowHour: string | null;
  index: number;
  total: number;
  onPrev: () => void;
  onNext: () => void;
  onClose: () => void;
};

export function certColor(c: number | null | undefined): string {
  if (c == null) return "text-zinc-500";
  if (c >= 90) return "text-emerald-400";
  if (c >= 75) return "text-yellow-400";
  if (c >= 60) return "text-orange-400";
  return "text-red-400";
}

const rnd = (v: number | null | undefined) => (v == null ? "—" : String(Math.round(v)));

export default function DayDetail({ day, hours, nowHour, index, total, onPrev, onNext, onClose }: Props) {
  // Handlers em ref: o listener de teclado é registrado uma única vez.
  const handlers = useRef({ onPrev, onNext, onClose });
  handlers.current = { onPrev, onNext, onClose };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") handlers.current.onClose();
      else if (e.key === "ArrowLeft") handlers.current.onPrev();
      else if (e.key === "ArrowRight") handlers.current.onNext();
    };
    window.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, []);

  const dateLabel = new Date(`${day.date}T12:00:00`).toLocaleDateString("pt-BR", {
    weekday: "long",
    day: "2-digit",
    month: "long",
  });

  const chart = useMemo(() => {
    const W = 960, L = 34, R = 16, TOP = 22, BOT = 124, RAIN_BASE = 196, RAIN_MAX = 46;
    const n = Math.max(1, hours.length - 1);
    const xAt = (i: number) => L + (i / n) * (W - L - R);
    const vals: number[] = [];
    hours.forEach((hr) => {
      [hr.tempMin, hr.tempMax, hr.temp].forEach((v) => { if (v != null) vals.push(v); });
    });
    const lo = vals.length ? Math.floor(Math.min(...vals)) - 1 : 0;
    const hi = vals.length ? Math.ceil(Math.max(...vals)) + 1 : 1;
    const yAt = (t: number) => TOP + (1 - (t - lo) / Math.max(1, hi - lo)) * (BOT - TOP);

    const pts: Array<{ x: number; y: number; t: number; i: number }> = [];
    const hiPts: Array<{ x: number; y: number }> = [];
    const loPts: Array<{ x: number; y: number }> = [];
    hours.forEach((hr, i) => {
      if (hr.temp != null) pts.push({ x: xAt(i), y: yAt(hr.temp), t: hr.temp, i });
      if (hr.tempMax != null) hiPts.push({ x: xAt(i), y: yAt(hr.tempMax) });
      if (hr.tempMin != null) loPts.push({ x: xAt(i), y: yAt(hr.tempMin) });
    });
    const band = hiPts.length && loPts.length
      ? [...hiPts, ...[...loPts].reverse()].map((p) => `${p.x},${p.y}`).join(" ")
      : "";
    const line = pts.map((p) => `${p.x},${p.y}`).join(" ");
    const barW = ((W - L - R) / Math.max(1, hours.length)) * 0.62;
    const bars = hours.map((hr, i) => ({
      x: xAt(i),
      h: ((hr.rainChance ?? 0) / 100) * RAIN_MAX,
      pct: hr.rainChance,
      mm: hr.rainMm,
      i,
    }));
    return { W, L, R, RAIN_BASE, TOP, BOT, barW, xAt, band, line, pts, bars };
  }, [hours]);

  const maxGust = Math.max(0, ...hours.map((h) => h.gust ?? 0));
  const maxWind = Math.max(0, ...hours.map((h) => h.wind ?? 0));
  const totalRain = hours.reduce((acc, h) => acc + (h.rainMm ?? 0), 0);

  const headers = ["Hora", "Tempo", "Temp.", "Sensação", "Chuva (cenários)", "mm", "Vento", "Rajada", "Umidade", "Certeza"];

  return (
    <div
      className="fixed inset-0 z-[400] overflow-y-auto bg-zinc-950/85 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={`Previsão hora a hora de ${dateLabel}`}
        className="mx-auto my-4 w-[min(1100px,calc(100%-1.5rem))] rounded-2xl border border-zinc-700 bg-zinc-900 shadow-2xl sm:my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* cabeçalho com navegação entre dias */}
        <div className="flex items-start justify-between gap-3 border-b border-zinc-800 p-4 sm:p-5">
          <div className="min-w-0">
            <p className="text-[11px] font-black uppercase tracking-widest text-cyan-400">
              Previsão hora a hora • dia {index + 1} de {total}
            </p>
            <h2 className="mt-0.5 text-xl font-black leading-tight sm:text-2xl">{dateLabel.charAt(0).toUpperCase() + dateLabel.slice(1)}</h2>
            <p className="mt-1 flex items-center gap-2 text-sm text-zinc-400">
              <CodeIcon code={day.code} className="h-5 w-5 text-cyan-300" /> {codeLabel(day.code)}
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-1.5">
            <button
              onClick={onPrev}
              disabled={index === 0}
              aria-label="Dia anterior"
              className="flex h-9 w-9 items-center justify-center rounded-md bg-zinc-800 text-zinc-200 hover:bg-zinc-700 disabled:opacity-30"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              onClick={onNext}
              disabled={index >= total - 1}
              aria-label="Dia seguinte"
              className="flex h-9 w-9 items-center justify-center rounded-md bg-zinc-800 text-zinc-200 hover:bg-zinc-700 disabled:opacity-30"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
            <button
              onClick={onClose}
              aria-label="Fechar"
              className="flex h-9 w-9 items-center justify-center rounded-md bg-zinc-800 text-zinc-200 hover:bg-red-950 hover:text-red-300"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* resumo do dia */}
        <div className="grid grid-cols-2 gap-2 p-4 sm:grid-cols-5 sm:p-5">
          <div className="rounded-lg bg-zinc-950 p-3">
            <p className="text-[10px] font-bold uppercase tracking-wide text-zinc-500">Máx / mín</p>
            <p className="mt-1 text-lg font-black tabular-nums">
              {rnd(day.max)}° <span className="text-sm text-zinc-500">{rnd(day.min)}°</span>
            </p>
          </div>
          <div className="rounded-lg bg-zinc-950 p-3">
            <p className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide text-zinc-500"><CloudRain className="h-3 w-3" /> Chuva do dia</p>
            <p className="mt-1 text-lg font-black tabular-nums">{(day.rain ?? totalRain).toFixed(1)} mm</p>
          </div>
          <div className="rounded-lg bg-zinc-950 p-3">
            <p className="text-[10px] font-bold uppercase tracking-wide text-zinc-500">Chance de chuva</p>
            <p className="mt-1 text-lg font-black tabular-nums text-cyan-300">{day.rainChanceEnsemble ?? "—"}%</p>
            <p className="text-[10px] text-zinc-500">média dos 143 cenários</p>
          </div>
          <div className="rounded-lg bg-zinc-950 p-3">
            <p className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide text-zinc-500"><Wind className="h-3 w-3" /> Vento máx.</p>
            <p className="mt-1 text-lg font-black tabular-nums">{Math.round(maxWind)} km/h</p>
            <p className="text-[10px] text-zinc-500">rajada {Math.round(maxGust)} km/h</p>
          </div>
          <div className="col-span-2 rounded-lg border border-emerald-900/60 bg-emerald-950/30 p-3 sm:col-span-1">
            <p className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide text-emerald-300"><ShieldCheck className="h-3 w-3" /> Certeza do dia</p>
            <p className={`mt-1 text-lg font-black tabular-nums ${certColor(day.confidence)}`}>
              {day.confidence ?? "—"}%{day.confidenceLabel ? <span className="ml-1 text-xs font-bold text-emerald-200/80">{day.confidenceLabel}</span> : null}
            </p>
            <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-zinc-800">
              <div className="h-full rounded-full bg-emerald-400" style={{ width: `${day.confidence ?? 0}%` }} />
            </div>
          </div>
        </div>

        {/* gráfico do dia inteiro */}
        <div className="px-4 pb-2 sm:px-5">
          <p className="mb-1 text-[11px] font-black uppercase tracking-wider text-zinc-400">Temperatura e chuva ao longo do dia</p>
          <svg viewBox={`0 0 ${chart.W} 226`} className="w-full" role="img" aria-label="Gráfico de temperatura e chuva ao longo do dia">
            {chart.band && <polygon points={chart.band} fill="rgba(34,211,238,0.14)" />}
            {chart.line && <polyline points={chart.line} fill="none" stroke="#22d3ee" strokeWidth={2.5} strokeLinejoin="round" />}
            {chart.pts.filter((p) => p.i % 3 === 0).map((p) => (
              <text key={`t${p.i}`} x={p.x} y={p.y - 9} textAnchor="middle" fontSize={11} fontWeight={700} fill="#e4e4e7">
                {Math.round(p.t)}°
              </text>
            ))}
            <line x1={chart.L} y1={chart.RAIN_BASE} x2={chart.W - chart.R} y2={chart.RAIN_BASE} stroke="#27272a" />
            {chart.bars.map((b) => (
              <rect
                key={`b${b.i}`}
                x={b.x - chart.barW / 2}
                y={chart.RAIN_BASE - b.h}
                width={chart.barW}
                height={Math.max(1, b.h)}
                rx={2}
                fill="#38bdf8"
                opacity={0.3 + ((b.pct ?? 0) / 100) * 0.7}
              >
                <title>{`${hours[b.i]?.time.slice(11, 13)}h • chance de chuva ${b.pct ?? "—"}% • ${b.mm ?? 0} mm`}</title>
              </rect>
            ))}
            {hours.map((hr, i) => (i % 3 === 0 ? (
              <text key={`h${i}`} x={chart.xAt(i)} y={220} textAnchor="middle" fontSize={11} fill="#a1a1aa">
                {hr.time.slice(11, 13)}h
              </text>
            ) : null))}
          </svg>
          <p className="pb-2 text-[11px] leading-snug text-zinc-500">
            Faixa azul: variação entre os modelos • linha: temperatura prevista • barras: chance de chuva entre os 143 cenários.
          </p>
        </div>

        {/* tabela hora a hora */}
        <div className="nice-scroll mx-4 mb-4 overflow-x-auto rounded-xl border border-zinc-800 sm:mx-5">
          <table className="w-full min-w-[900px] text-sm" data-testid="hour-table">
            <thead className="bg-zinc-950 text-left text-[10px] uppercase tracking-wide text-zinc-500">
              <tr>
                {headers.map((h) => (
                  <th key={h} className="px-3 py-2.5 font-bold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800">
              {hours.map((hr) => {
                const isNow = nowHour != null && hr.time.slice(0, 13) === nowHour;
                return (
                  <tr key={hr.time} data-hour-row className={isNow ? "bg-cyan-500/10" : "hover:bg-zinc-800/40"}>
                    <td className="whitespace-nowrap px-3 py-2 font-bold tabular-nums">
                      {hr.time.slice(11, 13)}h
                      {isNow && <span className="ml-1.5 rounded bg-cyan-500 px-1 text-[9px] font-black text-zinc-950">AGORA</span>}
                    </td>
                    <td className="px-3 py-2">
                      <span className="flex items-center gap-2 text-xs text-zinc-300">
                        <CodeIcon code={hr.code} className="h-5 w-5 shrink-0 text-cyan-300" />
                        <span className="truncate">{codeLabel(hr.code)}</span>
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-3 py-2 tabular-nums">
                      <strong>{rnd(hr.temp)}°</strong>{" "}
                      <span className="text-[10px] text-zinc-500">{rnd(hr.tempMin)}–{rnd(hr.tempMax)}°</span>
                    </td>
                    <td className="px-3 py-2 tabular-nums text-zinc-400">{rnd(hr.feels)}°</td>
                    <td className="whitespace-nowrap px-3 py-2 tabular-nums">
                      <span className="font-semibold text-cyan-300">{hr.rainChance ?? "—"}%</span>{" "}
                      <span className="text-[10px] text-zinc-500">modelo {hr.rainProb ?? "—"}%</span>
                    </td>
                    <td className="px-3 py-2 tabular-nums">{hr.rainMm != null ? hr.rainMm.toFixed(1) : "—"}</td>
                    <td className="whitespace-nowrap px-3 py-2 tabular-nums">{rnd(hr.wind)} km/h</td>
                    <td className="whitespace-nowrap px-3 py-2 tabular-nums text-zinc-400">{rnd(hr.gust)} km/h</td>
                    <td className="px-3 py-2 tabular-nums">{rnd(hr.humidity)}%</td>
                    <td className="px-3 py-2">
                      <span className={`rounded-full bg-zinc-800 px-2 py-0.5 text-xs font-black tabular-nums ${certColor(hr.confidence)}`}>
                        {hr.confidence ?? "—"}%
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <p className="px-4 pb-5 text-[11px] leading-relaxed text-zinc-500 sm:px-5">
          A certeza de cada hora mede a concordância entre 143 cenários (ECMWF 51 · GFS 31 · ICON 40 · GEM 21) e 5 modelos.
          99% é o máximo exibido: indica concordância quase total, mas nenhuma previsão tem certeza absoluta. Use as setas do teclado para trocar de dia.
        </p>
      </div>
    </div>
  );
}
