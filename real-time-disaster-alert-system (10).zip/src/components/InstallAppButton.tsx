"use client";

import { useEffect, useState } from "react";
import { Download, Smartphone, X } from "lucide-react";

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
};

export default function InstallAppButton() {
  const [promptEvent, setPromptEvent] = useState<InstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);

  useEffect(() => {
    const standalone = window.matchMedia("(display-mode: standalone)").matches || navigator.standalone === true;
    setInstalled(standalone);
    const onPrompt = (event: Event) => {
      event.preventDefault();
      setPromptEvent(event as InstallPromptEvent);
    };
    const onInstalled = () => { setInstalled(true); setPromptEvent(null); };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  if (installed) return null;

  const install = async () => {
    if (!promptEvent) { setHelpOpen((v) => !v); return; }
    await promptEvent.prompt();
    const choice = await promptEvent.userChoice;
    if (choice.outcome === "accepted") setInstalled(true);
    setPromptEvent(null);
  };

  return (
    <div className="relative">
      <button
        onClick={install}
        aria-label={promptEvent ? "Instalar o app VIGIA" : "Como instalar o app VIGIA"}
        className="flex items-center gap-1.5 rounded-md border border-zinc-700 bg-zinc-900 px-2.5 py-2 text-xs font-bold text-zinc-200 hover:border-cyan-600 hover:text-cyan-200 sm:px-3"
      >
        <Download className="h-4 w-4 text-cyan-400" />
        <span className="hidden sm:inline">Instalar app</span>
      </button>
      {helpOpen && (
        <div className="absolute right-0 top-12 z-[80] w-72 rounded-xl border border-zinc-700 bg-zinc-950 p-4 text-xs shadow-2xl">
          <div className="flex items-center justify-between gap-2">
            <p className="flex items-center gap-2 font-black text-white"><Smartphone className="h-4 w-4 text-cyan-400" /> Instalar o VIGIA</p>
            <button onClick={() => setHelpOpen(false)} aria-label="Fechar instruções" className="rounded p-1 text-zinc-500 hover:bg-zinc-800 hover:text-white"><X className="h-4 w-4" /></button>
          </div>
          <p className="mt-2 leading-relaxed text-zinc-400">
            <strong className="text-zinc-200">Android / Chrome:</strong> menu ⋮ → “Instalar app” ou “Adicionar à tela inicial”.
          </p>
          <p className="mt-2 leading-relaxed text-zinc-400">
            <strong className="text-zinc-200">iPhone / Safari:</strong> toque em Compartilhar ↑ → “Adicionar à Tela de Início”.
          </p>
          <p className="mt-2 leading-relaxed text-zinc-400">
            <strong className="text-zinc-200">Computador:</strong> use o ícone de instalação na barra de endereço do Chrome/Edge.
          </p>
          <p className="mt-2 text-[10px] leading-relaxed text-zinc-600">O VIGIA é um app web instalável; usa o mesmo endereço e a mesma conta do site.</p>
        </div>
      )}
    </div>
  );
}
