"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

export default function AutoRefresh({ seconds = 20 }: { seconds?: number }) {
  const router = useRouter();
  useEffect(() => {
    const t = setInterval(() => router.refresh(), seconds * 1000);
    return () => clearInterval(t);
  }, [router, seconds]);
  return (
    <span className="flex items-center gap-1.5 text-xs text-zinc-500">
      <span className="live-dot h-2 w-2 rounded-full bg-emerald-400" />
      Atualização automática a cada {seconds}s
    </span>
  );
}
