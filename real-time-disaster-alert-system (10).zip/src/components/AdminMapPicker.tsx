"use client";

import { useEffect, useRef } from "react";
import "leaflet/dist/leaflet.css";
import type { Map as LeafletMap, Marker, Circle } from "leaflet";

type Props = {
  lat: number;
  lon: number;
  radiusKm: number;
  onPick: (lat: number, lon: number) => void;
};

export default function AdminMapPicker({ lat, lon, radiusKm, onPick }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const markerRef = useRef<Marker | null>(null);
  const circleRef = useRef<Circle | null>(null);
  const leafletRef = useRef<typeof import("leaflet") | null>(null);
  const pickRef = useRef(onPick);
  pickRef.current = onPick;
  const firstRef = useRef(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const L = (await import("leaflet")).default;
      if (cancelled || !containerRef.current || mapRef.current) return;
      leafletRef.current = L;
      const map = L.map(containerRef.current, { center: [lat, lon], zoom: 6, worldCopyJump: true });
      L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
        attribution: "&copy; OSM &copy; CARTO",
        maxZoom: 18,
      }).addTo(map);
      map.on("click", (e: { latlng: { lat: number; lng: number } }) => pickRef.current(e.latlng.lat, e.latlng.lng));
      mapRef.current = map;
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const L = leafletRef.current, map = mapRef.current;
    if (!L || !map) return;
    if (!markerRef.current) {
      markerRef.current = L.marker([lat, lon], {
        icon: L.divIcon({
          className: "",
          html: `<div style="width:16px;height:16px;border-radius:9999px;background:#ef4444;border:2px solid #fff;box-shadow:0 0 12px #ef4444"></div>`,
          iconSize: [16, 16],
          iconAnchor: [8, 8],
        }),
      }).addTo(map);
      circleRef.current = L.circle([lat, lon], {
        radius: radiusKm * 1000, color: "#ef4444", weight: 1.5, fillColor: "#ef4444", fillOpacity: 0.08,
      }).addTo(map);
    } else {
      markerRef.current.setLatLng([lat, lon]);
      circleRef.current?.setLatLng([lat, lon]);
      circleRef.current?.setRadius(radiusKm * 1000);
    }
    if (firstRef.current) {
      firstRef.current = false;
    } else {
      map.flyTo([lat, lon], Math.max(map.getZoom(), 6), { duration: 0.8 });
    }
  }, [lat, lon, radiusKm]);

  return (
    <div className="overflow-hidden rounded-lg border border-zinc-700">
      <div ref={containerRef} className="h-64 w-full" />
      <p className="bg-zinc-950 px-3 py-2 text-[11px] text-zinc-500">
        Clique no mapa para mover o epicentro. O círculo vermelho é o raio de impacto do alerta.
      </p>
    </div>
  );
}
