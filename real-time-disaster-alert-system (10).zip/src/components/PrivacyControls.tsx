"use client";

import { useEffect, useState } from "react";
import { CheckCircle2, Eye, EyeOff, Loader2, ShieldCheck } from "lucide-react";

const CONSENT_KEY = "vigia:access-consent:v1";
const VISITOR_KEY = "vigia:anonymous-visitor:v1";

function notifyConsent(value: "granted" | "denied") {
  window.dispatchEvent(new CustomEvent("vigia:consent-changed", { detail: { value } }));
}

export default function PrivacyControls() {
  const [consent, setConsent] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => setConsent(localStorage.getItem(CONSENT_KEY)), []);

  const allow = () => {
    localStorage.setItem(CONSENT_KEY, "granted");
    setConsent("granted");
    setMessage("Consentimento salvo. Os acessos futuros serão registrados apenas para analytics do VIGIA.");
    notifyConsent("granted");
  };

  const revoke = async () => {
    setBusy(true);
    setMessage("");
    const visitorId = localStorage.getItem(VISITOR_KEY);
    let deleted: number | null = null;
    if (visitorId) {
      try {
        const res = await fetch("/api/analytics/visit", {
          method: "DELETE",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ visitorId }),
        });
        if (res.ok) deleted = Number((await res.json()).deleted ?? 0);
      } catch { /* a revogação local continua, mesmo offline */ }
    }
    localStorage.setItem(CONSENT_KEY, "denied");
    localStorage.removeItem(VISITOR_KEY);
    setConsent("denied");
    notifyConsent("denied");
    setMessage(
      deleted == null
        ? "Consentimento revogado neste aparelho. Sem conexão, não foi possível apagar registros antigos; eles expiram automaticamente em até 30 dias."
        : `Consentimento revogado e ${deleted} registro(s) deste navegador apagados. Novos acessos não serão registrados.`,
    );
    setBusy(false);
  };

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
      <p className="flex items-center gap-2 text-sm font-black"><ShieldCheck className="h-5 w-5 text-cyan-400" /> Preferência atual</p>
      <p className="mt-2 text-sm text-zinc-400">
        {consent === "granted" ? "Você permitiu analytics neste aparelho." : consent === "denied" ? "Você recusou analytics neste aparelho." : "Você ainda não escolheu. Analytics não é enviado antes do consentimento."}
      </p>
      <div className="mt-4 flex flex-wrap gap-2">
        <button onClick={allow} disabled={busy || consent === "granted"} className="flex items-center gap-2 rounded-md bg-cyan-600 px-3 py-2 text-xs font-bold text-white hover:bg-cyan-500 disabled:opacity-50">
          <Eye className="h-4 w-4" /> Permitir analytics
        </button>
        <button onClick={revoke} disabled={busy || consent === "denied"} className="flex items-center gap-2 rounded-md bg-zinc-800 px-3 py-2 text-xs font-bold text-zinc-100 hover:bg-zinc-700 disabled:opacity-50">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <EyeOff className="h-4 w-4" />} Revogar e apagar meus registros
        </button>
      </div>
      {message && <p className="mt-3 flex items-start gap-2 text-xs leading-relaxed text-emerald-300"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />{message}</p>}
      <p className="mt-3 text-[11px] leading-relaxed text-zinc-600">
        A exclusão pelo botão apaga os registros associados ao identificador anônimo guardado neste navegador. Limpar dados do navegador ou usar outro aparelho cria um identificador diferente.
      </p>
    </div>
  );
}
