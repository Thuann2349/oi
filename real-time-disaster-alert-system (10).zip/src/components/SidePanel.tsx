"use client";

import Link from "next/link";
import {
  X, Wind, Droplets, Gauge, Thermometer, MapPin, Clock3, Zap,
  BellRing, Users, Navigation, CloudRain,
} from "lucide-react";
import { severityMeta, typeLabel, formatDateTimePt } from "@/lib/meta";
import { TypeIcon } from "./TypeIcon";
import type { AlertRow } from "@/db/schema";

export type WeatherData = {
  lat: number;
  lon: number;
  timezone?: string;
  current: {
    temperature?: number;
    feelsLike?: number;
    humidity?: number;
    precipitation?: number;
    pressure?: number;
    windSpeed?: number;
    windDirection?: number;
    windGusts?: number;
    isDay: boolean;
    condition: string;
  };
  next12: Array<{ time: string; wind: number | null; rainProb: number | null }>;
  daily: Array<{ date: string; max?: number; min?: number; rain?: number; windMax?: number }>;
  confidence?: number | null;
  rainChance24h?: number | null;
  ensembleMembers?: number;
};

type Props = {
  alert: AlertRow | null;
  weather: WeatherData | null;
  weatherLoading: boolean;
  onClear: () => void;
};

function compass(deg?: number) {
  if (deg == null) return "—";
  const dirs = ["N", "NE", "L", "SE", "S", "SO", "O", "NO"];
  return dirs[Math.round(deg / 45) % 8];
}

export default function SidePanel({ alert, weather, weatherLoading, onClear }: Props) {
  if (weatherLoading) {
    return (
      <div className="flex h-full items-center justify-center rounded-xl border border-zinc-800 bg-zinc-900/60 p-6">
        <p className="animate-pulse text-sm text-zinc-400">Consultando estações meteorológicas...</p>
      </div>
    );
  }

  if (weather) {
    const c = weather.current;
    const maxWind = Math.max(10, ...weather.next12.map((h) => h.wind ?? 0));
    return (
      <div className="nice-scroll h-full overflow-y-auto rounded-xl border border-cyan-900/60 bg-zinc-900/60">
        <div className="flex items-start justify-between border-b border-zinc-800 p-4">
          <div>
            <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-cyan-400">
              <MapPin className="h-3.5 w-3.5" /> Ponto no mapa
            </p>
            <p className="mt-1 text-xs tabular-nums text-zinc-500">
              {weather.lat.toFixed(3)}, {weather.lon.toFixed(3)} {weather.timezone ? `• ${weather.timezone}` : ""}
            </p>
          </div>
          <button onClick={onClear} className="rounded p-1 text-zinc-500 hover:bg-zinc-800 hover:text-white" aria-label="Fechar">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="p-4">
          <div className="flex items-end justify-between">
            <div>
              <p className="text-sm text-zinc-400">{c.condition}</p>
              <p className="text-5xl font-black tabular-nums">{c.temperature != null ? Math.round(c.temperature) : "—"}°C</p>
              <p className="mt-1 text-xs text-zinc-500">Sensação {c.feelsLike != null ? Math.round(c.feelsLike) : "—"}°C</p>
            </div>
            <div className="text-center">
              <Navigation
                className="mx-auto h-8 w-8 text-cyan-400 transition-transform"
                style={{ transform: `rotate(${(c.windDirection ?? 0) + 180}deg)` }}
              />
              <p className="mt-1 text-xs font-bold text-zinc-300">{compass(c.windDirection)}</p>
            </div>
          </div>

          {weather.confidence != null && (
            <div className="mt-4 rounded-lg border border-emerald-900/60 bg-emerald-950/40 p-3">
              <div className="flex items-center justify-between">
                <p className="text-[11px] font-bold uppercase tracking-wide text-emerald-300">Confiança da previsão</p>
                <p className="text-2xl font-black tabular-nums text-emerald-400">{weather.confidence}%</p>
              </div>
              <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-zinc-800">
                <div className="h-full rounded-full bg-emerald-400" style={{ width: `${weather.confidence}%` }} />
              </div>
              <p className="mt-1.5 text-[11px] leading-snug text-emerald-200/70">
                Concordância entre {weather.ensembleMembers ? `${weather.ensembleMembers} cenários do ensemble ECMWF` : "o ensemble ECMWF"} e os modelos ECMWF, GFS e ICON.
                {weather.rainChance24h != null && (
                  <> Chance de chuva nas próximas 24h: <strong className="text-emerald-300">{weather.rainChance24h}%</strong> (ensemble).</>
                )}
              </p>
            </div>
          )}

          <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
            <div className="rounded-lg bg-zinc-950 p-3">
              <p className="flex items-center gap-1.5 text-[11px] uppercase tracking-wide text-zinc-500"><Wind className="h-3.5 w-3.5 text-cyan-400" /> Vento</p>
              <p className="mt-1 font-bold tabular-nums">{c.windSpeed != null ? Math.round(c.windSpeed) : "—"} km/h</p>
              <p className="text-[11px] text-zinc-500">rajadas {c.windGusts != null ? Math.round(c.windGusts) : "—"} km/h</p>
            </div>
            <div className="rounded-lg bg-zinc-950 p-3">
              <p className="flex items-center gap-1.5 text-[11px] uppercase tracking-wide text-zinc-500"><Droplets className="h-3.5 w-3.5 text-cyan-400" /> Umidade</p>
              <p className="mt-1 font-bold tabular-nums">{c.humidity ?? "—"}%</p>
              <p className="text-[11px] text-zinc-500">chuva {c.precipitation ?? 0} mm</p>
            </div>
            <div className="rounded-lg bg-zinc-950 p-3">
              <p className="flex items-center gap-1.5 text-[11px] uppercase tracking-wide text-zinc-500"><Gauge className="h-3.5 w-3.5 text-cyan-400" /> Pressão</p>
              <p className="mt-1 font-bold tabular-nums">{c.pressure != null ? Math.round(c.pressure) : "—"} hPa</p>
            </div>
            <div className="rounded-lg bg-zinc-950 p-3">
              <p className="flex items-center gap-1.5 text-[11px] uppercase tracking-wide text-zinc-500"><Thermometer className="h-3.5 w-3.5 text-cyan-400" /> Condição</p>
              <p className="mt-1 text-xs font-semibold leading-snug">{c.condition}</p>
            </div>
          </div>

          <p className="mb-2 mt-5 text-[11px] font-bold uppercase tracking-wider text-zinc-400">Vento nas próximas 12h (km/h)</p>
          <div className="flex h-20 items-end gap-1">
            {weather.next12.map((h, i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-1">
                <div
                  className={`w-full rounded-t ${h.rainProb != null && h.rainProb > 50 ? "bg-cyan-400" : "bg-zinc-600"}`}
                  style={{ height: `${Math.max(8, ((h.wind ?? 0) / maxWind) * 100)}%` }}
                  title={`${h.wind ?? 0} km/h • chuva ${h.rainProb ?? 0}%`}
                />
                <span className="text-[9px] tabular-nums text-zinc-500">
                  {new Date(h.time).getHours()}h
                </span>
              </div>
            ))}
          </div>

          <p className="mb-2 mt-4 text-[11px] font-bold uppercase tracking-wider text-zinc-400">Próximos dias</p>
          <div className="flex flex-col divide-y divide-zinc-800 rounded-lg bg-zinc-950">
            {weather.daily.map((d) => (
              <div key={d.date} className="flex items-center justify-between px-3 py-2 text-xs">
                <span className="font-medium capitalize text-zinc-300">
                  {new Date(`${d.date}T12:00:00`).toLocaleDateString("pt-BR", { weekday: "short", day: "2-digit", month: "2-digit" })}
                </span>
                <span className="tabular-nums text-zinc-400">{d.min != null ? Math.round(d.min) : "—"}° / <strong className="text-zinc-100">{d.max != null ? Math.round(d.max) : "—"}°</strong></span>
                <span className="flex items-center gap-1 tabular-nums text-zinc-500"><CloudRain className="h-3 w-3" /> {d.rain ?? 0}mm</span>
                <span className="flex items-center gap-1 tabular-nums text-zinc-500"><Wind className="h-3 w-3" /> {d.windMax != null ? Math.round(d.windMax) : "—"}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!alert) {
    return (
      <div className="flex h-full flex-col items-center justify-center rounded-xl border border-dashed border-zinc-800 bg-zinc-900/40 p-6 text-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-full bg-zinc-800">
          <MapPin className="h-7 w-7 text-cyan-400" />
        </span>
        <h3 className="mt-4 font-bold">Explore o mapa</h3>
        <p className="mt-1 max-w-[240px] text-sm leading-relaxed text-zinc-500">
          Clique em um alerta para ver detalhes, ou em qualquer ponto do mapa para vento, chuva e previsão — como no Windy, mas com alertas ao cidadão em tempo real.
        </p>
        <Link href="/assinar" className="mt-4 flex items-center gap-2 rounded-md bg-red-600 px-4 py-2 text-sm font-bold hover:bg-red-500">
          <BellRing className="h-4 w-4" /> Quero ser avisado antes
        </Link>
      </div>
    );
  }

  const sev = severityMeta(alert.severity);
  return (
    <div className="nice-scroll h-full overflow-y-auto rounded-xl border border-zinc-800 bg-zinc-900/60">
      <div className="p-4" style={{ borderTop: `4px solid ${sev.color}` }}>
        <div className="flex items-start justify-between gap-2">
          <span
            className="flex items-center gap-2 rounded-full px-3 py-1 text-xs font-black uppercase tracking-wide"
            style={{ background: `${sev.color}22`, color: sev.color }}
          >
            <TypeIcon type={alert.type} className="h-4 w-4" />
            {typeLabel(alert.type)} • {sev.label}
          </span>
          <button onClick={onClear} className="rounded p-1 text-zinc-500 hover:bg-zinc-800 hover:text-white" aria-label="Fechar detalhes">
            <X className="h-4 w-4" />
          </button>
        </div>

        <h3 className="mt-3 text-lg font-bold leading-snug">{alert.title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-zinc-400">{alert.description}</p>

        <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
          <div className="rounded-lg bg-zinc-950 p-3">
            <p className="flex items-center gap-1.5 text-[11px] uppercase tracking-wide text-zinc-500"><Clock3 className="h-3.5 w-3.5" /> Ocorreu</p>
            <p className="mt-1 font-semibold">{formatDateTimePt(alert.eventTime)}</p>
          </div>
          <div className="rounded-lg bg-zinc-950 p-3">
            <p className="flex items-center gap-1.5 text-[11px] uppercase tracking-wide text-zinc-500"><Zap className="h-3.5 w-3.5 text-emerald-400" /> Antecipação</p>
            <p className="mt-1 font-semibold text-emerald-400">{alert.leadMinutes} min antes do oficial</p>
          </div>
          <div className="rounded-lg bg-zinc-950 p-3">
            <p className="text-[11px] uppercase tracking-wide text-zinc-500">Fonte</p>
            <p className="mt-1 font-semibold">{alert.source}</p>
          </div>
          <div className="rounded-lg bg-zinc-950 p-3">
            <p className="text-[11px] uppercase tracking-wide text-zinc-500">Localização</p>
            <p className="mt-1 font-semibold tabular-nums">{alert.latitude.toFixed(2)}, {alert.longitude.toFixed(2)}</p>
          </div>
          {alert.magnitude != null && (
            <div className="rounded-lg bg-zinc-950 p-3">
              <p className="text-[11px] uppercase tracking-wide text-zinc-500">Magnitude</p>
              <p className="mt-1 font-semibold tabular-nums">{alert.magnitude}</p>
            </div>
          )}
          <div className="rounded-lg bg-zinc-950 p-3">
            <p className="text-[11px] uppercase tracking-wide text-zinc-500">Detectado pelo VIGIA</p>
            <p className="mt-1 font-semibold">{formatDateTimePt(alert.detectedAt)}</p>
          </div>
        </div>

        <div className="mt-4 rounded-lg border border-emerald-900/60 bg-emerald-950/40 p-3">
          <p className="flex items-center gap-2 text-sm font-bold text-emerald-300">
            <Users className="h-4 w-4" /> Quem está no VIGIA já foi avisado
          </p>
          <p className="mt-1 text-xs leading-relaxed text-emerald-200/70">
            Os alertas públicos aparecem na hora para todos os visitantes conectados — sem cadastro e sem nenhum dado pessoal.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Link href="/notificacoes" className="rounded-md bg-emerald-600 px-3 py-2 text-xs font-bold text-white hover:bg-emerald-500">
              Ver registro de disparos
            </Link>
            <Link href="/assinar" className="rounded-md bg-zinc-800 px-3 py-2 text-xs font-bold text-zinc-100 hover:bg-zinc-700">
              Proteger minha região
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
