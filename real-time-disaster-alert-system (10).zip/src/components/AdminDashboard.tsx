"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  ShieldAlert, LogOut, Send, Users, Globe2, Timer, Siren, Trash2,
  Radio, RefreshCw, FlaskConical, Zap, Eye, Lock, MapPin, Search,
  CheckCircle2, RotateCcw, Satellite, EyeOff,
} from "lucide-react";
import { ALERT_TYPES, severityMeta, typeLabel, timeAgoPt } from "@/lib/meta";
import { TypeIcon } from "./TypeIcon";
import type { AlertRow } from "@/db/schema";

const AdminMapPicker = dynamic(() => import("./AdminMapPicker"), {
  ssr: false,
  loading: () => <div className="flex h-64 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-900 text-sm text-zinc-500">Carregando mapa...</div>,
});

type GeoResult = { name: string; state: string; country: string; latitude: number; longitude: number };

type Dispatch = {
  id: number;
  title: string;
  type: string;
  severity: number;
  locationName: string;
  eventTime: string;
  reach: number;
  dispatchMs: number;
  impactRadiusKm: number;
};

type Overview = {
  connectedNow: number;
  alertsActive72h: number;
  adminAlertsTotal: number;
  totalReached: number;
  avgDispatchMs: number;
  ingest: {
    lastRunAt: string | null;
    lastNewAlerts: number;
    sources: Record<string, { ok: boolean; at: string | null; count: number }>;
  };
  alerts: AlertRow[];
  dispatches: Dispatch[];
};

const TEMPLATES = [
  { label: "Enchente", type: "enchente", severity: 4, title: "ALERTA DE ENCHENTE — evacuação preventiva imediata", description: "Nível do rio em elevação crítica. Moradores de áreas ribeirinhas e baixadas devem sair de casa AGORA e procurar terreno alto. Não atravesse ruas alagadas." },
  { label: "Tempestade severa", type: "tempestade", severity: 4, title: "TEMPESTADE SEVERA em aproximação — abriguem-se", description: "Tempestade com rajadas destrutivas, granizo e muitos raios atingirá a região nos próximos minutos. Abrigue-se em construção sólida, longe de janelas e árvores." },
  { label: "Risco de deslizamento", type: "deslizamento", severity: 4, title: "RISCO IMINENTE DE DESLIZAMENTO — saiam das encostas", description: "Encostas saturadas com sinais de movimentação. Quem mora em área de encosta deve sair de casa imediatamente e avisar os vizinhos." },
  { label: "Incêndio florestal", type: "incendio", severity: 3, title: "Incêndio florestal avançando — atenção à fumaça", description: "Frente de fogo em expansão em direção a áreas povoadas. Afaste-se contra o vento, proteja vias respiratórias e feche portas e janelas." },
  { label: "Onda de calor", type: "calor", severity: 2, title: "Onda de calor extremo — protejam-se", description: "Temperaturas extremas previstas. Hidrate-se, evite sol entre 10h e 16h e cuide de idosos, crianças e animais." },
  { label: "Evacuação geral", type: "outro", severity: 4, title: "EVACUAÇÃO PREVENTIVA — dirijam-se aos pontos de apoio", description: "Por determinação da coordenação de emergência, evacuação preventiva da área indicada. Levem documentos, remédios e sigam as rotas oficiais." },
];

export default function AdminDashboard() {
  const router = useRouter();
  const [data, setData] = useState<Overview | null>(null);
  const [type, setType] = useState("enchente");
  const [severity, setSeverity] = useState(4);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [locationName, setLocationName] = useState("Porto Alegre, RS");
  const [lat, setLat] = useState(-30.0346);
  const [lon, setLon] = useState(-51.2177);
  const [radiusKm, setRadiusKm] = useState(150);
  const [publicBroadcast, setPublicBroadcast] = useState(true);
  const [cityQuery, setCityQuery] = useState("");
  const [geoResults, setGeoResults] = useState<GeoResult[]>([]);
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState<{ reached: number; dispatchMs: number; title: string } | null>(null);
  const [actionMsg, setActionMsg] = useState<string | null>(null);
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/admin/overview");
      if (r.status === 401) { router.push("/admin/login"); return; }
      if (r.ok) setData(await r.json());
    } catch { /* mantém */ }
  }, [router]);

  useEffect(() => {
    load();
    const t = setInterval(load, 15000);
    return () => clearInterval(t);
  }, [load]);

  const searchCity = (q: string) => {
    setCityQuery(q);
    if (debounce.current) clearTimeout(debounce.current);
    if (q.trim().length < 2) { setGeoResults([]); return; }
    debounce.current = setTimeout(async () => {
      try {
        const r = await fetch(`/api/geocode?q=${encodeURIComponent(q)}`);
        setGeoResults((await r.json()).results ?? []);
      } catch { setGeoResults([]); }
    }, 300);
  };

  const applyTemplate = (t: (typeof TEMPLATES)[number]) => {
    setType(t.type);
    setSeverity(t.severity);
    setTitle(t.title);
    setDescription(t.description);
    setResult(null);
  };

  const dispatch = async () => {
    if (!title.trim()) { setActionMsg("Dê um título ao alerta antes de disparar."); return; }
    setSending(true);
    setResult(null);
    setActionMsg(null);
    try {
      const r = await fetch("/api/admin/broadcast", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type, severity, title, description,
          latitude: lat, longitude: lon, locationName,
          impactRadiusKm: radiusKm,
          publicBroadcast,
        }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "Erro no disparo");
      setResult({ reached: d.reached, dispatchMs: d.dispatchMs, title });
      load();
    } catch (err) {
      setActionMsg(err instanceof Error ? err.message : "Erro ao disparar");
    } finally {
      setSending(false);
    }
  };

  const rebroadcast = async (a: AlertRow) => {
    setSending(true);
    try {
      await fetch("/api/admin/broadcast", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: a.type, severity: a.severity, title: a.title, description: a.description,
          latitude: a.latitude, longitude: a.longitude, locationName: a.locationName,
          impactRadiusKm: (a.metadata as { impactRadiusKm?: number })?.impactRadiusKm ?? 150,
          publicBroadcast: true,
        }),
      });
      setActionMsg(`Alerta "${a.title}" redisparado para todos os conectados.`);
      load();
    } finally {
      setSending(false);
    }
  };

  const deleteAlert = async (id: number) => {
    await fetch(`/api/admin/alerts?id=${id}`, { method: "DELETE" });
    load();
  };

  const forceScan = async () => {
    setActionMsg("Varrendo USGS e NASA agora...");
    await fetch("/api/simulate");
    setTimeout(() => { load(); setActionMsg("Varredura concluída."); }, 800);
  };

  const simulate = async () => {
    await fetch("/api/simulate", { method: "POST" });
    setActionMsg("Desastre simulado disparado pela rede de sensores.");
    load();
  };

  const logout = async () => {
    await fetch("/api/admin/login", { method: "DELETE" });
    router.push("/admin/login");
  };

  const sources = data ? Object.values(data.ingest.sources) : [];
  const sourcesOk = sources.filter((s) => s.ok).length;

  const cards = [
    { icon: Globe2, label: "Visitantes conectados agora", value: data?.connectedNow ?? "—", color: "text-emerald-400", bg: "bg-emerald-400/10", hint: "recebem o disparo na hora, sem cadastro" },
    { icon: Users, label: "Pessoas alcançadas (total)", value: data?.totalReached ?? "—", color: "text-cyan-400", bg: "bg-cyan-400/10", hint: "soma do alcance de todos os disparos" },
    { icon: Send, label: "Disparos públicos", value: data?.adminAlertsTotal ?? "—", color: "text-cyan-400", bg: "bg-cyan-400/10", hint: "alertas emitidos por esta administração" },
    { icon: Timer, label: "Tempo médio de disparo", value: data ? `${data.avgDispatchMs} ms` : "—", color: "text-emerald-400", bg: "bg-emerald-400/10", hint: "do clique até estar no ar" },
    { icon: Siren, label: "Alertas ativos (72h)", value: data?.alertsActive72h ?? "—", color: "text-red-500", bg: "bg-red-500/10", hint: "todas as fontes de detecção" },
    { icon: Satellite, label: "Fontes de detecção online", value: data ? `${sourcesOk}/${sources.length}` : "—", color: "text-yellow-400", bg: "bg-yellow-400/10", hint: "USGS, NASA e rede de sensores" },
  ];

  const inputCls = "w-full rounded-md border border-zinc-700 bg-zinc-950 px-3 py-2.5 text-sm outline-none placeholder:text-zinc-600 focus:border-red-500";

  return (
    <div className="mx-auto max-w-[1600px] px-4 py-6 sm:px-6">
      {/* cabeçalho */}
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-red-600">
          <ShieldAlert className="h-7 w-7 text-white" />
        </span>
        <div className="mr-auto">
          <h1 className="text-2xl font-black tracking-tight">Painel de Comando — Administração</h1>
          <p className="flex flex-wrap items-center gap-1.5 text-sm text-zinc-400">
            <Lock className="h-3.5 w-3.5 text-emerald-400" />
            Disparo de emergência em 1 clique para todos os visitantes.
            <span className="flex items-center gap-1 font-semibold text-emerald-400">
              <EyeOff className="h-3.5 w-3.5" /> Disparo público sem dados pessoais; analytics de IP só com consentimento.
            </span>
          </p>
        </div>
        <Link href="/admin/acessos" className="flex items-center gap-2 rounded-md bg-cyan-950 px-3 py-2 text-xs font-bold text-cyan-200 hover:bg-cyan-900">
          <Users className="h-4 w-4" /> Acessos consentidos
        </Link>
        <Link href="/" className="flex items-center gap-2 rounded-md bg-zinc-800 px-3 py-2 text-xs font-bold hover:bg-zinc-700">
          <Eye className="h-4 w-4" /> Ver site público
        </Link>
        <button onClick={logout} className="flex items-center gap-2 rounded-md bg-zinc-800 px-3 py-2 text-xs font-bold hover:bg-red-950 hover:text-red-300">
          <LogOut className="h-4 w-4" /> Sair
        </button>
      </div>

      {/* cartões */}
      <div className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        {cards.map(({ icon: Icon, label, value, color, bg, hint }) => (
          <div key={label} className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-3.5">
            <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${bg}`}>
              <Icon className={`h-4 w-4 ${color}`} />
            </span>
            <p className="mt-2 text-xl font-black tabular-nums leading-none">{value}</p>
            <p className="mt-1 text-[11px] font-bold uppercase tracking-wide text-zinc-400">{label}</p>
            <p className="text-[10px] leading-snug text-zinc-600">{hint}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-4 xl:grid-cols-12">
        {/* ------------ COMPOSITOR DE ALERTA ------------ */}
        <section className="rounded-xl border border-red-900/60 bg-zinc-900/60 xl:col-span-7">
          <div className="border-b border-zinc-800 p-4">
            <h2 className="flex items-center gap-2 font-black uppercase tracking-wide">
              <Radio className="h-5 w-5 text-red-500" /> Disparar alerta de emergência
            </h2>
            <p className="mt-0.5 text-xs text-zinc-500">
              Um clique e o alerta abre na tela de todos os visitantes conectados. A região de cada pessoa é conferida no
              próprio aparelho dela — nenhum dado pessoal entra ou sai do sistema.
            </p>
          </div>

          <div className="p-4">
            <p className="mb-2 text-[11px] font-bold uppercase tracking-wider text-zinc-400">Modelos rápidos (1 clique preenche tudo)</p>
            <div className="flex flex-wrap gap-2">
              {TEMPLATES.map((t) => (
                <button
                  key={t.label}
                  onClick={() => applyTemplate(t)}
                  className="rounded-full bg-zinc-800 px-3 py-1.5 text-xs font-semibold text-zinc-200 transition-colors hover:bg-red-600 hover:text-white"
                >
                  {t.label}
                </button>
              ))}
            </div>

            <p className="mb-2 mt-5 text-[11px] font-bold uppercase tracking-wider text-zinc-400">Tipo de desastre</p>
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
              {Object.entries(ALERT_TYPES).map(([value, { label }]) => (
                <button
                  key={value}
                  onClick={() => setType(value)}
                  className={`flex items-center gap-2 rounded-lg border px-2.5 py-2 text-xs font-semibold transition-colors ${
                    type === value ? "border-red-500 bg-red-500/10 text-red-200" : "border-zinc-700 bg-zinc-950 text-zinc-400 hover:border-zinc-500"
                  }`}
                >
                  <TypeIcon type={value} className="h-4 w-4 shrink-0" /> <span className="truncate">{label}</span>
                </button>
              ))}
            </div>

            <p className="mb-2 mt-5 text-[11px] font-bold uppercase tracking-wider text-zinc-400">Severidade</p>
            <div className="grid grid-cols-4 gap-2">
              {[1, 2, 3, 4].map((s) => {
                const m = severityMeta(s);
                const active = severity === s;
                return (
                  <button
                    key={s}
                    onClick={() => setSeverity(s)}
                    className="rounded-lg border px-2 py-2.5 text-sm font-black uppercase transition-all"
                    style={active ? { borderColor: m.color, background: `${m.color}22`, color: m.color } : { borderColor: "#3f3f46", color: "#a1a1aa" }}
                  >
                    {m.label}
                  </button>
                );
              })}
            </div>

            <div className="mt-5 grid gap-3">
              <div>
                <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-zinc-400">Título do alerta</label>
                <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ex.: ALERTA DE ENCHENTE — evacuação preventiva" className={inputCls} />
              </div>
              <div>
                <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-zinc-400">Mensagem à população</label>
                <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} placeholder="Instruções claras e diretas: o que está acontecendo, onde e o que fazer agora." className={inputCls} />
              </div>
            </div>

            <div className="mt-5 grid gap-4 lg:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-zinc-400">Local do evento</label>
                <div className="relative">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
                  <input
                    value={cityQuery}
                    onChange={(e) => searchCity(e.target.value)}
                    placeholder={`Atual: ${locationName} — busque outra cidade...`}
                    className={`${inputCls} pl-9`}
                  />
                  {geoResults.length > 0 && (
                    <div className="absolute inset-x-0 top-full z-30 mt-1 overflow-hidden rounded-md border border-zinc-700 bg-zinc-900 shadow-2xl">
                      {geoResults.map((r, i) => (
                        <button
                          key={`${r.latitude}-${i}`}
                          onClick={() => {
                            setLat(r.latitude); setLon(r.longitude);
                            setLocationName(`${r.name}${r.state ? `, ${r.state}` : ""}`);
                            setCityQuery(""); setGeoResults([]);
                          }}
                          className="flex w-full items-center gap-2 px-3 py-2.5 text-left text-sm hover:bg-zinc-800"
                        >
                          <MapPin className="h-4 w-4 shrink-0 text-red-400" />
                          {r.name}{r.state ? `, ${r.state}` : ""} <span className="text-zinc-500">— {r.country}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <p className="mt-1.5 text-xs tabular-nums text-zinc-500">
                  Epicentro: <span className="text-zinc-300">{locationName} ({lat.toFixed(3)}, {lon.toFixed(3)})</span>
                </p>
                <label className="mb-1.5 mt-4 flex justify-between text-[11px] font-bold uppercase tracking-wider text-zinc-400">
                  Raio de impacto <span className="tabular-nums text-zinc-200">{radiusKm} km</span>
                </label>
                <input type="range" min={10} max={5000} step={10} value={radiusKm} onChange={(e) => setRadiusKm(Number(e.target.value))} className="w-full accent-red-500" />
                <p className="text-[11px] leading-snug text-zinc-500">
                  Quem tiver esta região protegida no aparelho e estiver dentro do raio vê o modal em tela cheia;
                  os demais visitantes veem um aviso discreto. Tudo decidido no aparelho de cada um.
                </p>
                <button
                  onClick={() => setPublicBroadcast((v) => !v)}
                  className={`mt-4 flex w-full items-start gap-2.5 rounded-lg border p-3 text-left transition-colors ${publicBroadcast ? "border-emerald-500/60 bg-emerald-500/10" : "border-zinc-700 bg-zinc-950"}`}
                >
                  <Globe2 className={`mt-0.5 h-5 w-5 shrink-0 ${publicBroadcast ? "text-emerald-400" : "text-zinc-500"}`} />
                  <span>
                    <span className="block text-sm font-bold">Alerta público imediato {publicBroadcast ? "• ATIVO" : "• desligado"}</span>
                    <span className="block text-xs leading-snug text-zinc-400">
                      Ligado: abre na tela de todos os visitantes conectados na hora. Desligado: o alerta entra só no mapa e no feed.
                    </span>
                  </span>
                </button>
              </div>
              <AdminMapPicker lat={lat} lon={lon} radiusKm={radiusKm} onPick={(la, lo) => { setLat(la); setLon(lo); }} />
            </div>

            {result && (
              <div className="mt-4 flex gap-2 rounded-lg border border-emerald-700 bg-emerald-950/50 p-3 text-sm text-emerald-200">
                <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-400" />
                <span>
                  <strong>Alerta disparado em {result.dispatchMs} ms!</strong> “{result.title}” alcançou{" "}
                  <strong>{result.reached} pessoa(s) conectada(s)</strong> — sem pedir nome, telefone ou e-mail de ninguém.
                </span>
              </div>
            )}
            {actionMsg && (
              <p className="mt-4 rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm text-zinc-300">{actionMsg}</p>
            )}

            <button
              onClick={dispatch}
              disabled={sending}
              className="mt-4 flex w-full items-center justify-center gap-3 rounded-lg bg-red-600 px-4 py-4 text-base font-black uppercase tracking-widest text-white shadow-lg shadow-red-950/50 transition-all hover:bg-red-500 disabled:opacity-60"
            >
              <Send className="h-5 w-5" />
              {sending ? "Disparando para todos..." : "Disparar alerta agora — sem pedir nada a ninguém"}
            </button>
            <p className="mt-2 text-center text-[11px] text-zinc-600">
              Um clique. Zero formulários. Zero dados pessoais. O alerta entra no ar em milissegundos.
            </p>
          </div>
        </section>

        {/* ------------ COLUNA DIREITA ------------ */}
        <div className="flex flex-col gap-4 xl:col-span-5">
          {/* sistema */}
          <section className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
            <h2 className="flex items-center gap-2 text-sm font-black uppercase tracking-wide">
              <Satellite className="h-4 w-4 text-cyan-400" /> Sistema de detecção
            </h2>
            <div className="mt-3 flex flex-col gap-2 text-sm">
              {data && Object.entries(data.ingest.sources).map(([name, s]) => (
                <div key={name} className="flex items-center justify-between rounded-lg bg-zinc-950 px-3 py-2">
                  <span className="flex items-center gap-2 font-medium">
                    <span className={`h-2 w-2 rounded-full ${s.ok ? "bg-emerald-400" : "bg-red-500"}`} />
                    {name}
                  </span>
                  <span className="text-xs tabular-nums text-zinc-500">
                    {s.ok ? `${s.count} eventos • ${s.at ? timeAgoPt(s.at) : ""}` : "offline"}
                  </span>
                </div>
              ))}
              <p className="text-xs text-zinc-500">
                Última varredura: {data?.ingest.lastRunAt ? timeAgoPt(data.ingest.lastRunAt) : "—"} • novos: {data?.ingest.lastNewAlerts ?? 0}
              </p>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <button onClick={forceScan} className="flex items-center gap-2 rounded-md bg-zinc-800 px-3 py-2 text-xs font-bold hover:bg-zinc-700">
                <RefreshCw className="h-4 w-4" /> Varrer fontes agora
              </button>
              <button onClick={simulate} className="flex items-center gap-2 rounded-md bg-zinc-800 px-3 py-2 text-xs font-bold hover:bg-zinc-700">
                <FlaskConical className="h-4 w-4" /> Simular desastre (sensores)
              </button>
              <Link href="/notificacoes" className="flex items-center gap-2 rounded-md bg-zinc-800 px-3 py-2 text-xs font-bold hover:bg-zinc-700">
                <Zap className="h-4 w-4" /> Registro de disparos
              </Link>
            </div>
          </section>

          {/* últimos disparos */}
          <section className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
            <h2 className="flex items-center gap-2 text-sm font-black uppercase tracking-wide">
              <Send className="h-4 w-4 text-cyan-400" /> Últimos disparos públicos
            </h2>
            <p className="mt-1 flex items-center gap-1 text-[11px] text-zinc-500">
              <EyeOff className="h-3 w-3" /> Alcance = conexões ao vivo no instante do disparo. Sem nenhum dado pessoal.
            </p>
            <div className="mt-3 flex flex-col divide-y divide-zinc-800">
              {(data?.dispatches ?? []).slice(0, 8).map((d) => (
                <div key={d.id} className="py-2 text-xs">
                  <p className="truncate font-medium text-zinc-200" title={d.title}>{d.title}</p>
                  <p className="mt-0.5 tabular-nums text-zinc-500">
                    {d.locationName} • alcançou <strong className="text-emerald-400">{d.reach} pessoa(s)</strong> •{" "}
                    disparo em <strong className="text-zinc-300">{d.dispatchMs} ms</strong> • {timeAgoPt(d.eventTime)}
                  </p>
                </div>
              ))}
              {(data?.dispatches ?? []).length === 0 && <p className="py-2 text-sm text-zinc-500">Nenhum disparo ainda. Use o compositor ao lado.</p>}
            </div>
          </section>

          {/* gerenciar alertas */}
          <section className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
            <h2 className="flex items-center gap-2 text-sm font-black uppercase tracking-wide">
              <Siren className="h-4 w-4 text-red-500" /> Gerenciar alertas
            </h2>
            <div className="nice-scroll mt-3 flex max-h-[460px] flex-col gap-2 overflow-y-auto pr-1">
              {(data?.alerts ?? []).map((a) => {
                const m = severityMeta(a.severity);
                const isAdminAlert = a.source === "Administração VIGIA";
                return (
                  <div key={a.id} className="rounded-lg border border-zinc-800 bg-zinc-950 p-3">
                    <div className="flex items-start gap-2">
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md" style={{ background: `${m.color}22`, color: m.color }}>
                        <TypeIcon type={a.type} className="h-4 w-4" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold" title={a.title}>{a.title}</p>
                        <p className="text-[11px] text-zinc-500">
                          {typeLabel(a.type)} • <span style={{ color: m.color }}>{m.label}</span> • {timeAgoPt(a.eventTime)} • {a.source}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 flex gap-1.5">
                      {isAdminAlert && (
                        <button onClick={() => rebroadcast(a)} disabled={sending} className="flex items-center gap-1 rounded bg-red-600/20 px-2 py-1 text-[11px] font-bold text-red-300 hover:bg-red-600 hover:text-white disabled:opacity-50">
                          <RotateCcw className="h-3 w-3" /> Redisparar p/ todos
                        </button>
                      )}
                      <button onClick={() => deleteAlert(a.id)} className="flex items-center gap-1 rounded bg-zinc-800 px-2 py-1 text-[11px] font-bold text-zinc-300 hover:bg-red-950 hover:text-red-300">
                        <Trash2 className="h-3 w-3" /> Excluir
                      </button>
                    </div>
                  </div>
                );
              })}
              {!data && <p className="text-sm text-zinc-500">Carregando...</p>}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}

