"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Radar, BellRing, LayoutDashboard, Siren, Inbox, Info, ShieldAlert, CloudSun, BarChart3 } from "lucide-react";
import InstallAppButton from "@/components/InstallAppButton";

const LINKS = [
  { href: "/", label: "Painel ao vivo", icon: LayoutDashboard },
  { href: "/clima", label: "Clima & Previsão", icon: CloudSun },
  { href: "/alertas", label: "Alertas", icon: Siren },
  { href: "/notificacoes", label: "Disparos", icon: Inbox },
  { href: "/metricas", label: "Métricas", icon: BarChart3 },
  { href: "/como-funciona", label: "Como funciona", icon: Info },
  { href: "/admin", label: "Admin", icon: ShieldAlert },
];

export default function Header() {
  const pathname = usePathname();
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <header className="sticky top-0 z-50 border-b border-zinc-800 bg-zinc-950/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-[1600px] items-center gap-4 px-4 sm:px-6">
        <Link href="/" className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-600 text-white">
            <Radar className="h-6 w-6" />
          </span>
          <span className="leading-tight">
            <span className="block text-lg font-black tracking-widest">VIGIA</span>
            <span className="block text-[10px] font-medium uppercase tracking-wider text-zinc-400">
              O cidadão sabe primeiro
            </span>
          </span>
        </Link>

        <nav className="ml-6 hidden items-center gap-1 xl:flex">
          {LINKS.map(({ href, label, icon: Icon }) => {
            const active = pathname === href;
            return (
              <Link
                key={href}
                href={href}
                className={`flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                  active ? "bg-zinc-800 text-white" : "text-zinc-400 hover:bg-zinc-900 hover:text-zinc-100"
                }`}
              >
                <Icon className="h-4 w-4" />
                {label}
              </Link>
            );
          })}
        </nav>

        <div className="ml-auto flex items-center gap-3">
          <InstallAppButton />
          <div className="hidden text-right md:block">
            <div className="flex items-center justify-end gap-2 text-sm font-semibold tabular-nums">
              <span className="live-dot h-2 w-2 rounded-full bg-emerald-400" />
              AO VIVO
            </div>
            <div className="text-xs tabular-nums text-zinc-500">
              {now ? now.toLocaleTimeString("pt-BR") : "--:--:--"}
            </div>
          </div>
          <Link
            href="/assinar"
            className="flex items-center gap-2 rounded-md bg-red-600 px-3 py-2.5 text-sm font-bold text-white transition-colors hover:bg-red-500 sm:px-4"
          >
            <BellRing className="h-4 w-4" />
            <span className="hidden sm:inline">Proteger minha região</span>
            <span className="sm:hidden">Alertas</span>
          </Link>
        </div>
      </div>

      {/* nav mobile */}
      <nav className="flex items-center gap-1 overflow-x-auto border-t border-zinc-900 px-3 py-1.5 lg:hidden">
        {LINKS.map(({ href, label, icon: Icon }) => {
          const active = pathname === href;
          return (
            <Link
              key={href}
              href={href}
              className={`flex shrink-0 items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium ${
                active ? "bg-zinc-800 text-white" : "text-zinc-400"
              }`}
            >
              <Icon className="h-3.5 w-3.5" />
              {label}
            </Link>
          );
        })}
      </nav>
    </header>
  );
}
