import {
  pgTable,
  serial,
  varchar,
  text,
  integer,
  real,
  boolean,
  timestamp,
  jsonb,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/** Alertas de desastres detectados (USGS, NASA EONET, rede de sensores VIGIA) */
export const alerts = pgTable(
  "alerts",
  {
    id: serial("id").primaryKey(),
    externalId: varchar("external_id", { length: 160 }).notNull(),
    source: varchar("source", { length: 60 }).notNull(),
    type: varchar("type", { length: 40 }).notNull(), // terremoto, incendio, vulcao, tempestade, enchente, deslizamento, seca, tsunami...
    title: text("title").notNull(),
    description: text("description").notNull().default(""),
    severity: integer("severity").notNull().default(2), // 1 baixo, 2 moderado, 3 alto, 4 extremo
    magnitude: real("magnitude"),
    latitude: real("latitude").notNull(),
    longitude: real("longitude").notNull(),
    locationName: text("location_name").notNull().default(""),
    eventTime: timestamp("event_time").notNull(),
    detectedAt: timestamp("detected_at").notNull().defaultNow(),
    /** minutos de antecipação estimados em relação ao alerta oficial tradicional */
    leadMinutes: integer("lead_minutes").notNull().default(0),
    metadata: jsonb("metadata").$type<Record<string, unknown>>().default({}),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("alerts_external_id_idx").on(t.externalId),
    index("alerts_event_time_idx").on(t.eventTime),
    index("alerts_type_idx").on(t.type),
    index("alerts_severity_idx").on(t.severity),
  ],
);

/** Cidadãos cadastrados para receber alertas antes da Defesa Civil */
export const subscriptions = pgTable(
  "subscriptions",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 120 }).notNull(),
    contact: varchar("contact", { length: 160 }).notNull(),
    channel: varchar("channel", { length: 20 }).notNull().default("push"), // push, whatsapp, sms, email
    city: varchar("city", { length: 120 }).notNull(),
    state: varchar("state", { length: 60 }).notNull().default(""),
    latitude: real("latitude").notNull(),
    longitude: real("longitude").notNull(),
    radiusKm: integer("radius_km").notNull().default(300),
    minSeverity: integer("min_severity").notNull().default(2),
    types: jsonb("types").$type<string[]>().notNull().default([]), // vazio = todos
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("subscriptions_active_idx").on(t.active)],
);

/** Registro de cada notificação disparada ao cidadão (prova do 0% de atraso) */
export const notifications = pgTable(
  "notifications",
  {
    id: serial("id").primaryKey(),
    subscriptionId: integer("subscription_id")
      .notNull()
      .references(() => subscriptions.id, { onDelete: "cascade" }),
    alertId: integer("alert_id")
      .notNull()
      .references(() => alerts.id, { onDelete: "cascade" }),
    channel: varchar("channel", { length: 20 }).notNull(),
    recipientName: varchar("recipient_name", { length: 120 }).notNull(),
    contact: varchar("contact", { length: 160 }).notNull(),
    message: text("message").notNull(),
    distanceKm: real("distance_km").notNull(),
    latencyMs: integer("latency_ms").notNull(), // tempo detecção -> disparo
    status: varchar("status", { length: 20 }).notNull().default("enviado"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("notifications_created_idx").on(t.createdAt),
    index("notifications_alert_idx").on(t.alertId),
  ],
);

/**
 * Acessos do site/app, gravados somente após consentimento explícito.
 * O user-agent bruto não é armazenado; somente navegador/SO/dispositivo inferidos.
 * IP é dado pessoal: retenção de 30 dias e acesso restrito ao admin.
 */
export const siteVisits = pgTable(
  "site_visits",
  {
    id: serial("id").primaryKey(),
    visitorId: varchar("visitor_id", { length: 64 }).notNull(),
    ipAddress: varchar("ip_address", { length: 45 }).notNull(),
    path: varchar("path", { length: 300 }).notNull(),
    appMode: varchar("app_mode", { length: 12 }).notNull().default("site"),
    deviceName: varchar("device_name", { length: 120 }).notNull(),
    deviceType: varchar("device_type", { length: 32 }).notNull(),
    browserName: varchar("browser_name", { length: 80 }).notNull(),
    browserVersion: varchar("browser_version", { length: 40 }).notNull().default(""),
    osName: varchar("os_name", { length: 80 }).notNull(),
    osVersion: varchar("os_version", { length: 40 }).notNull().default(""),
    consentedAt: timestamp("consented_at").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("site_visits_created_at_idx").on(t.createdAt),
    index("site_visits_ip_address_idx").on(t.ipAddress),
    index("site_visits_visitor_id_idx").on(t.visitorId),
    index("site_visits_path_idx").on(t.path),
  ],
);

export type AlertRow = typeof alerts.$inferSelect;
export type SubscriptionRow = typeof subscriptions.$inferSelect;
export type NotificationRow = typeof notifications.$inferSelect;
export type SiteVisitRow = typeof siteVisits.$inferSelect;
