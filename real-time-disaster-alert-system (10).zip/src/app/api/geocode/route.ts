import { NextRequest, NextResponse } from "next/server";
import { rateLimited } from "@/lib/security";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const limited = rateLimited(req, "geocode", 60);
  if (limited) return limited;
  const q = (new URL(req.url).searchParams.get("q") ?? "").slice(0, 80);
  if (q.trim().length < 2) return NextResponse.json({ results: [] });
  try {
    const res = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=6&language=pt&format=json`,
      { cache: "no-store" },
    );
    const data = await res.json();
    const results = (data.results ?? []).map((r: Record<string, unknown>) => ({
      name: r.name,
      state: r.admin1 ?? "",
      country: r.country ?? "",
      latitude: r.latitude,
      longitude: r.longitude,
    }));
    return NextResponse.json({ results });
  } catch {
    return NextResponse.json({ results: [] });
  }
}
