import { emitter, tryAcquireConnection, releaseConnection, type StreamEvent } from "@/lib/emitter";
import { clientIp } from "@/lib/security";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/** Canal SSE: empurra alertas e notificações ao navegador no instante da detecção (0% de atraso). */
export async function GET(req: Request) {
  const ip = clientIp(req);
  if (!tryAcquireConnection(ip)) {
    return NextResponse.json(
      { error: "Limite de conexões ao vivo atingido. Feche outras abas do VIGIA e tente novamente." },
      { status: 503 },
    );
  }

  const encoder = new TextEncoder();
  let closed = false;

  const release = () => {
    if (closed) return;
    closed = true;
    releaseConnection(ip);
  };

  const stream = new ReadableStream({
    start(controller) {
      const send = (event: StreamEvent) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(event)}\n\n`));
        } catch {
          release();
        }
      };

      send({ kind: "heartbeat", data: { at: Date.now() } });

      const listener = (event: StreamEvent) => send(event);
      emitter.on("vigia", listener);

      const heartbeat = setInterval(() => send({ kind: "heartbeat", data: { at: Date.now() } }), 20000);

      const cleanup = () => {
        if (closed) return;
        release();
        clearInterval(heartbeat);
        emitter.off("vigia", listener);
        try { controller.close(); } catch { /* já fechado */ }
      };

      req.signal.addEventListener("abort", cleanup);
    },
    cancel() {
      release();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
