import { NextRequest, NextResponse } from "next/server";
import { createSimulatedAlert, ingestAll } from "@/lib/ingest";
import { rateLimited } from "@/lib/security";

export const dynamic = "force-dynamic";

/** Dispara um alerta de demonstração da rede de sensores: prova o pipeline 0% de atraso. */
export async function POST(req: NextRequest) {
  const limited = rateLimited(req, "simulate-post", 3);
  if (limited) return limited;
  const { alert, reached } = await createSimulatedAlert();
  return NextResponse.json({ alert, reached });
}

/** Força nova varredura das fontes reais (USGS/NASA). */
export async function GET(req: NextRequest) {
  const limited = rateLimited(req, "simulate-scan", 6);
  if (limited) return limited;
  const result = await ingestAll();
  return NextResponse.json(result);
}
