import { NextRequest, NextResponse } from "next/server";
import { fetchJsonSafe } from "@/lib/weather";
import { rateLimited } from "@/lib/security";

export const dynamic = "force-dynamic";

type GridCache = { at: number; payload: unknown };
const cache = new Map<string, GridCache>();
const TTL_MS = 10 * 60 * 1000;

/**
 * Grade de vento (u/v) sobre a área visível do mapa — alimenta a camada de
 * partículas animadas estilo Windy. Uma única chamada ao Open-Meteo com
 * dezenas de pontos + cache de 10 min = zero atraso percebido.
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const num = (k: string) => Number(searchParams.get(k));
  let south = num("south"), west = num("west"), north = num("north"), east = num("east");
  if ([south, west, north, east].some(Number.isNaN)) {
    return NextResponse.json({ error: "bounds inválidos" }, { status: 400 });
  }
  // normaliza e limita a área (perf + cache eficiente)
  south = Math.max(-85, Math.min(85, Math.round(south * 2) / 2));
  north = Math.max(-85, Math.min(85, Math.round(north * 2) / 2));
  west = Math.round(west * 2) / 2;
  east = Math.round(east * 2) / 2;
  if (east - west > 160) { const mid = (west + east) / 2; west = mid - 80; east = mid + 80; }
  if (north - south > 100) { const mid = (south + north) / 2; south = mid - 50; north = mid + 50; }
  if (north <= south || east <= west) {
    return NextResponse.json({ error: "bounds inválidos" }, { status: 400 });
  }

  const cacheKey = `${south},${west},${north},${east}`;
  const hit = cache.get(cacheKey);
  if (hit && Date.now() - hit.at < TTL_MS) {
    return NextResponse.json(hit.payload);
  }

  const COLS = 11, ROWS = 9;
  const lats: number[] = [], lons: number[] = [];
  const points: Array<{ lat: number; lon: number }> = [];
  for (let r = 0; r < ROWS; r++) {
    const lat = south + ((north - south) * r) / (ROWS - 1);
    for (let c = 0; c < COLS; c++) {
      const lon = west + ((east - west) * c) / (COLS - 1);
      points.push({ lat, lon });
      if (r === 0) lons.push(lon);
    }
    lats.push(lat);
  }

  const url =
    `https://api.open-meteo.com/v1/forecast?latitude=${points.map((p) => p.lat.toFixed(3)).join(",")}` +
    `&longitude=${points.map((p) => p.lon.toFixed(3)).join(",")}` +
    `&current=wind_speed_10m,wind_direction_10m&wind_speed_unit=kmh`;

  const data = await fetchJsonSafe(url, 15000);
  const results = Array.isArray(data) ? data : data ? [data] : [];
  if (!results.length) {
    return NextResponse.json({ error: "grade de vento indisponível" }, { status: 502 });
  }

  const u = new Array(points.length).fill(0);
  const v = new Array(points.length).fill(0);
  results.forEach((res: any, i: number) => {
    const speed = typeof res?.current?.wind_speed_10m === "number" ? res.current.wind_speed_10m : 0;
    const dirDeg = typeof res?.current?.wind_direction_10m === "number" ? res.current.wind_direction_10m : 0;
    const rad = (dirDeg * Math.PI) / 180;
    // direção meteorológica = de onde o vento vem → componentes u (leste) e v (norte)
    u[i] = -speed * Math.sin(rad);
    v[i] = -speed * Math.cos(rad);
  });

  const payload = { west, east, south, north, cols: COLS, rows: ROWS, u, v, generatedAt: Date.now() };
  cache.set(cacheKey, { at: Date.now(), payload });
  if (cache.size > 60) cache.clear();
  return NextResponse.json(payload);
}
