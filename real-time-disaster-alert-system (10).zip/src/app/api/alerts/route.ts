import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { alerts } from "@/db/schema";
import { and, desc, eq, gte, ilike, or } from "drizzle-orm";
import { clampInt, rateLimited } from "@/lib/security";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const limited = rateLimited(req, "alerts", 120);
  if (limited) return limited;
  const { searchParams } = new URL(req.url);
  const type = searchParams.get("type");
  const minSeverity = clampInt(searchParams.get("minSeverity"), 0, 4, 0);
  const q = (searchParams.get("q") ?? "").slice(0, 80);
  const limit = clampInt(searchParams.get("limit"), 1, 300, 80);

  const conds = [];
  if (type) conds.push(eq(alerts.type, type));
  if (minSeverity > 0) conds.push(gte(alerts.severity, minSeverity));
  if (q) conds.push(or(ilike(alerts.title, `%${q}%`), ilike(alerts.locationName, `%${q}%`)));

  const rows = await db
    .select()
    .from(alerts)
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(desc(alerts.eventTime))
    .limit(limit);

  return NextResponse.json({ alerts: rows });
}
