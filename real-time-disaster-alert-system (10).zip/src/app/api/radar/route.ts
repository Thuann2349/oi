import { NextRequest, NextResponse } from "next/server";
import { rateLimited } from "@/lib/security";

export const dynamic = "force-dynamic";

/** Frames de radar/satélite do RainViewer (mesma base de dados aberta usada por apps de radar). */
export async function GET(req: NextRequest) {
  const limited = rateLimited(req, "radar", 60);
  if (limited) return limited;
  try {
    const res = await fetch("https://api.rainviewer.com/public/weather-maps.json", { cache: "no-store" });
    if (!res.ok) throw new Error("rainviewer indisponível");
    const data = await res.json();
    return NextResponse.json({
      radarPast: data.radar?.past ?? [],
      radarNowcast: data.radar?.nowcast ?? [],
      satellite: data.satellite?.infrared ?? [],
      generated: data.generated,
    });
  } catch {
    return NextResponse.json({ radarPast: [], radarNowcast: [], satellite: [] }, { status: 502 });
  }
}
