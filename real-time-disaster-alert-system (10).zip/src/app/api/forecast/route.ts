import { NextRequest, NextResponse } from "next/server";
import {
  WMO, MODELS, MODEL_LABELS, fetchJsonSafe, parseEnsemble, mergeEnsembles,
  hourlyEnsembleStats, alignIndex, spreadAt, tempAgreementFromSd, modelTempAgreement,
  rainConsensusFromPct, combinedConfidence, confidenceLabel, type EnsembleData,
} from "@/lib/weather";
import { parseLatLon, rateLimited } from "@/lib/security";

export const dynamic = "force-dynamic";

const DAYS = 16;
/** Ensembles usados: 51 + 31 + 40 + 21 = 143 cenários. */
const ENS_SOURCES = [
  { api: "ecmwf_ifs025", label: "ECMWF" },
  { api: "gfs025", label: "GFS" },
  { api: "icon_seamless", label: "ICON" },
  { api: "gem_global", label: "GEM" },
] as const;

const TTL_MS = 15 * 60 * 1000;
const cache = new Map<string, { at: number; payload: Record<string, unknown> }>();

type Row = {
  time: string;
  temp: number | null;
  tempMin: number | null;
  tempMax: number | null;
  feels: number | null;
  humidity: number | null;
  rainProb: number | null;
  rainChance: number | null;
  rainMm: number | null;
  wind: number | null;
  gust: number | null;
  cloud: number | null;
  code: number | null;
  isDay: boolean;
  confidence: number | null;
  modelAgreement: number | null;
  models: Record<string, number | null>;
};

const num = (v: unknown): number | null => (typeof v === "number" && Number.isFinite(v) ? v : null);
const r1 = (v: number | null): number | null => (v == null ? null : Math.round(v * 10) / 10);
const mean = (xs: number[]): number | null => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null);

/**
 * Previsão de 16 dias, hora a hora.
 * - 5 modelos determinísticos (ECMWF, GFS, ICON, JMA, GEM) por hora
 * - 4 ensembles somando 143 cenários para medir a dispersão e a chance de chuva
 * - Certeza calculada em cada hora (e média por dia) pela concordância real
 */
export async function GET(req: NextRequest) {
  const limited = rateLimited(req, "forecast", 60);
  if (limited) return limited;
  const coords = parseLatLon(new URL(req.url).searchParams);
  if (!coords) {
    return NextResponse.json({ error: "lat/lon inválidos" }, { status: 400 });
  }
  const { lat, lon } = coords;

  const cacheKey = `${lat.toFixed(2)},${lon.toFixed(2)}`;
  const hit = cache.get(cacheKey);
  if (hit && Date.now() - hit.at < TTL_MS) {
    return NextResponse.json({ ...hit.payload, cached: true });
  }

  const base = `latitude=${lat}&longitude=${lon}&timezone=auto`;
  const mainUrl =
    `https://api.open-meteo.com/v1/forecast?${base}` +
    `&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m` +
    `&hourly=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m,wind_gusts_10m,cloud_cover,is_day` +
    `&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max&forecast_days=${DAYS}`;
  const multiUrl =
    `https://api.open-meteo.com/v1/forecast?${base}` +
    `&hourly=temperature_2m,precipitation,precipitation_probability&models=${MODELS.join(",")}&forecast_days=${DAYS}`;

  const [main, multi, ...ensRaw] = await Promise.all([
    fetchJsonSafe(mainUrl, 15000),
    fetchJsonSafe(multiUrl, 20000),
    ...ENS_SOURCES.map((s) =>
      fetchJsonSafe(
        `https://ensemble-api.open-meteo.com/v1/ensemble?${base}&hourly=temperature_2m,precipitation&models=${s.api}&forecast_days=${DAYS}`,
        25000,
      ),
    ),
  ]);

  if (!main?.hourly?.time) {
    return NextResponse.json({ error: "Serviço de previsão indisponível no momento" }, { status: 502 });
  }

  const parsed: Array<EnsembleData | null> = ensRaw.map((r) => (r ? parseEnsemble(r) : null));
  const ensembleSources = ENS_SOURCES.map((s, i) => ({ model: s.label, members: parsed[i]?.memberCount ?? 0 }));
  const merged = mergeEnsembles(parsed.filter((e): e is EnsembleData => e != null));
  const ensStats = merged ? hourlyEnsembleStats(merged) : null;

  const h = main.hourly;
  const times: string[] = h.time;
  const mIdx: number[] = multi?.hourly?.time ? alignIndex(multi.hourly.time, times) : times.map(() => -1);
  const mh: Record<string, Array<number | null>> = multi?.hourly ?? {};
  const eIdx: number[] = merged ? alignIndex(merged.times, times) : times.map(() => -1);

  const rows: Row[] = times.map((t, i) => {
    const models: Record<string, number | null> = {};
    for (const m of MODELS) {
      const j = mIdx[i];
      const arr = mh[`temperature_2m_${m}`];
      models[m] = j >= 0 && arr ? num(arr[j]) : null;
    }
    const modelVals = Object.values(models);
    const mSpread = spreadAt(modelVals);
    const modelAgr = mSpread != null ? modelTempAgreement(mSpread) : null;

    const ej = eIdx[i];
    const sd = ensStats && ej >= 0 ? ensStats.sd[ej] : null;
    const wet = ensStats && ej >= 0 ? ensStats.wetPct[ej] : null;
    const ensAgr = sd != null ? tempAgreementFromSd(sd) : null;
    const rainCons = wet != null ? rainConsensusFromPct(wet) : null;
    const confidence = combinedConfidence({ ensembleTemp: ensAgr, rainConsensus: rainCons, model: modelAgr });

    const allT = [num(h.temperature_2m?.[i]), ...modelVals].filter((v): v is number => v != null);
    return {
      time: t,
      temp: r1(num(h.temperature_2m?.[i])),
      tempMin: allT.length ? r1(Math.min(...allT)) : null,
      tempMax: allT.length ? r1(Math.max(...allT)) : null,
      feels: r1(num(h.apparent_temperature?.[i])),
      humidity: num(h.relative_humidity_2m?.[i]),
      rainProb: num(h.precipitation_probability?.[i]),
      rainChance: wet,
      rainMm: r1(num(h.precipitation?.[i])),
      wind: r1(num(h.wind_speed_10m?.[i])),
      gust: r1(num(h.wind_gusts_10m?.[i])),
      cloud: num(h.cloud_cover?.[i]),
      code: num(h.weather_code?.[i]),
      isDay: h.is_day?.[i] === 1,
      confidence,
      modelAgreement: modelAgr != null ? Math.round(modelAgr * 100) : null,
      models,
    };
  });

  const d = main.daily ?? {};
  const dates: string[] = d.time ?? [];
  const daily = dates.map((date: string, k: number) => {
    const hs = rows.filter((r) => r.time.startsWith(date));
    const confs = hs.map((r) => r.confidence).filter((v): v is number => v != null);
    const dayConf = mean(confs) != null ? Math.round(mean(confs) as number) : null;
    const agrs = hs.map((r) => r.modelAgreement).filter((v): v is number => v != null);
    const wets = hs.map((r) => r.rainChance).filter((v): v is number => v != null);
    const models: Record<string, { max: number | null; min: number | null }> = {};
    for (const m of MODELS) {
      const vals = hs.map((r) => r.models[m]).filter((v): v is number => v != null);
      models[m] = {
        max: vals.length ? r1(Math.max(...vals)) : null,
        min: vals.length ? r1(Math.min(...vals)) : null,
      };
    }
    return {
      date,
      code: num(d.weather_code?.[k]),
      max: r1(num(d.temperature_2m_max?.[k])),
      min: r1(num(d.temperature_2m_min?.[k])),
      rain: r1(num(d.precipitation_sum?.[k])),
      rainProbMax: num(d.precipitation_probability_max?.[k]),
      windMax: r1(num(d.wind_speed_10m_max?.[k])),
      gustMax: r1(num(d.wind_gusts_10m_max?.[k])),
      rainChanceEnsemble: mean(wets) != null ? Math.round(mean(wets) as number) : null,
      models,
      modelAgreement: mean(agrs) != null ? Math.round(mean(agrs) as number) : null,
      confidence: dayConf,
      confidenceLabel: confidenceLabel(dayConf),
      hours: hs.length,
    };
  });

  const allConf = rows.map((r) => r.confidence).filter((v): v is number => v != null);
  const nearConf = rows.slice(0, 48).map((r) => r.confidence).filter((v): v is number => v != null);
  const confidence = mean(allConf) != null ? Math.round(mean(allConf) as number) : null;
  const confidenceNear = mean(nearConf) != null ? Math.round(mean(nearConf) as number) : null;

  const c = main.current ?? {};
  const payload = {
    lat,
    lon,
    timezone: main.timezone ?? null,
    forecastDays: dates.length,
    generatedAt: Date.now(),
    nowHour: typeof c.time === "string" ? c.time.slice(0, 13) : null,
    current: {
      temperature: c.temperature_2m,
      feelsLike: c.apparent_temperature,
      humidity: c.relative_humidity_2m,
      precipitation: c.precipitation,
      pressure: c.pressure_msl,
      windSpeed: c.wind_speed_10m,
      windDirection: c.wind_direction_10m,
      windGusts: c.wind_gusts_10m,
      isDay: c.is_day === 1,
      condition: WMO[c.weather_code] ?? "—",
      code: c.weather_code,
    },
    hourly: rows,
    daily,
    confidence,
    confidenceNear,
    confidenceLabel: confidenceLabel(confidence),
    ensembleMembers: merged?.memberCount ?? 0,
    ensembleSources,
    modelsUsed: MODELS.map((m) => MODEL_LABELS[m] ?? m),
    cached: false,
  };

  cache.set(cacheKey, { at: Date.now(), payload });
  if (cache.size > 200) cache.clear();
  return NextResponse.json(payload);
}
