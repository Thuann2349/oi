import { NextRequest, NextResponse } from "next/server";
import {
  WMO, fetchJsonSafe, parseEnsemble, ensembleAgreement,
  rainChanceNextHours, parseDailyByModel, modelAgreementOverall, combinedConfidence,
} from "@/lib/weather";
import { parseLatLon, rateLimited } from "@/lib/security";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const limited = rateLimited(req, "weather", 90);
  if (limited) return limited;
  const coords = parseLatLon(new URL(req.url).searchParams);
  if (!coords) {
    return NextResponse.json({ error: "lat/lon inválidos" }, { status: 400 });
  }
  const { lat, lon } = coords;

  const base = `latitude=${lat}&longitude=${lon}&timezone=auto`;
  const [data, ensRaw, mmRaw] = await Promise.all([
    fetchJsonSafe(
      `https://api.open-meteo.com/v1/forecast?${base}` +
      `&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m` +
      `&hourly=wind_speed_10m,precipitation_probability` +
      `&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max&forecast_days=5`,
    ),
    fetchJsonSafe(
      `https://ensemble-api.open-meteo.com/v1/ensemble?${base}` +
      `&hourly=temperature_2m,precipitation&models=ecmwf_ifs025&forecast_days=3`,
    ),
    fetchJsonSafe(
      `https://api.open-meteo.com/v1/forecast?${base}` +
      `&daily=temperature_2m_max,temperature_2m_min,precipitation_sum&models=ecmwf_ifs025,gfs_seamless,icon_seamless&forecast_days=5`,
    ),
  ]);

  if (!data) {
    return NextResponse.json({ error: "Serviço de clima indisponível no momento" }, { status: 502 });
  }

  const c = data.current ?? {};
  const times: string[] = data.hourly?.time ?? [];
  const nowIdx = Math.max(0, times.findIndex((t: string) => new Date(t).getTime() >= Date.now() - 3600_000));
  const next12 = times.slice(nowIdx, nowIdx + 12).map((t: string, i: number) => ({
    time: t,
    wind: data.hourly.wind_speed_10m?.[nowIdx + i] ?? null,
    rainProb: data.hourly.precipitation_probability?.[nowIdx + i] ?? null,
  }));

  // Índice de confiança real: concordância ensemble (50 cenários) + ECMWF/GFS/ICON
  const ens = ensRaw ? parseEnsemble(ensRaw) : null;
  let confidence: number | null = null;
  let rainChance24h: number | null = null;
  let ensembleMembers = 0;
  if (ens) {
    ensembleMembers = ens.memberCount;
    const agr = ensembleAgreement(ens, 48);
    const model = mmRaw ? modelAgreementOverall(parseDailyByModel(mmRaw.daily), 5) : null;
    confidence = combinedConfidence({ ensembleTemp: agr.tempAgreement, rainConsensus: agr.rainConsensus, model });
    rainChance24h = rainChanceNextHours(ens, 24);
  } else if (mmRaw) {
    confidence = combinedConfidence({ model: modelAgreementOverall(parseDailyByModel(mmRaw.daily), 5) });
  }

  return NextResponse.json({
    lat, lon,
    timezone: data.timezone,
    current: {
      temperature: c.temperature_2m,
      feelsLike: c.apparent_temperature,
      humidity: c.relative_humidity_2m,
      precipitation: c.precipitation,
      pressure: c.pressure_msl,
      windSpeed: c.wind_speed_10m,
      windDirection: c.wind_direction_10m,
      windGusts: c.wind_gusts_10m,
      isDay: c.is_day === 1,
      condition: WMO[c.weather_code] ?? "—",
      code: c.weather_code,
    },
    next12,
    daily: (data.daily?.time ?? []).map((t: string, i: number) => ({
      date: t,
      max: data.daily.temperature_2m_max?.[i],
      min: data.daily.temperature_2m_min?.[i],
      rain: data.daily.precipitation_sum?.[i],
      windMax: data.daily.wind_speed_10m_max?.[i],
    })),
    confidence,
    rainChance24h,
    ensembleMembers,
  });
}
