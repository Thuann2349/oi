import { NextRequest, NextResponse } from "next/server";
import { isIP } from "node:net";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { siteVisits } from "@/db/schema";
import { bodyTooLarge, clientIp, originGuard, rateLimited } from "@/lib/security";
import { parseVisitDevice } from "@/lib/visit-device";
import { cleanupExpiredSiteVisits, SITE_VISIT_RETENTION_DAYS } from "@/lib/visit-retention";

export const dynamic = "force-dynamic";

function validVisitorId(value: unknown): value is string {
  return typeof value === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

export async function POST(req: NextRequest) {
  const originError = originGuard(req);
  if (originError) return originError;
  const limited = rateLimited(req, "analytics-visit", 90);
  if (limited) return limited;
  if (bodyTooLarge(req, 4096)) {
    return NextResponse.json({ error: "Requisição muito grande." }, { status: 413 });
  }

  const body = await req.json().catch(() => null);
  if (!body || body.consent !== true) {
    return NextResponse.json({ error: "Consentimento explícito necessário." }, { status: 403 });
  }
  if (!validVisitorId(body.visitorId)) {
    return NextResponse.json({ error: "Identificador anônimo inválido." }, { status: 400 });
  }

  const path = typeof body.path === "string" ? body.path.slice(0, 300) : "";
  if (!path.startsWith("/") || path.startsWith("/admin") || path.startsWith("/api")) {
    return NextResponse.json({ error: "Rota não permitida para analytics." }, { status: 400 });
  }

  const rawIp = clientIp(req);
  const ipAddress = isIP(rawIp) ? rawIp : "Não identificado";
  const ua = req.headers.get("user-agent") ?? "";
  const device = parseVisitDevice(ua);
  const appMode = body.appMode === "app" ? "app" : "site";
  const now = new Date();

  await cleanupExpiredSiteVisits();
  await db.insert(siteVisits).values({
    visitorId: body.visitorId,
    ipAddress,
    path,
    appMode,
    deviceName: device.deviceName,
    deviceType: device.deviceType,
    browserName: device.browserName,
    browserVersion: device.browserVersion,
    osName: device.osName,
    osVersion: device.osVersion,
    consentedAt: now,
  });

  return NextResponse.json({ ok: true, retentionDays: SITE_VISIT_RETENTION_DAYS }, { status: 201 });
}

/** Apaga o histórico de um único navegador ao revogar consentimento. */
export async function DELETE(req: NextRequest) {
  const originError = originGuard(req);
  if (originError) return originError;
  const limited = rateLimited(req, "analytics-delete-own", 10);
  if (limited) return limited;
  if (bodyTooLarge(req, 2048)) {
    return NextResponse.json({ error: "Requisição muito grande." }, { status: 413 });
  }
  const body = await req.json().catch(() => null);
  if (!validVisitorId(body?.visitorId)) {
    return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  }
  const deleted = await db.delete(siteVisits).where(eq(siteVisits.visitorId, body.visitorId)).returning({ id: siteVisits.id });
  return NextResponse.json({ ok: true, deleted: deleted.length });
}
