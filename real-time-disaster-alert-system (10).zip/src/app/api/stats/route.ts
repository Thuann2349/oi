import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { alerts } from "@/db/schema";
import { and, count, desc, eq, gte } from "drizzle-orm";
import { getIngestState, getConnectionCount } from "@/lib/emitter";
import { rateLimited } from "@/lib/security";

export const dynamic = "force-dynamic";

type AdminMeta = { reach?: number; dispatchMs?: number };

export async function GET(req: NextRequest) {
  const limited = rateLimited(req, "stats", 120);
  if (limited) return limited;
  const since72h = new Date(Date.now() - 72 * 3600 * 1000);

  const [totalAlerts] = await db
    .select({ v: count() })
    .from(alerts)
    .where(gte(alerts.eventTime, since72h));
  const [highPlus] = await db
    .select({ v: count() })
    .from(alerts)
    .where(and(gte(alerts.eventTime, since72h), gte(alerts.severity, 3)));
  // Disparos públicos da administração (100% sem dados pessoais)
  const adminAlerts = await db
    .select({ metadata: alerts.metadata })
    .from(alerts)
    .where(eq(alerts.source, "Administração VIGIA"))
    .orderBy(desc(alerts.eventTime))
    .limit(200);

  let totalReached = 0;
  let dispatchSamples = 0;
  let dispatchSum = 0;
  for (const row of adminAlerts) {
    const meta = (row.metadata ?? {}) as AdminMeta;
    if (typeof meta.reach === "number") totalReached += meta.reach;
    if (typeof meta.dispatchMs === "number" && meta.dispatchMs > 0) {
      dispatchSum += meta.dispatchMs;
      dispatchSamples++;
    }
  }

  const leadRows = await db
    .select({ lead: alerts.leadMinutes })
    .from(alerts)
    .where(gte(alerts.eventTime, since72h))
    .limit(500);
  const avgLead = leadRows.length
    ? Math.round(leadRows.reduce((acc, r) => acc + r.lead, 0) / leadRows.length)
    : 0;

  return NextResponse.json({
    alertsActive72h: totalAlerts?.v ?? 0,
    alertsHighPlus: highPlus?.v ?? 0,
    connectedNow: getConnectionCount(),
    publicBroadcasts: adminAlerts.length,
    totalReached,
    avgDispatchMs: dispatchSamples ? Math.round(dispatchSum / dispatchSamples) : 0,
    avgLeadMinutes: avgLead,
    ingest: getIngestState(),
  });
}
