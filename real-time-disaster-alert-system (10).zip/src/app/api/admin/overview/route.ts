import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { alerts } from "@/db/schema";
import { count, desc, eq, gte } from "drizzle-orm";
import { isAdmin } from "@/lib/auth";
import { getIngestState, getConnectionCount } from "@/lib/emitter";
import { rateLimited } from "@/lib/security";

export const dynamic = "force-dynamic";

type AdminMeta = { reach?: number; dispatchMs?: number; impactRadiusKm?: number; publicBroadcast?: boolean };

/**
 * Visão geral do Painel de Comando.
 * NENHUM dado pessoal é coletado, armazenado ou exibido aqui: apenas números
 * agregados e anônimos (conexões ao vivo, alcance e tempo de disparo).
 */
export async function GET(req: NextRequest) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Acesso não autorizado." }, { status: 401 });
  }
  const limited = rateLimited(req, "admin-overview", 240);
  if (limited) return limited;

  const since72h = new Date(Date.now() - 72 * 3600 * 1000);
  const [totalAlerts] = await db.select({ v: count() }).from(alerts).where(gte(alerts.eventTime, since72h));
  const [adminCount] = await db.select({ v: count() }).from(alerts).where(eq(alerts.source, "Administração VIGIA"));

  const recentAlerts = await db.select().from(alerts).orderBy(desc(alerts.eventTime)).limit(25);

  const adminAlerts = await db
    .select()
    .from(alerts)
    .where(eq(alerts.source, "Administração VIGIA"))
    .orderBy(desc(alerts.eventTime))
    .limit(100);

  let totalReached = 0;
  let dispatchSum = 0;
  let dispatchSamples = 0;
  const dispatches = adminAlerts.slice(0, 15).map((a) => {
    const meta = (a.metadata ?? {}) as AdminMeta;
    return {
      id: a.id,
      title: a.title,
      type: a.type,
      severity: a.severity,
      locationName: a.locationName,
      eventTime: a.eventTime,
      reach: typeof meta.reach === "number" ? meta.reach : 0,
      dispatchMs: typeof meta.dispatchMs === "number" ? meta.dispatchMs : 0,
      impactRadiusKm: typeof meta.impactRadiusKm === "number" ? meta.impactRadiusKm : 0,
    };
  });
  for (const a of adminAlerts) {
    const meta = (a.metadata ?? {}) as AdminMeta;
    if (typeof meta.reach === "number") totalReached += meta.reach;
    if (typeof meta.dispatchMs === "number" && meta.dispatchMs > 0) {
      dispatchSum += meta.dispatchMs;
      dispatchSamples++;
    }
  }

  return NextResponse.json({
    connectedNow: getConnectionCount(),
    alertsActive72h: totalAlerts?.v ?? 0,
    adminAlertsTotal: adminCount?.v ?? 0,
    totalReached,
    avgDispatchMs: dispatchSamples ? Math.round(dispatchSum / dispatchSamples) : 0,
    ingest: getIngestState(),
    alerts: recentAlerts,
    dispatches,
  });
}
