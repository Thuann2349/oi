import { NextRequest, NextResponse } from "next/server";
import { isAdmin } from "@/lib/auth";
import { createAdminBroadcast } from "@/lib/ingest";
import { ALERT_TYPES } from "@/lib/meta";
import { bodyTooLarge, originGuard, rateLimited } from "@/lib/security";

export const dynamic = "force-dynamic";

/**
 * DISPARO DO ADMIN — 1 clique, sem pedir nenhum dado pessoal:
 * o alerta público aparece na hora para todos os visitantes conectados.
 */
export async function POST(req: NextRequest) {
  const originError = originGuard(req);
  if (originError) return originError;
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Acesso não autorizado." }, { status: 401 });
  }
  const limited = rateLimited(req, "admin-broadcast", 20);
  if (limited) return limited;
  if (bodyTooLarge(req, 16384)) {
    return NextResponse.json({ error: "Requisição muito grande." }, { status: 413 });
  }

  const body = await req.json().catch(() => null);
  if (!body) return NextResponse.json({ error: "Corpo inválido." }, { status: 400 });

  const type = ALERT_TYPES[String(body.type)] ? String(body.type) : "outro";
  const title = String(body.title ?? "").trim().slice(0, 220);
  const description = String(body.description ?? "").trim().slice(0, 1200);
  const latitude = Number(body.latitude);
  const longitude = Number(body.longitude);
  if (!title) {
    return NextResponse.json({ error: "Informe o título do alerta." }, { status: 400 });
  }
  if (
    !Number.isFinite(latitude) || !Number.isFinite(longitude) ||
    latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180
  ) {
    return NextResponse.json({ error: "Localização inválida." }, { status: 400 });
  }

  const result = await createAdminBroadcast({
    type,
    severity: Math.min(4, Math.max(1, Number(body.severity ?? 3) || 3)),
    title,
    description: description || "Alerta emitido pela Administração VIGIA. Siga as orientações de segurança.",
    latitude,
    longitude,
    locationName: String(body.locationName ?? "").slice(0, 220) || `${latitude.toFixed(3)}, ${longitude.toFixed(3)}`,
    impactRadiusKm: Math.min(5000, Math.max(10, Number(body.impactRadiusKm ?? 150) || 150)),
    publicBroadcast: body.publicBroadcast !== false,
  });

  return NextResponse.json(result, { status: 201 });
}
