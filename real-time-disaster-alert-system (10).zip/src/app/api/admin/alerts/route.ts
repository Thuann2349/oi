import { NextRequest, NextResponse } from "next/server";
import { isAdmin } from "@/lib/auth";
import { deleteAlertById } from "@/lib/ingest";
import { originGuard, rateLimited } from "@/lib/security";

export const dynamic = "force-dynamic";

export async function DELETE(req: NextRequest) {
  const originError = originGuard(req);
  if (originError) return originError;
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Acesso não autorizado." }, { status: 401 });
  }
  const limited = rateLimited(req, "admin-alerts-delete", 30);
  if (limited) return limited;
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!Number.isInteger(id) || id <= 0) {
    return NextResponse.json({ error: "id inválido" }, { status: 400 });
  }
  const ok = await deleteAlertById(id);
  return NextResponse.json({ ok });
}
