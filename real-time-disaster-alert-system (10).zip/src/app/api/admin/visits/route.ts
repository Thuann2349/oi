import { NextRequest, NextResponse } from "next/server";
import { and, count, desc, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { siteVisits } from "@/db/schema";
import { isAdmin } from "@/lib/auth";
import { clampInt, originGuard, rateLimited } from "@/lib/security";
import { cleanupExpiredSiteVisits } from "@/lib/visit-retention";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Acesso não autorizado." }, { status: 401 });
  const limited = rateLimited(req, "admin-visits", 120);
  if (limited) return limited;

  await cleanupExpiredSiteVisits();
  const { searchParams } = new URL(req.url);
  const days = clampInt(searchParams.get("days"), 1, 30, 7);
  const page = clampInt(searchParams.get("page"), 1, 10000, 1);
  const limit = 100;
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const condition = gte(siteVisits.createdAt, since);

  const [totalRow] = await db.select({ value: count() }).from(siteVisits).where(condition);
  const [visitorsRow] = await db
    .select({ value: sql<number>`count(distinct ${siteVisits.visitorId})` })
    .from(siteVisits)
    .where(condition);
  const [ipsRow] = await db
    .select({ value: sql<number>`count(distinct ${siteVisits.ipAddress})` })
    .from(siteVisits)
    .where(condition);
  const [appRow] = await db
    .select({ value: count() })
    .from(siteVisits)
    .where(and(condition, eq(siteVisits.appMode, "app")));
  const [siteRow] = await db
    .select({ value: count() })
    .from(siteVisits)
    .where(and(condition, eq(siteVisits.appMode, "site")));

  const rows = await db
    .select({
      id: siteVisits.id,
      visitorId: siteVisits.visitorId,
      ipAddress: siteVisits.ipAddress,
      path: siteVisits.path,
      appMode: siteVisits.appMode,
      deviceName: siteVisits.deviceName,
      deviceType: siteVisits.deviceType,
      browserName: siteVisits.browserName,
      browserVersion: siteVisits.browserVersion,
      osName: siteVisits.osName,
      osVersion: siteVisits.osVersion,
      consentedAt: siteVisits.consentedAt,
      createdAt: siteVisits.createdAt,
    })
    .from(siteVisits)
    .where(condition)
    .orderBy(desc(siteVisits.createdAt))
    .limit(limit)
    .offset((page - 1) * limit);

  const browserRows = await db
    .select({ name: siteVisits.browserName, value: count() })
    .from(siteVisits)
    .where(condition)
    .groupBy(siteVisits.browserName)
    .orderBy(desc(count()))
    .limit(8);
  const deviceRows = await db
    .select({ name: siteVisits.deviceType, value: count() })
    .from(siteVisits)
    .where(condition)
    .groupBy(siteVisits.deviceType)
    .orderBy(desc(count()));

  return NextResponse.json({
    rangeDays: days,
    page,
    pageSize: limit,
    total: totalRow?.value ?? 0,
    pages: Math.max(1, Math.ceil((totalRow?.value ?? 0) / limit)),
    uniqueVisitors: Number(visitorsRow?.value ?? 0),
    uniqueIps: Number(ipsRow?.value ?? 0),
    appVisits: appRow?.value ?? 0,
    siteVisits: siteRow?.value ?? 0,
    browsers: browserRows,
    devices: deviceRows,
    visits: rows,
    retentionDays: 30,
  }, { headers: { "Cache-Control": "no-store, private" } });
}

export async function DELETE(req: NextRequest) {
  const originError = originGuard(req);
  if (originError) return originError;
  if (!(await isAdmin())) return NextResponse.json({ error: "Acesso não autorizado." }, { status: 401 });
  const limited = rateLimited(req, "admin-visits-delete", 3);
  if (limited) return limited;
  const deleted = await db.delete(siteVisits).returning({ id: siteVisits.id });
  return NextResponse.json({ ok: true, deleted: deleted.length });
}
