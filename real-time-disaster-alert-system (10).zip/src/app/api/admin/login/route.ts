import { NextRequest, NextResponse } from "next/server";
import { ADMIN_COOKIE, adminToken, isValidKey } from "@/lib/auth";
import {
  clientIp, bodyTooLarge, originGuard,
  loginLockSeconds, recordLoginFailure, clearLoginFailures,
} from "@/lib/security";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const originError = originGuard(req);
  if (originError) return originError;
  if (bodyTooLarge(req, 4096)) {
    return NextResponse.json({ error: "Requisição inválida." }, { status: 413 });
  }

  const ip = clientIp(req);
  const lockedFor = loginLockSeconds(ip);
  if (lockedFor > 0) {
    return NextResponse.json(
      { error: `Muitas tentativas incorretas. Acesso bloqueado por ${Math.ceil(lockedFor / 60)} min.` },
      { status: 429, headers: { "Retry-After": String(lockedFor) } },
    );
  }

  const body = await req.json().catch(() => null);
  const key = String(body?.key ?? "");
  if (!isValidKey(key)) {
    recordLoginFailure(ip);
    return NextResponse.json({ error: "Chave de acesso inválida." }, { status: 401 });
  }

  clearLoginFailures(ip);
  const res = NextResponse.json({ ok: true });
  res.cookies.set(ADMIN_COOKIE, adminToken(), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 4, // 4 horas
  });
  return res;
}

export async function DELETE() {
  const res = NextResponse.json({ ok: true });
  res.cookies.set(ADMIN_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
  return res;
}
