import Link from "next/link";
import { db } from "@/db";
import { alerts } from "@/db/schema";
import { and, desc, eq, gte } from "drizzle-orm";
import { Siren, MapPin } from "lucide-react";
import { severityMeta, typeLabel, timeAgoPt, formatDateTimePt, ALERT_TYPES } from "@/lib/meta";
import { TypeIcon } from "@/components/TypeIcon";

export const dynamic = "force-dynamic";

type SearchParams = Promise<{ type?: string; sev?: string }>;

export default async function AlertasPage({ searchParams }: { searchParams: SearchParams }) {
  const { type, sev } = await searchParams;
  const minSev = Number(sev ?? 0);
  const conds = [];
  if (type) conds.push(eq(alerts.type, type));
  if (minSev > 0) conds.push(gte(alerts.severity, minSev));

  const rows = await db
    .select()
    .from(alerts)
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(desc(alerts.eventTime))
    .limit(200);

  const filterLink = (params: Record<string, string>) => {
    const p = new URLSearchParams(params);
    const s = p.toString();
    return s ? `/alertas?${s}` : "/alertas";
  };

  return (
    <div className="mx-auto max-w-[1200px] px-4 py-8 sm:px-6">
      <h1 className="flex items-center gap-3 text-3xl font-black tracking-tight">
        <Siren className="h-8 w-8 text-red-500" /> Todos os alertas
      </h1>
      <p className="mt-2 text-zinc-400">
        Registro completo de eventos detectados pela rede VIGIA (USGS, NASA EONET e sensores próprios), atualizados a cada 45 segundos.
      </p>

      <div className="mt-6 flex flex-wrap items-center gap-2">
        <Link href="/alertas" className={`rounded-full px-3 py-1.5 text-xs font-semibold ${!type && !minSev ? "bg-cyan-500 text-zinc-950" : "bg-zinc-800 text-zinc-300 hover:bg-zinc-700"}`}>
          Todos
        </Link>
        {Object.entries(ALERT_TYPES).map(([value, { label }]) => (
          <Link
            key={value}
            href={filterLink({ type: value, ...(minSev ? { sev: String(minSev) } : {}) })}
            className={`rounded-full px-3 py-1.5 text-xs font-semibold ${type === value ? "bg-cyan-500 text-zinc-950" : "bg-zinc-800 text-zinc-300 hover:bg-zinc-700"}`}
          >
            {label}
          </Link>
        ))}
        <span className="mx-1 h-5 w-px bg-zinc-800" />
        {[3, 4].map((s) => (
          <Link
            key={s}
            href={filterLink({ ...(type ? { type } : {}), sev: String(s) })}
            className={`rounded-full px-3 py-1.5 text-xs font-bold ${minSev === s ? "bg-red-600 text-white" : "bg-zinc-800 text-red-300 hover:bg-zinc-700"}`}
          >
            {s === 3 ? "Graves+" : "Só extremos"}
          </Link>
        ))}
        <span className="ml-auto text-sm tabular-nums text-zinc-500">{rows.length} eventos</span>
      </div>

      <div className="mt-4 overflow-hidden rounded-xl border border-zinc-800">
        {rows.length === 0 && (
          <p className="bg-zinc-900/60 p-6 text-sm text-zinc-500">Nenhum alerta com esses filtros no momento.</p>
        )}
        <div className="divide-y divide-zinc-800 bg-zinc-900/40">
          {rows.map((a) => {
            const meta = severityMeta(a.severity);
            return (
              <div key={a.id} className="flex gap-3 px-4 py-3.5 transition-colors hover:bg-zinc-900">
                <span className="w-1 shrink-0 rounded-full" style={{ background: meta.color }} />
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg" style={{ background: `${meta.color}22`, color: meta.color }}>
                  <TypeIcon type={a.type} className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="font-semibold leading-snug">{a.title}</p>
                  <p className="mt-0.5 line-clamp-2 text-sm text-zinc-500">{a.description}</p>
                  <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-1 text-xs text-zinc-500">
                    <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {a.latitude.toFixed(2)}, {a.longitude.toFixed(2)}</span>
                    <span>{typeLabel(a.type)}</span>
                    <span>{formatDateTimePt(a.eventTime)} ({timeAgoPt(a.eventTime)})</span>
                    <span className="rounded bg-zinc-800 px-1.5 py-0.5 font-medium text-zinc-400">{a.source}</span>
                    {a.magnitude != null && <span>Mag. {a.magnitude}</span>}
                  </div>
                </div>
                <div className="hidden shrink-0 text-right sm:block">
                  <span className="inline-block rounded-full px-2.5 py-1 text-xs font-black uppercase" style={{ background: `${meta.color}22`, color: meta.color }}>
                    {meta.label}
                  </span>
                  {a.leadMinutes > 0 && (
                    <p className="mt-1.5 text-xs font-semibold text-emerald-400">{a.leadMinutes} min antes do oficial</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
