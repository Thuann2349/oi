import { db } from "@/db";
import { alerts } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { Megaphone, Timer, Users, ShieldCheck, MapPin } from "lucide-react";
import { severityMeta, typeLabel, timeAgoPt, formatDateTimePt } from "@/lib/meta";
import { TypeIcon } from "@/components/TypeIcon";

export const dynamic = "force-dynamic";

type AdminMeta = { reach?: number; dispatchMs?: number; impactRadiusKm?: number };

export default async function NotificacoesPage() {
  const rows = await db
    .select()
    .from(alerts)
    .where(eq(alerts.source, "Administração VIGIA"))
    .orderBy(desc(alerts.eventTime))
    .limit(100);

  let totalReached = 0;
  let dispatchSum = 0;
  let dispatchSamples = 0;
  for (const a of rows) {
    const meta = (a.metadata ?? {}) as AdminMeta;
    if (typeof meta.reach === "number") totalReached += meta.reach;
    if (typeof meta.dispatchMs === "number" && meta.dispatchMs > 0) {
      dispatchSum += meta.dispatchMs;
      dispatchSamples++;
    }
  }
  const avgDispatch = dispatchSamples ? Math.round(dispatchSum / dispatchSamples) : 0;

  return (
    <div className="mx-auto max-w-[1200px] px-4 py-8 sm:px-6">
      <h1 className="flex items-center gap-3 text-3xl font-black tracking-tight">
        <Megaphone className="h-8 w-8 text-cyan-400" /> Registro de disparos públicos
      </h1>
      <p className="mt-2 max-w-3xl text-zinc-400">
        Cada disparo da administração aparece aqui com <strong className="text-zinc-100">quantas pessoas conectadas
        foram alcançadas</strong> e em <strong className="text-zinc-100">quantos milissegundos</strong>. Nenhum disparo
        usa nome, telefone ou e-mail de ninguém — é transmissão pública e anônima.
      </p>

      <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
          <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-zinc-500">
            <Megaphone className="h-4 w-4 text-cyan-400" /> Disparos realizados
          </p>
          <p className="mt-1 text-3xl font-black tabular-nums">{rows.length}</p>
        </div>
        <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
          <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-zinc-500">
            <Users className="h-4 w-4 text-emerald-400" /> Pessoas alcançadas (soma)
          </p>
          <p className="mt-1 text-3xl font-black tabular-nums text-emerald-400">{totalReached}</p>
          <p className="text-[11px] text-zinc-500">conexões ao vivo no momento de cada disparo</p>
        </div>
        <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
          <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-zinc-500">
            <Timer className="h-4 w-4 text-yellow-400" /> Tempo médio de disparo
          </p>
          <p className="mt-1 text-3xl font-black tabular-nums">{avgDispatch} ms</p>
          <p className="text-[11px] text-zinc-500">do clique do admin até o ar</p>
        </div>
      </div>

      <div className="mt-6 flex flex-col gap-2">
        {rows.length === 0 && (
          <p className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-6 text-sm leading-relaxed text-zinc-500">
            Ainda não houve disparos da administração. Entre no{" "}
            <strong className="text-zinc-300">Painel de Comando (Admin)</strong> e dispare o primeiro alerta —
            ele aparecerá aqui e na tela de todos os visitantes, sem pedir nenhum dado pessoal.
          </p>
        )}
        {rows.map((a) => {
          const sev = severityMeta(a.severity);
          const meta = (a.metadata ?? {}) as AdminMeta;
          return (
            <article key={a.id} className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="flex items-center gap-1 font-bold text-emerald-400">
                  <ShieldCheck className="h-3.5 w-3.5" /> DISPARO PÚBLICO
                </span>
                <span className="rounded bg-zinc-800 px-2 py-0.5 font-semibold uppercase tracking-wide text-zinc-300">
                  {typeLabel(a.type)}
                </span>
                <span className="rounded px-2 py-0.5 font-bold uppercase" style={{ background: `${sev.color}22`, color: sev.color }}>
                  {sev.label}
                </span>
                <span className="ml-auto tabular-nums text-zinc-500">
                  {formatDateTimePt(a.eventTime)} ({timeAgoPt(a.eventTime)})
                </span>
              </div>

              <div className="mt-2 flex gap-3">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg" style={{ background: `${sev.color}22`, color: sev.color }}>
                  <TypeIcon type={a.type} className="h-5 w-5" />
                </span>
                <div className="min-w-0">
                  <p className="font-semibold leading-snug">{a.title}</p>
                  <p className="mt-0.5 line-clamp-2 text-sm text-zinc-500">{a.description}</p>
                </div>
              </div>

              <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-zinc-500">
                <span className="flex items-center gap-1">
                  <MapPin className="h-3 w-3" /> {a.locationName || `${a.latitude.toFixed(2)}, ${a.longitude.toFixed(2)}`}
                  {meta.impactRadiusKm ? ` • raio ${meta.impactRadiusKm} km` : ""}
                </span>
                <span>
                  Alcançou <strong className="tabular-nums text-emerald-400">{meta.reach ?? 0} pessoa(s) conectada(s)</strong>
                </span>
                <span>
                  Disparo em <strong className="tabular-nums text-zinc-200">{meta.dispatchMs ?? 0} ms</strong>
                </span>
                <span className="font-semibold text-zinc-400">Dados pessoais usados: nenhum</span>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
