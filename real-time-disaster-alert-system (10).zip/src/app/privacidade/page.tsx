import type { Metadata } from "next";
import { ShieldCheck, Database, Clock3, Smartphone, EyeOff, LockKeyhole } from "lucide-react";
import PrivacyControls from "@/components/PrivacyControls";

export const metadata: Metadata = {
  title: "Privacidade e analytics | VIGIA",
  description: "Como o VIGIA trata dados de acesso e como alterar o consentimento de analytics.",
};

export default function PrivacidadePage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <p className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-cyan-400"><ShieldCheck className="h-4 w-4" /> Privacidade e transparência</p>
      <h1 className="mt-2 text-3xl font-black tracking-tight">Seus dados, sua escolha</h1>
      <p className="mt-3 max-w-3xl leading-relaxed text-zinc-400">
        O mapa e os alertas públicos funcionam sem cadastro e sem analytics. O registro de IP e dados de navegador só começa
        se você escolher <strong className="text-zinc-200">“Permitir analytics”</strong> no aviso de privacidade.
      </p>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        {[
          { icon: Database, title: "O que é registrado", text: "Após consentimento: endereço IP, rota visitada, horário, modo site/app, categoria/modelo de aparelho, navegador e sistema operacional inferidos do User-Agent. O User-Agent bruto não é salvo." },
          { icon: EyeOff, title: "O que não coletamos", text: "Nome, e-mail, telefone, GPS, lista de contatos ou nome pessoal configurado no aparelho. A categoria do aparelho é uma estimativa que o navegador informa." },
          { icon: Clock3, title: "Retenção", text: "Os registros expiram e são apagados automaticamente após 30 dias. O Admin também pode apagar o histórico antes desse prazo." },
          { icon: LockKeyhole, title: "Acesso restrito", text: "O IP completo só aparece em /admin/acessos, protegido por login administrativo. Não é exibido no site público nem enviado a serviços de publicidade." },
          { icon: Smartphone, title: "Site ou app", text: "O VIGIA é um PWA: o mesmo site pode ser instalado na tela inicial de celular e computador. Registramos apenas se a página estava em modo app ou navegador, após consentimento." },
          { icon: ShieldCheck, title: "Revogação", text: "Você pode revogar nesta página. O navegador deixa de enviar novos eventos e solicita a exclusão dos registros associados ao identificador anônimo local." },
        ].map(({ icon: Icon, title, text }) => (
          <article key={title} className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
            <Icon className="h-5 w-5 text-cyan-400" />
            <h2 className="mt-2 font-bold">{title}</h2>
            <p className="mt-1 text-sm leading-relaxed text-zinc-400">{text}</p>
          </article>
        ))}
      </div>

      <div className="mt-5"><PrivacyControls /></div>
      <p className="mt-5 text-[11px] leading-relaxed text-zinc-600">
        Esta página descreve a funcionalidade técnica do projeto. Antes de uso comercial ou institucional, revise o tratamento de dados com o responsável de privacidade e adapte os procedimentos à legislação aplicável.
      </p>
    </div>
  );
}
