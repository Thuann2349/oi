import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    id: "/",
    name: "VIGIA — Alertas e Clima",
    short_name: "VIGIA",
    description: "Mapa de alertas, radar e previsão do tempo. Instale no celular ou computador.",
    start_url: "/",
    scope: "/",
    display: "standalone",
    display_override: ["standalone", "minimal-ui"],
    orientation: "any",
    background_color: "#09090b",
    theme_color: "#09090b",
    lang: "pt-BR",
    categories: ["weather", "utilities"],
    icons: [
      { src: "/vigia-icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/vigia-icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/vigia-icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
