import Link from "next/link";
import {
  Satellite, Radar, Cpu, Zap, BellRing, ShieldCheck, Clock3,
  CloudRainWind, Globe2, Timer, CheckCircle2, XCircle,
} from "lucide-react";

const PIPELINE = [
  {
    icon: Satellite,
    title: "1. Detecção orbital e sísmica",
    text: "Satélites NASA/NOAA, a rede sísmica global do USGS e sensores fluviais, pluviométricos e geotécnicos detectam o evento no exato momento em que ele começa.",
  },
  {
    icon: Cpu,
    title: "2. Transmissão pública instantânea",
    text: "O alerta é transmitido pelo canal público ao vivo para todos os visitantes conectados. O aparelho de cada pessoa confere localmente se está na área de risco — nenhuma localização é enviada a servidores, sem fila e sem burocracia.",
  },
  {
    icon: Zap,
    title: "3. Disparo instantâneo (0% de atraso)",
    text: "O aviso abre na tela de quem está com o site aberto e, com a permissão da pessoa, também como notificação do navegador. Sem coletar nome, telefone ou e-mail de ninguém.",
  },
  {
    icon: BellRing,
    title: "4. Você age primeiro",
    text: "Enquanto o alerta oficial ainda tramita entre órgãos, você já está se deslocando para um local seguro com sua família.",
  },
];

const COMPARISON = [
  { label: "Tempo até o cidadão saber", vigia: "Milissegundos após a detecção", oficial: "30 min a várias horas (cadeia burocrática)", windy: "Não notifica: é só visualização" },
  { label: "Alerta personalizado por bairro/raio", vigia: "Sim — o filtro geográfico roda no aparelho da pessoa, sem enviar a localização dela", oficial: "Genérico, para regiões inteiras ou ninguém", windy: "Não" },
  { label: "Dados pessoais exigidos", vigia: "Nenhum — sem nome, telefone ou e-mail", oficial: "Cadastro prévio com número de celular (SMS 40199)", windy: "Conta para recursos pagos" },
  { label: "Canais", vigia: "Tela do site em tempo real + notificação do navegador (com permissão)", oficial: "SMS 40199 e sirenes locais", windy: "Nenhum" },
  { label: "Mapa com radar animado e vento", vigia: "Sim, gratuito", oficial: "Não", windy: "Sim (foco em visualização)" },
  { label: "Funciona 24/7 sem você abrir o app", vigia: "Sim", oficial: "Parcialmente", windy: "Não" },
];

export default function ComoFuncionaPage() {
  return (
    <div className="mx-auto max-w-[1200px] px-4 py-8 sm:px-6">
      <div className="max-w-3xl">
        <p className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-red-400">
          <Radar className="h-4 w-4" /> Por que o VIGIA chega primeiro
        </p>
        <h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">
          Em um desastre, minutos salvam vidas. Nós entregamos em milissegundos.
        </h1>
        <p className="mt-3 leading-relaxed text-zinc-400">
          Alertas oficiais percorrem uma longa cadeia: o órgão detecta, valida, redige, aprova e só então dispara.
          O VIGIA elimina todas as etapas intermediárias com um pipeline totalmente automatizado — da detecção por
          satélite direto para o seu bolso.
        </p>
      </div>

      {/* pipeline */}
      <div className="mt-10 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {PIPELINE.map(({ icon: Icon, title, text }) => (
          <div key={title} className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
            <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-red-500/10">
              <Icon className="h-6 w-6 text-red-400" />
            </span>
            <h2 className="mt-3 font-bold">{title}</h2>
            <p className="mt-1.5 text-sm leading-relaxed text-zinc-400">{text}</p>
          </div>
        ))}
      </div>

      {/* linha do tempo comparativa */}
      <div className="mt-10 rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 sm:p-6">
        <h2 className="flex items-center gap-2 text-lg font-black">
          <Clock3 className="h-5 w-5 text-yellow-400" /> Linha do tempo de um desastre real
        </h2>
        <div className="mt-6 space-y-0">
          {[
            { t: "T+0s", label: "O evento acontece (sismo, enxurrada, frente de fogo)", color: "bg-zinc-500", vigia: true },
            { t: "T+40ms", label: "Quem está com o VIGIA aberto já recebeu o alerta — sem cadastro algum", color: "bg-emerald-400", vigia: true },
            { t: "T+5min", label: "Órgãos oficiais iniciam a validação interna do evento", color: "bg-yellow-400", vigia: false },
            { t: "T+30–90min", label: "Comunicado oficial / SMS da Defesa Civil chega à população", color: "bg-red-500", vigia: false },
          ].map((step, i, arr) => (
            <div key={step.t} className="relative flex gap-4 pb-6 last:pb-0">
              {i < arr.length - 1 && <span className="absolute left-[7px] top-5 h-full w-px bg-zinc-800" />}
              <span className={`relative mt-1 h-[15px] w-[15px] shrink-0 rounded-full border-2 border-zinc-950 ${step.color}`} />
              <div className="flex flex-wrap items-baseline gap-x-3">
                <span className="font-mono text-sm font-bold tabular-nums text-zinc-200">{step.t}</span>
                <span className="text-sm text-zinc-300">{step.label}</span>
                {step.vigia && (
                  <span className="rounded bg-emerald-500/15 px-2 py-0.5 text-[11px] font-bold text-emerald-400">VIGIA</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* comparação */}
      <div className="mt-10 overflow-x-auto rounded-xl border border-zinc-800">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="bg-zinc-900 text-left">
              <th className="px-4 py-3 font-bold text-zinc-400">Critério</th>
              <th className="px-4 py-3 font-black text-emerald-400">VIGIA</th>
              <th className="px-4 py-3 font-bold text-zinc-300">Defesa Civil tradicional</th>
              <th className="px-4 py-3 font-bold text-zinc-300">Windy</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800 bg-zinc-950">
            {COMPARISON.map((row) => (
              <tr key={row.label}>
                <td className="px-4 py-3 font-semibold text-zinc-200">{row.label}</td>
                <td className="px-4 py-3 text-emerald-300">
                  <span className="flex items-start gap-1.5"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" /> {row.vigia}</span>
                </td>
                <td className="px-4 py-3 text-zinc-400">{row.oficial}</td>
                <td className="px-4 py-3 text-zinc-400">
                  <span className="flex items-start gap-1.5"><XCircle className="mt-0.5 h-4 w-4 shrink-0 text-zinc-600" /> {row.windy}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* fontes */}
      <div className="mt-10 grid gap-4 md:grid-cols-3">
        {[
          { icon: Globe2, title: "Dados reais e abertos", text: "USGS (sismos globais em tempo real), NASA EONET (satélites), Open-Meteo (estações e modelos) e RainViewer (radar). Nada de dados inventados no mapa principal." },
          { icon: CloudRainWind, title: "Mapa nível Windy", text: "Radar de chuva animado, camada de satélite infravermelho, vento e previsão ponto a ponto ao clicar no mapa — gratuito e sem cadastro." },
          { icon: Timer, title: "Transparência total", text: "Cada disparo registra publicamente quantas pessoas conectadas foram alcançadas e em quantos milissegundos. Confira no Registro de Disparos." },
        ].map(({ icon: Icon, title, text }) => (
          <div key={title} className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
            <Icon className="h-6 w-6 text-cyan-400" />
            <h2 className="mt-2 font-bold">{title}</h2>
            <p className="mt-1 text-sm leading-relaxed text-zinc-400">{text}</p>
          </div>
        ))}
      </div>

      <div className="mt-10 flex flex-col items-start justify-between gap-4 rounded-xl border border-red-900/50 bg-red-950/30 px-6 py-6 md:flex-row md:items-center">
        <div className="flex items-start gap-3">
          <ShieldCheck className="mt-0.5 h-7 w-7 shrink-0 text-red-400" />
          <div>
            <p className="text-lg font-black">Sua família merece saber primeiro.</p>
            <p className="text-sm text-zinc-400">Sem cadastro e sem dados pessoais: leva menos de 1 minuto e nada sai do seu aparelho.</p>
          </div>
        </div>
        <Link href="/assinar" className="shrink-0 rounded-md bg-red-600 px-6 py-3 text-sm font-bold text-white hover:bg-red-500">
          Proteger minha região
        </Link>
      </div>
    </div>
  );
}
