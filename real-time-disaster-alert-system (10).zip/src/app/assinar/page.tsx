"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  BellRing, MapPin, CheckCircle2, Trash2, ShieldCheck, Zap,
  Search, HardDrive, EyeOff, Bell,
} from "lucide-react";
import { ALERT_TYPES } from "@/lib/meta";
import { AREAS_KEY, type AreaPref } from "@/components/PublicAlertListener";

type GeoResult = { name: string; state: string; country: string; latitude: number; longitude: number };

export default function AssinarPage() {
  const [areas, setAreas] = useState<AreaPref[]>([]);
  const [cityQuery, setCityQuery] = useState("");
  const [geoResults, setGeoResults] = useState<GeoResult[]>([]);
  const [city, setCity] = useState<GeoResult | null>(null);
  const [radiusKm, setRadiusKm] = useState(150);
  const [minSeverity, setMinSeverity] = useState(2);
  const [types, setTypes] = useState<string[]>([]);
  const [saved, setSaved] = useState(false);
  const [notifState, setNotifState] = useState<string>("default");
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(AREAS_KEY);
      if (raw) setAreas(JSON.parse(raw));
    } catch { /* sem áreas ainda */ }
    if (typeof Notification !== "undefined") setNotifState(Notification.permission);
  }, []);

  const persist = (next: AreaPref[]) => {
    setAreas(next);
    try { localStorage.setItem(AREAS_KEY, JSON.stringify(next)); } catch { /* armazenamento cheio */ }
  };

  const searchCity = (q: string) => {
    setCityQuery(q);
    setCity(null);
    if (debounce.current) clearTimeout(debounce.current);
    if (q.trim().length < 2) { setGeoResults([]); return; }
    debounce.current = setTimeout(async () => {
      try {
        const r = await fetch(`/api/geocode?q=${encodeURIComponent(q)}`);
        setGeoResults((await r.json()).results ?? []);
      } catch { setGeoResults([]); }
    }, 300);
  };

  const toggleType = (t: string) =>
    setTypes((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]));

  const saveArea = () => {
    if (!city) return;
    const area: AreaPref = {
      name: city.name,
      state: city.state,
      latitude: city.latitude,
      longitude: city.longitude,
      radiusKm,
      minSeverity,
      types,
    };
    persist([...areas, area]);
    setSaved(true);
    setCity(null);
    setCityQuery("");
    setTypes([]);
    setTimeout(() => setSaved(false), 4000);
  };

  const removeArea = (idx: number) => persist(areas.filter((_, i) => i !== idx));

  const enableNotifications = async () => {
    if (typeof Notification === "undefined") return;
    const perm = await Notification.requestPermission();
    setNotifState(perm);
  };

  const inputCls =
    "w-full rounded-md border border-zinc-700 bg-zinc-950 px-3 py-2.5 text-sm outline-none placeholder:text-zinc-600 focus:border-red-500";

  return (
    <div className="mx-auto max-w-[1200px] px-4 py-8 sm:px-6">
      <div className="mb-8 max-w-2xl">
        <h1 className="flex items-center gap-3 text-3xl font-black tracking-tight">
          <BellRing className="h-8 w-8 text-red-500" /> Proteja sua região — sem cadastro
        </h1>
        <p className="mt-2 text-zinc-400">
          Aqui você <strong className="text-zinc-100">não informa nome, telefone, e-mail nem cria conta</strong>.
          Você só diz qual região importa para você — e essa informação fica{" "}
          <strong className="text-zinc-100">salva apenas no seu aparelho</strong>. Quando a administração dispara
          um alerta, seu próprio navegador verifica (localmente) se ele é para a sua região e abre o aviso em tela cheia.
        </p>
        <div className="mt-4 flex flex-wrap gap-2 text-xs">
          <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1.5 font-semibold text-emerald-400">
            <EyeOff className="h-3.5 w-3.5" /> Zero dados pessoais coletados
          </span>
          <span className="flex items-center gap-1.5 rounded-full bg-zinc-800 px-3 py-1.5 font-semibold text-zinc-300">
            <HardDrive className="h-3.5 w-3.5" /> Sua região nunca sai deste aparelho
          </span>
          <span className="flex items-center gap-1.5 rounded-full bg-zinc-800 px-3 py-1.5 font-semibold text-zinc-300">
            <Zap className="h-3.5 w-3.5" /> Alerta em milissegundos
          </span>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 lg:col-span-3">
          <h2 className="text-sm font-black uppercase tracking-wider">1. Qual região você quer proteger?</h2>

          <label className="mb-1.5 mt-4 block text-xs font-bold uppercase tracking-wide text-zinc-400">Cidade</label>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
            <input
              value={cityQuery}
              onChange={(e) => searchCity(e.target.value)}
              placeholder="Digite sua cidade... (ex.: Porto Alegre)"
              className={`${inputCls} pl-9`}
            />
            {geoResults.length > 0 && !city && (
              <div className="absolute inset-x-0 top-full z-20 mt-1 overflow-hidden rounded-md border border-zinc-700 bg-zinc-900 shadow-2xl">
                {geoResults.map((r, i) => (
                  <button
                    type="button"
                    key={`${r.latitude}-${i}`}
                    onClick={() => { setCity(r); setCityQuery(`${r.name}${r.state ? `, ${r.state}` : ""} — ${r.country}`); setGeoResults([]); }}
                    className="flex w-full items-center gap-2 px-3 py-2.5 text-left text-sm hover:bg-zinc-800"
                  >
                    <MapPin className="h-4 w-4 shrink-0 text-red-400" />
                    {r.name}{r.state ? `, ${r.state}` : ""} <span className="text-zinc-500">— {r.country}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
          {city && (
            <p className="mt-1.5 flex items-center gap-1 text-xs text-emerald-400">
              <CheckCircle2 className="h-3.5 w-3.5" /> Região definida: {city.name} ({city.latitude.toFixed(2)}, {city.longitude.toFixed(2)}) — fica só neste aparelho.
            </p>
          )}

          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 flex justify-between text-xs font-bold uppercase tracking-wide text-zinc-400">
                Raio de proteção <span className="tabular-nums text-zinc-200">{radiusKm} km</span>
              </label>
              <input type="range" min={25} max={2000} step={25} value={radiusKm} onChange={(e) => setRadiusKm(Number(e.target.value))} className="w-full accent-red-500" />
              <p className="text-[11px] text-zinc-500">Alertas dentro deste raio abrem em tela cheia com sirene. Fora dele, você vê só um aviso discreto.</p>
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-zinc-400">Gravidade mínima</label>
              <select value={minSeverity} onChange={(e) => setMinSeverity(Number(e.target.value))} className={inputCls}>
                <option value={1}>Qualquer evento</option>
                <option value={2}>Moderado ou pior</option>
                <option value={3}>Somente graves</option>
                <option value={4}>Somente extremos</option>
              </select>
            </div>
          </div>

          <label className="mb-1.5 mt-5 block text-xs font-bold uppercase tracking-wide text-zinc-400">
            Tipos de desastre <span className="font-normal normal-case text-zinc-500">(nenhum marcado = todos)</span>
          </label>
          <div className="flex flex-wrap gap-2">
            {Object.entries(ALERT_TYPES).map(([value, { label }]) => (
              <button
                type="button"
                key={value}
                onClick={() => toggleType(value)}
                className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
                  types.includes(value) ? "bg-red-600 text-white" : "bg-zinc-800 text-zinc-400 hover:text-zinc-100"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <button
            onClick={saveArea}
            disabled={!city}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-md bg-red-600 px-4 py-3 text-sm font-black uppercase tracking-wide text-white transition-colors hover:bg-red-500 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <ShieldCheck className="h-4 w-4" /> Ativar proteção desta região (sem cadastro)
          </button>
          {saved && (
            <p className="mt-3 flex gap-2 rounded-md border border-emerald-800 bg-emerald-950/50 px-3 py-2 text-sm text-emerald-300">
              <CheckCircle2 className="h-5 w-5 shrink-0" /> Região protegida! Mantenha o VIGIA aberto em uma aba — o alerta chega em milissegundos, sem você ter informado nenhum dado.
            </p>
          )}

          <div className="mt-6 rounded-lg border border-zinc-800 bg-zinc-950 p-4">
            <h3 className="text-sm font-black uppercase tracking-wider">2. (Opcional) Notificação do navegador</h3>
            <p className="mt-1 text-sm leading-relaxed text-zinc-400">
              Autorize as notificações do navegador para ser avisado mesmo com a aba em segundo plano.
              Isso também <strong className="text-zinc-200">não coleta nenhum dado</strong> — é uma permissão local do seu navegador.
            </p>
            {notifState === "granted" ? (
              <p className="mt-3 flex items-center gap-2 text-sm font-semibold text-emerald-400">
                <CheckCircle2 className="h-4 w-4" /> Notificações do navegador ativadas neste aparelho.
              </p>
            ) : (
              <button
                onClick={enableNotifications}
                className="mt-3 flex items-center gap-2 rounded-md bg-cyan-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-cyan-500"
              >
                <Bell className="h-4 w-4" /> Ativar notificações do navegador
              </button>
            )}
            {notifState === "denied" && (
              <p className="mt-2 text-xs text-red-300">O navegador bloqueou as notificações. Você ainda recebe os alertas em tela cheia com a aba aberta.</p>
            )}
          </div>
        </div>

        <div className="lg:col-span-2">
          <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-zinc-300">
            Minhas regiões protegidas ({areas.length})
          </h2>
          <div className="flex flex-col gap-2">
            {areas.length === 0 && (
              <p className="rounded-lg border border-dashed border-zinc-800 bg-zinc-950 p-4 text-sm leading-relaxed text-zinc-500">
                Nenhuma região configurada. Sem região definida, <strong className="text-zinc-300">todos</strong> os alertas
                públicos abrem em tela cheia para você. Defina sua cidade ao lado para receber em tela cheia só o que for perto de você.
              </p>
            )}
            {areas.map((a, i) => (
              <div key={`${a.latitude}-${i}`} className="rounded-lg border border-zinc-800 bg-zinc-900/60 p-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="flex items-center gap-1.5 truncate text-sm font-bold">
                      <MapPin className="h-4 w-4 shrink-0 text-red-400" /> {a.name}{a.state ? `, ${a.state}` : ""}
                    </p>
                    <p className="mt-0.5 text-xs text-zinc-500">
                      Raio de {a.radiusKm} km • gravidade mínima {a.minSeverity} • {a.types.length ? `${a.types.length} tipo(s)` : "todos os tipos"}
                    </p>
                    <p className="mt-0.5 flex items-center gap-1 text-[11px] text-zinc-600">
                      <HardDrive className="h-3 w-3" /> salvo somente neste aparelho
                    </p>
                  </div>
                  <button onClick={() => removeArea(i)} className="shrink-0 rounded bg-zinc-800 p-1.5 text-zinc-400 hover:bg-red-950 hover:text-red-400" aria-label="Remover região">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 rounded-lg border border-emerald-900/60 bg-emerald-950/30 p-4">
            <p className="flex items-center gap-2 text-sm font-bold text-emerald-300">
              <ShieldCheck className="h-4 w-4" /> Como funciona sem cadastro?
            </p>
            <ul className="mt-2 list-disc space-y-1 pl-5 text-xs leading-relaxed text-emerald-100/70">
              <li>A administração dispara o alerta para <strong>todos</strong> os visitantes conectados ao mesmo tempo.</li>
              <li>Seu navegador compara o local do alerta com suas regiões — <strong>no seu aparelho</strong>.</li>
              <li>Se for perto de você: modal em tela cheia + sirene. Se for longe: avisozinho discreto no canto.</li>
              <li>Nenhum servidor sabe quem você é, onde você mora ou qual é o seu telefone. Não há o que vazar.</li>
            </ul>
            <Link href="/" className="mt-3 inline-block rounded-md bg-emerald-600 px-3 py-2 text-xs font-bold text-white hover:bg-emerald-500">
              Ir para o painel ao vivo
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
