import { db } from "@/db";
import { alerts } from "@/db/schema";
import { count, desc, eq, gte } from "drizzle-orm";
import {
  BarChart3, Activity, Database, Globe2, Satellite, Send, Siren, Timer, Users,
} from "lucide-react";
import { getConnectionCount, getIngestState } from "@/lib/emitter";
import { severityMeta, typeLabel, ALERT_TYPES, timeAgoPt, formatDateTimePt } from "@/lib/meta";
import AutoRefresh from "@/components/AutoRefresh";

export const dynamic = "force-dynamic";

type AdminMeta = { reach?: number; dispatchMs?: number; impactRadiusKm?: number };

export default async function MetricasPage() {
  const now = Date.now();
  const since24h = new Date(now - 24 * 3600 * 1000);
  const since14d = new Date(now - 14 * 24 * 3600 * 1000);

  // latência real do banco, medida agora
  const dbT0 = Date.now();
  const [totalRow] = await db.select({ v: count() }).from(alerts);
  const dbLatencyMs = Date.now() - dbT0;

  const [last24Row] = await db.select({ v: count() }).from(alerts).where(gte(alerts.eventTime, since24h));
  const highCount = await db
    .select({ severity: alerts.severity, v: count() })
    .from(alerts)
    .where(gte(alerts.severity, 3))
    .groupBy(alerts.severity);
  const highTotal = highCount.reduce((acc, r) => acc + r.v, 0);

  const byType = await db
    .select({ type: alerts.type, v: count() })
    .from(alerts)
    .groupBy(alerts.type)
    .orderBy(desc(count()));
  const bySeverity = await db
    .select({ severity: alerts.severity, v: count() })
    .from(alerts)
    .groupBy(alerts.severity)
    .orderBy(alerts.severity);
  const bySource = await db
    .select({ source: alerts.source, v: count() })
    .from(alerts)
    .groupBy(alerts.source)
    .orderBy(desc(count()));

  const recent14 = await db
    .select({ eventTime: alerts.eventTime })
    .from(alerts)
    .where(gte(alerts.eventTime, since14d))
    .limit(8000);
  const dayBuckets = new Map<string, number>();
  for (let i = 13; i >= 0; i--) {
    const d = new Date(now - i * 24 * 3600 * 1000);
    dayBuckets.set(d.toISOString().slice(0, 10), 0);
  }
  for (const r of recent14) {
    const key = new Date(r.eventTime).toISOString().slice(0, 10);
    if (dayBuckets.has(key)) dayBuckets.set(key, (dayBuckets.get(key) ?? 0) + 1);
  }
  const days = [...dayBuckets.entries()];
  const maxDay = Math.max(1, ...days.map(([, v]) => v));

  const adminAlerts = await db
    .select()
    .from(alerts)
    .where(eq(alerts.source, "Administração VIGIA"))
    .orderBy(desc(alerts.eventTime))
    .limit(100);
  let totalReached = 0, dispatchSum = 0, dispatchSamples = 0;
  for (const a of adminAlerts) {
    const m = (a.metadata ?? {}) as AdminMeta;
    if (typeof m.reach === "number") totalReached += m.reach;
    if (typeof m.dispatchMs === "number" && m.dispatchMs > 0) { dispatchSum += m.dispatchMs; dispatchSamples++; }
  }

  const connections = getConnectionCount();
  const ingest = getIngestState();
  const maxType = Math.max(1, ...byType.map((r) => r.v));
  const maxSource = Math.max(1, ...bySource.map((r) => r.v));
  const totalSev = Math.max(1, bySeverity.reduce((a, r) => a + r.v, 0));
  const donut = bySeverity
    .reduce<{ acc: number; parts: string[] }>((state, r) => {
      const start = state.acc;
      const portion = (r.v / totalSev) * 100;
      state.acc += portion;
      state.parts.push(`${severityMeta(r.severity).color} ${start}% ${state.acc}%`);
      return state;
    }, { acc: 0, parts: [] }).parts.join(", ");

  const cards = [
    { icon: Globe2, label: "Pessoas conectadas agora", value: connections, color: "text-emerald-400", bg: "bg-emerald-400/10" },
    { icon: Siren, label: "Alertas nas últimas 24h", value: last24Row?.v ?? 0, color: "text-red-500", bg: "bg-red-500/10" },
    { icon: Siren, label: "Graves/extremos (total)", value: highTotal, color: "text-orange-400", bg: "bg-orange-400/10" },
    { icon: Activity, label: "Alertas registrados (total)", value: totalRow?.v ?? 0, color: "text-cyan-400", bg: "bg-cyan-400/10" },
    { icon: Send, label: "Disparos públicos do admin", value: adminAlerts.length, color: "text-cyan-400", bg: "bg-cyan-400/10" },
    { icon: Users, label: "Pessoas alcançadas (soma)", value: totalReached, color: "text-emerald-400", bg: "bg-emerald-400/10" },
    { icon: Timer, label: "Tempo médio de disparo", value: `${dispatchSamples ? Math.round(dispatchSum / dispatchSamples) : 0} ms`, color: "text-emerald-400", bg: "bg-emerald-400/10" },
    { icon: Database, label: "Latência do banco agora", value: `${dbLatencyMs} ms`, color: "text-yellow-400", bg: "bg-yellow-400/10" },
  ];

  return (
    <div className="mx-auto max-w-[1200px] px-4 py-8 sm:px-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-3 text-3xl font-black tracking-tight">
            <BarChart3 className="h-8 w-8 text-cyan-400" /> Métricas do sistema
          </h1>
          <p className="mt-1 text-zinc-400">
            Transparência total: eventos detectados, desempenho dos disparos e saúde das fontes — sem nenhum dado pessoal.
          </p>
        </div>
        <AutoRefresh seconds={20} />
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        {cards.map(({ icon: Icon, label, value, color, bg }) => (
          <div key={label} className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
            <span className={`flex h-9 w-9 items-center justify-center rounded-lg ${bg}`}>
              <Icon className={`h-5 w-5 ${color}`} />
            </span>
            <p className="mt-2 text-2xl font-black tabular-nums leading-none">{value}</p>
            <p className="mt-1 text-[11px] font-bold uppercase tracking-wide text-zinc-500">{label}</p>
          </div>
        ))}
      </div>

      {/* série de 14 dias */}
      <section className="mt-4 rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
        <h2 className="text-sm font-black uppercase tracking-wider">Eventos detectados — últimos 14 dias</h2>
        <div className="mt-4 flex h-36 items-end gap-1.5">
          {days.map(([day, v]) => (
            <div key={day} className="flex flex-1 flex-col items-center gap-1">
              <span className="text-[10px] font-bold tabular-nums text-zinc-400">{v || ""}</span>
              <div
                className="w-full rounded-t bg-cyan-500/80 transition-all hover:bg-cyan-400"
                style={{ height: `${Math.max(3, (v / maxDay) * 100)}%` }}
                title={`${day}: ${v} eventos`}
              />
              <span className="text-[9px] tabular-nums text-zinc-600">
                {new Date(`${day}T12:00:00`).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })}
              </span>
            </div>
          ))}
        </div>
      </section>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        {/* por tipo */}
        <section className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
          <h2 className="text-sm font-black uppercase tracking-wider">Alertas por tipo</h2>
          <div className="mt-3 flex flex-col gap-2.5">
            {byType.length === 0 && <p className="text-sm text-zinc-500">Sem dados ainda.</p>}
            {byType.map((r) => (
              <div key={r.type}>
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-zinc-300">{ALERT_TYPES[r.type]?.label ?? typeLabel(r.type)}</span>
                  <span className="font-bold tabular-nums text-zinc-400">{r.v}</span>
                </div>
                <div className="mt-1 h-2 overflow-hidden rounded-full bg-zinc-800">
                  <div className="h-full rounded-full bg-cyan-400" style={{ width: `${(r.v / maxType) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* severidade donut */}
        <section className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
          <h2 className="text-sm font-black uppercase tracking-wider">Distribuição por severidade</h2>
          <div className="mt-4 flex items-center gap-4">
            <div
              className="relative h-32 w-32 shrink-0 rounded-full"
              style={{ background: `conic-gradient(${donut || "#27272a 0% 100%"})` }}
            >
              <div className="absolute inset-[22%] flex items-center justify-center rounded-full bg-zinc-950 text-center">
                <span className="text-lg font-black tabular-nums">{totalSev}</span>
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              {[4, 3, 2, 1].map((s) => {
                const row = bySeverity.find((r) => r.severity === s);
                const v = row?.v ?? 0;
                return (
                  <span key={s} className="flex items-center gap-2 text-xs text-zinc-300">
                    <span className="h-2.5 w-2.5 rounded-sm" style={{ background: severityMeta(s).color }} />
                    {severityMeta(s).label}: <strong className="tabular-nums">{v}</strong>
                    <span className="tabular-nums text-zinc-600">({Math.round((v / totalSev) * 100)}%)</span>
                  </span>
                );
              })}
            </div>
          </div>
        </section>

        {/* fontes */}
        <section className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
          <h2 className="text-sm font-black uppercase tracking-wider">Eventos por fonte</h2>
          <div className="mt-3 flex flex-col gap-2.5">
            {bySource.map((r) => (
              <div key={r.source}>
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-zinc-300">{r.source}</span>
                  <span className="font-bold tabular-nums text-zinc-400">{r.v}</span>
                </div>
                <div className="mt-1 h-2 overflow-hidden rounded-full bg-zinc-800">
                  <div className="h-full rounded-full bg-emerald-400" style={{ width: `${(r.v / maxSource) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 border-t border-zinc-800 pt-3">
            <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-zinc-400">
              <Satellite className="h-4 w-4 text-cyan-400" /> Saúde da ingestão
            </p>
            <div className="mt-2 flex flex-col gap-1.5 text-xs">
              {Object.entries(ingest.sources).map(([name, s]) => (
                <p key={name} className="flex items-center justify-between rounded bg-zinc-950 px-2.5 py-1.5">
                  <span className="flex items-center gap-2 font-medium text-zinc-300">
                    <span className={`h-2 w-2 rounded-full ${s.ok ? "bg-emerald-400" : "bg-red-500"}`} /> {name}
                  </span>
                  <span className="tabular-nums text-zinc-500">{s.ok ? `${s.count} eventos` : "offline"}</span>
                </p>
              ))}
              <p className="tabular-nums text-zinc-500">
                Última varredura: {ingest.lastRunAt ? `${formatDateTimePt(ingest.lastRunAt)} (${timeAgoPt(ingest.lastRunAt)})` : "—"} •
                novos: {ingest.lastNewAlerts}
              </p>
            </div>
          </div>
        </section>
      </div>

      {/* últimos disparos */}
      <section className="mt-4 overflow-hidden rounded-xl border border-zinc-800">
        <div className="border-b border-zinc-800 bg-zinc-900/60 px-5 py-3">
          <h2 className="text-sm font-black uppercase tracking-wider">Últimos disparos públicos da administração</h2>
        </div>
        <div className="divide-y divide-zinc-800 bg-zinc-950">
          {adminAlerts.length === 0 && (
            <p className="px-5 py-4 text-sm text-zinc-500">Nenhum disparo ainda. Eles aparecerão aqui com alcance e tempo de disparo.</p>
          )}
          {adminAlerts.slice(0, 10).map((a) => {
            const m = (a.metadata ?? {}) as AdminMeta;
            const sev = severityMeta(a.severity);
            return (
              <div key={a.id} className="flex flex-wrap items-center gap-x-4 gap-y-1 px-5 py-3 text-sm">
                <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: sev.color }} />
                <span className="min-w-0 flex-1 truncate font-medium" title={a.title}>{a.title}</span>
                <span className="tabular-nums text-xs text-zinc-500">{a.locationName}</span>
                <span className="text-xs">alcançou <strong className="tabular-nums text-emerald-400">{m.reach ?? 0}</strong></span>
                <span className="text-xs">disparo <strong className="tabular-nums text-zinc-200">{m.dispatchMs ?? 0} ms</strong></span>
                <span className="tabular-nums text-xs text-zinc-600">{timeAgoPt(a.eventTime)}</span>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
