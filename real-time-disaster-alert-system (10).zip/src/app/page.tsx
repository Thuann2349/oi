"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import {
  Siren, Users, Send, Timer, FastForward, Volume2, VolumeX,
  FlaskConical, RefreshCw, Bell, X, Radio, CloudSun, BarChart3, ArrowRight,
} from "lucide-react";
import AlertFeed from "@/components/AlertFeed";
import SidePanel, { type WeatherData } from "@/components/SidePanel";
import { severityMeta } from "@/lib/meta";
import { TypeIcon } from "@/components/TypeIcon";
import type { AlertRow } from "@/db/schema";

const MapView = dynamic(() => import("@/components/MapView"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full items-center justify-center rounded-xl border border-zinc-800 bg-zinc-900">
      <p className="animate-pulse text-sm text-zinc-500">Carregando mapa meteorológico...</p>
    </div>
  ),
});

type Stats = {
  alertsActive72h: number;
  alertsHighPlus: number;
  connectedNow: number;
  publicBroadcasts: number;
  totalReached: number;
  avgDispatchMs: number;
  avgLeadMinutes: number;
  ingest: {
    lastRunAt: string | null;
    sources: Record<string, { ok: boolean; count: number }>;
  };
};

type Toast = { id: number; alert: AlertRow; notified?: number };

export default function DashboardPage() {
  const [alerts, setAlerts] = useState<AlertRow[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [selected, setSelected] = useState<AlertRow | null>(null);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [weatherLoading, setWeatherLoading] = useState(false);
  const [freshIds, setFreshIds] = useState<Set<number>>(new Set());
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [connected, setConnected] = useState(false);
  const [soundOn, setSoundOn] = useState(false);
  const [simulating, setSimulating] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const audioRef = useRef<AudioContext | null>(null);
  const statsTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const fetchStats = useCallback(async () => {
    try {
      const r = await fetch("/api/stats");
      if (r.ok) setStats(await r.json());
    } catch { /* mantém anterior */ }
  }, []);

  const fetchAlerts = useCallback(async () => {
    try {
      const r = await fetch("/api/alerts?limit=150");
      if (r.ok) {
        const d = await r.json();
        setAlerts(d.alerts ?? []);
      }
    } catch { /* mantém anterior */ }
  }, []);

  useEffect(() => {
    fetchAlerts();
    fetchStats();
    const t = setInterval(() => { fetchStats(); }, 30000);
    const t2 = setInterval(() => { fetchAlerts(); }, 90000);
    return () => { clearInterval(t); clearInterval(t2); };
  }, [fetchAlerts, fetchStats]);

  /* ---------------- som de alerta ---------------- */
  const beep = useCallback((severity: number) => {
    if (!soundOn) return;
    try {
      audioRef.current ??= new AudioContext();
      const ctx = audioRef.current;
      if (ctx.state === "suspended") void ctx.resume();
      const times = severity >= 4 ? [0, 0.22, 0.44] : [0, 0.22];
      for (const offset of times) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = severity >= 4 ? 880 : 660;
        gain.gain.setValueAtTime(0.0001, ctx.currentTime + offset);
        gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + offset + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + offset + 0.18);
        osc.connect(gain).connect(ctx.destination);
        osc.start(ctx.currentTime + offset);
        osc.stop(ctx.currentTime + offset + 0.2);
      }
    } catch { /* áudio indisponível */ }
  }, [soundOn]);

  const pushToast = useCallback((alert: AlertRow) => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev.slice(-2), { id, alert }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 12000);
  }, []);

  /* ----------- Canal ao vivo compartilhado (1 conexão por aba) ----------- */
  useEffect(() => {
    let lastBeat = Date.now();
    const onStream = (e: Event) => {
      const event = (e as CustomEvent).detail as { kind: string; data: AlertRow };
      if (!event || typeof event.kind !== "string") return;
      if (event.kind === "heartbeat") {
        lastBeat = Date.now();
        setConnected(true);
        return;
      }
      try {
        if (event.kind === "alert") {
          const alert = { ...event.data, eventTime: new Date(event.data.eventTime), detectedAt: new Date(event.data.detectedAt), createdAt: new Date(event.data.createdAt) } as AlertRow;
          setAlerts((prev) => (prev.some((a) => a.id === alert.id) ? prev : [alert, ...prev].slice(0, 200)));
          setFreshIds((prev) => new Set(prev).add(alert.id));
          setTimeout(() => setFreshIds((prev) => { const n = new Set(prev); n.delete(alert.id); return n; }), 6000);
          if (alert.severity >= 3) {
            pushToast(alert);
            beep(alert.severity);
            if (typeof Notification !== "undefined" && Notification.permission === "granted") {
              new Notification(`VIGIA — Alerta ${severityMeta(alert.severity).label}`, { body: alert.title });
            }
          }
          if (statsTimer.current) clearTimeout(statsTimer.current);
          statsTimer.current = setTimeout(fetchStats, 600);
        }
        if (event.kind === "stats") {
          if (statsTimer.current) clearTimeout(statsTimer.current);
          statsTimer.current = setTimeout(fetchStats, 600);
        }
      } catch { /* evento inválido */ }
    };
    const onStatus = (e: Event) => {
      const open = Boolean((e as CustomEvent).detail?.connected);
      if (open) lastBeat = Date.now();
      setConnected(open);
    };
    window.addEventListener("vigia:status", onStatus);
    // a conexão pode ter aberto antes deste painel montar
    if ((window as unknown as { __vigiaConnected?: boolean }).__vigiaConnected) setConnected(true);
    window.addEventListener("vigia:stream", onStream);
    const watchdog = setInterval(() => {
      if (Date.now() - lastBeat > 45000) setConnected(false);
    }, 5000);
    return () => {
      window.removeEventListener("vigia:stream", onStream);
      window.removeEventListener("vigia:status", onStatus);
      clearInterval(watchdog);
    };
  }, [beep, fetchStats, pushToast]);

  /* ---------------- ações ---------------- */
  const handleSelect = useCallback((alert: AlertRow) => {
    setSelected(alert);
    setWeather(null);
  }, []);

  const handleMapClick = useCallback(async (lat: number, lon: number) => {
    setSelected(null);
    setWeatherLoading(true);
    try {
      const r = await fetch(`/api/weather?lat=${lat}&lon=${lon}`);
      if (r.ok) setWeather(await r.json());
      else setWeather(null);
    } catch {
      setWeather(null);
    } finally {
      setWeatherLoading(false);
    }
  }, []);

  const simulate = async () => {
    setSimulating(true);
    try {
      const r = await fetch("/api/simulate", { method: "POST" });
      const d = await r.json();
      if (d.alert) {
        const alert = { ...d.alert, eventTime: new Date(d.alert.eventTime), detectedAt: new Date(d.alert.detectedAt), createdAt: new Date(d.alert.createdAt) } as AlertRow;
        setSelected(alert);
        setWeather(null);
        fetchStats();
      }
    } finally {
      setSimulating(false);
    }
  };

  const refreshNow = async () => {
    setRefreshing(true);
    try {
      await fetch("/api/simulate");
      await Promise.all([fetchAlerts(), fetchStats()]);
    } finally {
      setRefreshing(false);
    }
  };

  const enableBrowserNotifications = async () => {
    if (typeof Notification !== "undefined" && Notification.permission === "default") {
      await Notification.requestPermission();
    }
    setSoundOn((v) => !v);
  };

  const statCards = [
    { icon: Siren, label: "Alertas ativos (72h)", value: stats?.alertsActive72h ?? "—", color: "text-red-500", bg: "bg-red-500/10" },
    { icon: Siren, label: "Graves ou extremos", value: stats?.alertsHighPlus ?? "—", color: "text-orange-400", bg: "bg-orange-400/10" },
    { icon: Users, label: "Pessoas conectadas agora", value: stats?.connectedNow ?? "—", color: "text-emerald-400", bg: "bg-emerald-400/10" },
    { icon: Send, label: "Alertas públicos disparados", value: stats?.publicBroadcasts ?? "—", color: "text-cyan-400", bg: "bg-cyan-400/10" },
    { icon: Timer, label: "Tempo de disparo do admin", value: stats ? `${stats.avgDispatchMs} ms` : "—", color: "text-emerald-400", bg: "bg-emerald-400/10" },
    { icon: FastForward, label: "Antecipação média", value: stats ? `${stats.avgLeadMinutes} min` : "—", color: "text-yellow-400", bg: "bg-yellow-400/10" },
  ];

  return (
    <div className="mx-auto max-w-[1600px] px-4 py-4 sm:px-6">
      {/* faixa superior */}
      <div className="mb-4 flex flex-wrap items-center gap-3 rounded-xl border border-zinc-800 bg-zinc-900/60 px-4 py-3">
        <div className="flex items-center gap-2">
          <span className={`h-2.5 w-2.5 rounded-full ${connected ? "bg-emerald-400 live-dot" : "bg-zinc-600"}`} />
          <p className="text-sm font-semibold">
            {connected ? "Canal em tempo real conectado — 0% de atraso" : "Reconectando ao canal ao vivo..."}
          </p>
        </div>
        <div className="hidden items-center gap-2 text-xs text-zinc-500 md:flex">
          {stats && Object.entries(stats.ingest.sources).map(([name, s]) => (
            <span key={name} className={`flex items-center gap-1 rounded-full px-2 py-0.5 ${s.ok ? "bg-emerald-500/10 text-emerald-400" : "bg-red-500/10 text-red-400"}`}>
              <span className={`h-1.5 w-1.5 rounded-full ${s.ok ? "bg-emerald-400" : "bg-red-400"}`} />
              {name} {s.ok ? `(${s.count})` : "offline"}
            </span>
          ))}
        </div>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <button
            onClick={enableBrowserNotifications}
            className={`flex items-center gap-2 rounded-md px-3 py-2 text-xs font-bold transition-colors ${soundOn ? "bg-amber-500 text-zinc-950" : "bg-zinc-800 text-zinc-200 hover:bg-zinc-700"}`}
          >
            {soundOn ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            {soundOn ? "Som ativo" : "Ativar som de alerta"}
          </button>
          <button
            onClick={refreshNow}
            disabled={refreshing}
            className="flex items-center gap-2 rounded-md bg-zinc-800 px-3 py-2 text-xs font-bold text-zinc-200 transition-colors hover:bg-zinc-700 disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`} /> Varrer fontes
          </button>
          <button
            onClick={simulate}
            disabled={simulating}
            className="flex items-center gap-2 rounded-md bg-red-600 px-3 py-2 text-xs font-bold text-white transition-colors hover:bg-red-500 disabled:opacity-50"
          >
            <FlaskConical className="h-4 w-4" /> {simulating ? "Disparando..." : "Simular desastre"}
          </button>
        </div>
      </div>

      {/* mapa principal: visível logo ao abrir, sem rolar a página */}
      <div className="mb-4 grid gap-4 xl:grid-cols-12">
        <section className="min-w-0 xl:col-span-8" aria-label="Mapa meteorológico ao vivo">
          <div className="mb-2 flex items-center justify-between gap-3 px-1">
            <div>
              <h1 className="text-base font-black uppercase tracking-wider sm:text-lg">Mapa global ao vivo</h1>
              <p className="text-xs text-zinc-500">Radar de chuva, alertas ativos e camadas meteorológicas — clique no mapa para ver a previsão local.</p>
            </div>
            <span className="hidden shrink-0 items-center gap-1.5 rounded-full border border-emerald-900/60 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-bold text-emerald-400 sm:flex">
              <span className="live-dot h-1.5 w-1.5 rounded-full bg-emerald-400" /> MAPA ATIVO
            </span>
          </div>
          <div className="h-[58vh] min-h-[420px] max-h-[760px] overflow-hidden rounded-xl xl:h-[calc(100vh-250px)] xl:min-h-[540px]">
            <MapView alerts={alerts} selectedId={selected?.id ?? null} onSelect={handleSelect} onMapClick={handleMapClick} />
          </div>
        </section>

        <div className="flex min-h-0 flex-col gap-4 xl:col-span-4 xl:h-[calc(100vh-250px)] xl:min-h-[540px]">
          <div className="h-[420px] min-h-0 xl:h-[55%]">
            <AlertFeed alerts={alerts} selectedId={selected?.id ?? null} freshIds={freshIds} onSelect={handleSelect} />
          </div>
          <div className="h-[380px] min-h-0 xl:min-h-0 xl:flex-1">
            <SidePanel
              alert={selected}
              weather={weather}
              weatherLoading={weatherLoading}
              onClear={() => { setSelected(null); setWeather(null); }}
            />
          </div>
        </div>
      </div>

      {/* métricas depois do mapa: mantém o mapa no primeiro plano */}
      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        {statCards.map(({ icon: Icon, label, value, color, bg }) => (
          <div key={label} className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-3.5">
            <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${bg}`}>
              <Icon className={`h-4.5 w-4.5 ${color}`} />
            </span>
            <p className="mt-2 text-xl font-black tabular-nums leading-none">{value}</p>
            <p className="mt-1 text-[11px] font-medium uppercase tracking-wide text-zinc-500">{label}</p>
          </div>
        ))}
      </div>

      {/* atalhos: clima de alta confiança + métricas */}
      <div className="mb-4 grid gap-3 md:grid-cols-2">
        <Link href="/clima" className="group flex items-center gap-4 rounded-xl border border-cyan-900/60 bg-cyan-950/20 px-5 py-4 transition-colors hover:bg-cyan-950/40">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-cyan-500/15">
            <CloudSun className="h-6 w-6 text-cyan-300" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block font-bold">Previsão do tempo com índice de confiança</span>
            <span className="block truncate text-sm text-zinc-400">5 modelos + 143 cenários — previsão de 16 dias, hora a hora.</span>
          </span>
          <ArrowRight className="h-5 w-5 shrink-0 text-cyan-400 transition-transform group-hover:translate-x-1" />
        </Link>
        <Link href="/metricas" className="group flex items-center gap-4 rounded-xl border border-zinc-800 bg-zinc-900/60 px-5 py-4 transition-colors hover:bg-zinc-900">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-emerald-500/15">
            <BarChart3 className="h-6 w-6 text-emerald-300" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block font-bold">Métricas e transparência do sistema</span>
            <span className="block truncate text-sm text-zinc-400">Eventos por tipo, severidade e fonte, alcance dos disparos e saúde das fontes ao vivo.</span>
          </span>
          <ArrowRight className="h-5 w-5 shrink-0 text-emerald-400 transition-transform group-hover:translate-x-1" />
        </Link>
      </div>

      {/* chamada */}
      <div className="mt-4 flex flex-col items-start justify-between gap-3 rounded-xl border border-red-900/50 bg-red-950/30 px-5 py-4 md:flex-row md:items-center">
        <div className="flex items-start gap-3">
          <Bell className="mt-0.5 h-6 w-6 shrink-0 text-red-400" />
          <div>
            <p className="font-bold">A Defesa Civil avisa depois. O VIGIA avisa você primeiro.</p>
            <p className="text-sm text-zinc-400">
              Ative a proteção da sua região em segundos — sem cadastro, sem nome, sem telefone, sem e-mail. Sua região fica salva só no seu aparelho.
            </p>
          </div>
        </div>
        <Link href="/assinar" className="shrink-0 rounded-md bg-red-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-red-500">
          Proteger minha região (sem cadastro)
        </Link>
      </div>

      {/* toasts */}
      <div className="pointer-events-none fixed right-4 top-20 z-[100] flex w-[min(380px,90vw)] flex-col gap-2">
        {toasts.map(({ id, alert }) => {
          const sev = severityMeta(alert.severity);
          return (
            <div
              key={id}
              className="toast-enter pointer-events-auto flex gap-3 rounded-xl border bg-zinc-900 p-3.5 shadow-2xl"
              style={{ borderColor: sev.color }}
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg" style={{ background: `${sev.color}22`, color: sev.color }}>
                <TypeIcon type={alert.type} className="h-5 w-5" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-2 text-[11px] font-black uppercase tracking-wider" style={{ color: sev.color }}>
                  <Radio className="h-3 w-3" /> Novo alerta {sev.label}
                </p>
                <p className="mt-0.5 truncate text-sm font-semibold" title={alert.title}>{alert.title}</p>
                <p className="text-xs text-emerald-400">Transmitido a todos os visitantes conectados em milissegundos — sem nenhum dado pessoal.</p>
              </div>
              <button
                onClick={() => { setToasts((p) => p.filter((t) => t.id !== id)); setSelected(alert); }}
                className="self-start rounded p-1 text-zinc-500 hover:bg-zinc-800 hover:text-white"
                aria-label="Ver alerta"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
