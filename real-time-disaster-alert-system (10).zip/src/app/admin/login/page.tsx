"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ShieldAlert, KeyRound, Loader2, ArrowLeft } from "lucide-react";

export default function AdminLoginPage() {
  const router = useRouter();
  const [key, setKey] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const r = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "Chave inválida");
      router.push("/admin");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro ao entrar");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto flex max-w-md flex-col px-4 py-16 sm:px-6">
      <Link href="/" className="mb-6 flex items-center gap-1.5 text-sm text-zinc-400 hover:text-zinc-100">
        <ArrowLeft className="h-4 w-4" /> Voltar ao painel público
      </Link>
      <div className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-6">
        <span className="flex h-14 w-14 items-center justify-center rounded-xl bg-red-600">
          <ShieldAlert className="h-8 w-8 text-white" />
        </span>
        <h1 className="mt-4 text-2xl font-black tracking-tight">Área da Administração</h1>
        <p className="mt-1 text-sm leading-relaxed text-zinc-400">
          Acesso restrito à equipe de emergência. Daqui você dispara alertas para toda a
          população <strong className="text-zinc-200">sem precisar de nenhum dado pessoal</strong>.
        </p>
        <form onSubmit={submit} className="mt-5">
          <label className="mb-1.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-zinc-400">
            <KeyRound className="h-3.5 w-3.5" /> Chave de acesso
          </label>
          <input
            type="password"
            value={key}
            onChange={(e) => setKey(e.target.value)}
            placeholder="Digite a chave do painel"
            autoFocus
            className="w-full rounded-md border border-zinc-700 bg-zinc-950 px-3 py-3 text-sm outline-none placeholder:text-zinc-600 focus:border-red-500"
          />
          {error && <p className="mt-3 rounded-md border border-red-800 bg-red-950/50 px-3 py-2 text-sm text-red-300">{error}</p>}
          <button
            type="submit"
            disabled={loading || !key}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-md bg-red-600 px-4 py-3 text-sm font-black uppercase tracking-wide text-white hover:bg-red-500 disabled:opacity-60"
          >
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            Entrar no Painel de Comando
          </button>
        </form>
        <p className="mt-4 text-center text-[11px] leading-snug text-zinc-600">
          A chave é definida de forma segura no servidor (variável <code className="rounded bg-zinc-800 px-1.5 py-0.5 text-zinc-300">ADMIN_KEY</code>).
          Tentativas incorretas são limitadas e bloqueiam o acesso temporariamente.
        </p>
      </div>
    </div>
  );
}
