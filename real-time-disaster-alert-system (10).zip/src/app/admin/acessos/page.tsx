import { redirect } from "next/navigation";
import { isAdmin } from "@/lib/auth";
import AdminVisitsPanel from "@/components/AdminVisitsPanel";

export const dynamic = "force-dynamic";

export default async function AdminAcessosPage() {
  if (!(await isAdmin())) redirect("/admin/login");
  return <AdminVisitsPanel />;
}
