"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Search, MapPin, LocateFixed, Wind, Droplets, Gauge, Navigation, CloudRain,
  ShieldCheck, Info, Loader2, Thermometer, MousePointerClick,
} from "lucide-react";
import { CodeIcon } from "@/components/WeatherIcon";
import DayDetail, { certColor, type DayRow, type HourRow } from "@/components/DayDetail";

type GeoResult = { name: string; state: string; country: string; latitude: number; longitude: number };
type Loc = { name: string; lat: number; lon: number };

type Forecast = {
  timezone: string | null;
  forecastDays: number;
  nowHour: string | null;
  current: {
    temperature?: number | null; feelsLike?: number | null; humidity?: number | null;
    precipitation?: number | null; pressure?: number | null; windSpeed?: number | null;
    windDirection?: number | null; windGusts?: number | null; isDay: boolean; condition: string; code?: number | null;
  };
  hourly: HourRow[];
  daily: DayRow[];
  confidence: number | null;
  confidenceNear: number | null;
  confidenceLabel: string;
  ensembleMembers: number;
  ensembleSources: Array<{ model: string; members: number }>;
  modelsUsed: string[];
};

function compass(deg?: number | null) {
  if (deg == null) return "—";
  const dirs = ["N", "NE", "L", "SE", "S", "SO", "O", "NO"];
  return dirs[Math.round(deg / 45) % 8];
}

export default function ClimaPage() {
  const [loc, setLoc] = useState<Loc>({ name: "São Paulo, SP", lat: -23.5505, lon: -46.6333 });
  const [data, setData] = useState<Forecast | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<GeoResult[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);

  const load = useCallback(async (target: Loc) => {
    setLoading(true);
    setError(null);
    try {
      const r = await fetch(`/api/forecast?lat=${target.lat}&lon=${target.lon}`);
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "Falha ao carregar a previsão");
      setData(d);
      setSelected(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro inesperado");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(loc); }, [load, loc]);

  const search = (q: string) => {
    setQuery(q);
    if (debounce.current) clearTimeout(debounce.current);
    if (q.trim().length < 2) { setResults([]); return; }
    debounce.current = setTimeout(async () => {
      try {
        const r = await fetch(`/api/geocode?q=${encodeURIComponent(q)}`);
        setResults((await r.json()).results ?? []);
      } catch { setResults([]); }
    }, 300);
  };

  const geolocate = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => setLoc({ name: "Sua localização atual", lat: pos.coords.latitude, lon: pos.coords.longitude }),
      () => setError("Não foi possível obter sua localização. Busque a cidade pelo nome."),
      { timeout: 8000 },
    );
  };

  const goPrev = useCallback(() => setSelected((i) => (i == null ? i : Math.max(0, i - 1))), []);
  const goNext = useCallback(
    () => setSelected((i) => (i == null || !data ? i : Math.min(data.daily.length - 1, i + 1))),
    [data],
  );
  const close = useCallback(() => setSelected(null), []);

  const c = data?.current;
  const days = data?.daily ?? [];
  const nowHour = data?.nowHour ?? null;
  const startIdx = data ? Math.max(0, data.hourly.findIndex((h) => h.time.slice(0, 13) === nowHour)) : 0;
  const next24 = data ? data.hourly.slice(startIdx, startIdx + 24) : [];
  const temps24 = next24.map((h) => h.temp).filter((t): t is number => t != null);
  const tMin = temps24.length ? Math.min(...temps24) : 0;
  const tMax = temps24.length ? Math.max(...temps24) : 1;
  const chartPoints = next24
    .map((h, i) => {
      if (h.temp == null) return null;
      const x = (i / Math.max(1, next24.length - 1)) * 720;
      const y = 120 - ((h.temp - tMin) / Math.max(1, tMax - tMin)) * 90;
      return `${x},${y}`;
    })
    .filter(Boolean)
    .join(" ");

  const selectedDay = selected != null ? days[selected] : null;
  const selectedHours = selectedDay && data ? data.hourly.filter((h) => h.time.startsWith(selectedDay.date)) : [];

  const inputCls =
    "w-full rounded-md border border-zinc-700 bg-zinc-950 py-2.5 pl-9 pr-3 text-sm outline-none placeholder:text-zinc-600 focus:border-cyan-500";

  return (
    <div className="mx-auto max-w-[1200px] px-4 py-8 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="max-w-2xl">
          <h1 className="flex items-center gap-3 text-3xl font-black tracking-tight">
            <CloudRain className="h-8 w-8 text-cyan-400" /> Previsão de 16 dias, hora a hora
          </h1>
          <p className="mt-2 text-zinc-400">
            <strong className="text-zinc-200">5 modelos</strong> (ECMWF, GFS, ICON, JMA e GEM) e{" "}
            <strong className="text-zinc-200">{data?.ensembleMembers || 143} cenários</strong> de ensemble, atualizados a cada 15 minutos.
            Clique em qualquer dia para ver o tempo <strong className="text-zinc-200">hora por hora, do começo ao fim do dia</strong>.
          </p>
        </div>
        <div className="relative w-full max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
          <input value={query} onChange={(e) => search(e.target.value)} placeholder="Buscar cidade..." className={inputCls} />
          {results.length > 0 && (
            <div className="absolute inset-x-0 top-full z-30 mt-1 overflow-hidden rounded-md border border-zinc-700 bg-zinc-900 shadow-2xl">
              {results.map((r, i) => (
                <button
                  key={`${r.latitude}-${i}`}
                  onClick={() => {
                    setLoc({ name: `${r.name}${r.state ? `, ${r.state}` : ""}`, lat: r.latitude, lon: r.longitude });
                    setQuery("");
                    setResults([]);
                  }}
                  className="flex w-full items-center gap-2 px-3 py-2.5 text-left text-sm hover:bg-zinc-800"
                >
                  <MapPin className="h-4 w-4 shrink-0 text-cyan-400" />
                  {r.name}{r.state ? `, ${r.state}` : ""} <span className="text-zinc-500">— {r.country}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <span className="flex items-center gap-1.5 rounded-full bg-zinc-900 px-3 py-1.5 text-sm font-semibold">
          <MapPin className="h-4 w-4 text-cyan-400" /> {loc.name}
        </span>
        <button onClick={geolocate} className="flex items-center gap-1.5 rounded-full bg-zinc-800 px-3 py-1.5 text-xs font-bold hover:bg-zinc-700">
          <LocateFixed className="h-3.5 w-3.5" /> Usar minha localização
        </button>
        <button onClick={() => load(loc)} className="flex items-center gap-1.5 rounded-full bg-zinc-800 px-3 py-1.5 text-xs font-bold hover:bg-zinc-700">
          Atualizar previsão
        </button>
        {data?.timezone && <span className="text-xs text-zinc-500">Fuso: {data.timezone}</span>}
      </div>

      {loading && (
        <div className="mt-10 flex items-center justify-center gap-2 text-zinc-400">
          <Loader2 className="h-5 w-5 animate-spin" /> Consultando 5 modelos e 143 cenários para 16 dias...
        </div>
      )}

      {error && !loading && (
        <div className="mt-6 rounded-xl border border-red-800 bg-red-950/40 p-5 text-sm text-red-200">
          <p className="font-bold">Não foi possível carregar a previsão.</p>
          <p className="mt-1 text-red-300/80">{error}</p>
          <button onClick={() => load(loc)} className="mt-3 rounded-md bg-red-600 px-4 py-2 text-xs font-bold text-white hover:bg-red-500">
            Tentar novamente
          </button>
        </div>
      )}

      {data && c && !loading && (
        <>
          {/* ------------------------------ AGORA + CERTEZA ------------------------------ */}
          <div className="mt-6 grid gap-4 lg:grid-cols-3">
            <div className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-5 lg:col-span-2">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <p className="flex items-center gap-2 text-sm text-zinc-400">
                    <CodeIcon code={c.code} className="h-5 w-5 text-cyan-300" /> {c.condition}
                  </p>
                  <p className="text-6xl font-black tabular-nums leading-none">
                    {c.temperature != null ? Math.round(c.temperature) : "—"}°C
                  </p>
                  <p className="mt-1 text-sm text-zinc-500">
                    Sensação de {c.feelsLike != null ? Math.round(c.feelsLike) : "—"}°C • {loc.name}
                  </p>
                </div>
                <div className="text-center">
                  <Navigation className="mx-auto h-9 w-9 text-cyan-400" style={{ transform: `rotate(${(c.windDirection ?? 0) + 180}deg)` }} />
                  <p className="mt-1 text-xs font-bold">Vento {compass(c.windDirection)}</p>
                  <p className="text-[11px] tabular-nums text-zinc-500">
                    {c.windSpeed != null ? Math.round(c.windSpeed) : "—"} km/h • raj. {c.windGusts != null ? Math.round(c.windGusts) : "—"}
                  </p>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2 text-sm sm:grid-cols-4">
                <div className="rounded-lg bg-zinc-950 p-3">
                  <p className="flex items-center gap-1.5 text-[11px] uppercase text-zinc-500"><Wind className="h-3.5 w-3.5 text-cyan-400" /> Vento</p>
                  <p className="mt-1 font-bold tabular-nums">{c.windSpeed != null ? Math.round(c.windSpeed) : "—"} km/h</p>
                </div>
                <div className="rounded-lg bg-zinc-950 p-3">
                  <p className="flex items-center gap-1.5 text-[11px] uppercase text-zinc-500"><Droplets className="h-3.5 w-3.5 text-cyan-400" /> Umidade</p>
                  <p className="mt-1 font-bold tabular-nums">{c.humidity ?? "—"}%</p>
                </div>
                <div className="rounded-lg bg-zinc-950 p-3">
                  <p className="flex items-center gap-1.5 text-[11px] uppercase text-zinc-500"><Gauge className="h-3.5 w-3.5 text-cyan-400" /> Pressão</p>
                  <p className="mt-1 font-bold tabular-nums">{c.pressure != null ? Math.round(c.pressure) : "—"} hPa</p>
                </div>
                <div className="rounded-lg bg-zinc-950 p-3">
                  <p className="flex items-center gap-1.5 text-[11px] uppercase text-zinc-500"><Thermometer className="h-3.5 w-3.5 text-cyan-400" /> Chuva agora</p>
                  <p className="mt-1 font-bold tabular-nums">{c.precipitation ?? 0} mm</p>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-emerald-900/60 bg-emerald-950/30 p-5">
              <p className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-emerald-300">
                <ShieldCheck className="h-4 w-4" /> Índice de certeza
              </p>
              <p className={`mt-2 text-6xl font-black tabular-nums leading-none ${certColor(data.confidence)}`}>
                {data.confidence ?? "—"}<span className="text-3xl">%</span>
              </p>
              <p className="mt-1 text-sm font-bold text-emerald-200">
                {data.confidenceLabel} • próximas 48h: <span className="tabular-nums">{data.confidenceNear ?? "—"}%</span>
              </p>
              <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-zinc-800">
                <div className="h-full rounded-full bg-emerald-400 transition-all" style={{ width: `${data.confidence ?? 0}%` }} />
              </div>
              <p className="mt-3 text-xs leading-relaxed text-emerald-100/70">
                Média de concordância dos {data.ensembleMembers} cenários e dos 5 modelos nos {data.forecastDays} dias.
                O máximo exibido é 99%: concordância quase total, sem prometer certeza absoluta.
              </p>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {data.ensembleSources.map((s) => (
                  <span key={s.model} className="rounded bg-zinc-900/80 px-2 py-0.5 text-[10px] font-bold text-zinc-300">
                    {s.model} {s.members}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* ------------------------------ PRÓXIMAS 24H ------------------------------ */}
          <div className="mt-4 rounded-2xl border border-zinc-800 bg-zinc-900/60 p-5">
            <h2 className="text-sm font-black uppercase tracking-wider">Próximas 24 horas — temperatura e chance de chuva</h2>
            <svg viewBox="0 0 720 140" className="mt-3 w-full" role="img" aria-label="Gráfico de temperatura das próximas 24 horas">
              <polyline points={chartPoints} fill="none" stroke="#22d3ee" strokeWidth="2.5" strokeLinejoin="round" />
              {next24.map((h, i) => {
                if (h.temp == null || i % 4 !== 0) return null;
                const x = (i / Math.max(1, next24.length - 1)) * 720;
                const y = 120 - ((h.temp - tMin) / Math.max(1, tMax - tMin)) * 90;
                return (
                  <text key={i} x={x} y={Math.max(12, y - 8)} textAnchor="middle" fontSize="11" fill="#a1a1aa" fontWeight="700">
                    {Math.round(h.temp)}°
                  </text>
                );
              })}
            </svg>
            <div className="flex items-end gap-[2px]" aria-hidden>
              {next24.map((h, i) => (
                <div key={i} className="flex-1 rounded-t bg-cyan-500/70" style={{ height: `${Math.max(2, (h.rainChance ?? 0) * 0.4)}px` }} title={`${h.rainChance ?? 0}%`} />
              ))}
            </div>
            <div className="mt-1 flex justify-between text-[10px] tabular-nums text-zinc-500">
              {next24.filter((_, i) => i % 4 === 0).map((h, i) => (
                <span key={i}>{h.time.slice(11, 13)}h</span>
              ))}
            </div>
          </div>

          {/* ------------------------------ CERTEZA DIA A DIA ------------------------------ */}
          <div className="mt-4 rounded-2xl border border-zinc-800 bg-zinc-900/60 p-5">
            <h2 className="text-sm font-black uppercase tracking-wider">Certeza dia a dia — toque em uma barra para abrir o dia</h2>
            <div className="mt-4 flex h-32 items-end gap-1">
              {days.map((d, idx) => {
                const conf = d.confidence ?? 0;
                const color = conf >= 90 ? "bg-emerald-400" : conf >= 75 ? "bg-yellow-400" : conf >= 60 ? "bg-orange-400" : "bg-red-500";
                return (
                  <button
                    key={d.date}
                    onClick={() => setSelected(idx)}
                    aria-label={`Abrir ${d.date}, certeza ${conf}%`}
                    className="group flex flex-1 flex-col items-center gap-1 rounded-t hover:bg-zinc-800/60"
                  >
                    <span className="text-[9px] font-bold tabular-nums text-zinc-400">{conf}%</span>
                    <div className={`w-full rounded-t ${color} transition-opacity group-hover:opacity-80`} style={{ height: `${Math.max(4, conf)}%` }} />
                    <span className="text-[9px] capitalize tabular-nums text-zinc-600">
                      {new Date(`${d.date}T12:00:00`).toLocaleDateString("pt-BR", { weekday: "narrow" })}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* ------------------------------ 16 DIAS (CARTÕES) ------------------------------ */}
          <div className="mb-3 mt-6 flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-sm font-black uppercase tracking-wider">Próximos {days.length} dias</h2>
            <span className="flex items-center gap-1.5 text-xs font-semibold text-cyan-300">
              <MousePointerClick className="h-4 w-4" /> Clique em um dia para ver as 24 horas
            </span>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {days.map((d, idx) => (
              <button
                key={d.date}
                data-testid="day-card"
                onClick={() => setSelected(idx)}
                className="group rounded-xl border border-zinc-800 bg-zinc-900/60 p-4 text-left transition-colors hover:border-cyan-600/60 hover:bg-zinc-900"
              >
                <div className="flex items-center justify-between">
                  <p className="text-sm font-bold capitalize">
                    {new Date(`${d.date}T12:00:00`).toLocaleDateString("pt-BR", { weekday: "short", day: "2-digit", month: "2-digit" })}
                  </p>
                  <span className="text-cyan-300"><CodeIcon code={d.code} className="h-6 w-6" /></span>
                </div>
                <p className="mt-2 text-2xl font-black tabular-nums">
                  {d.max != null ? Math.round(d.max) : "—"}°{" "}
                  <span className="text-base font-semibold text-zinc-500">{d.min != null ? Math.round(d.min) : "—"}°</span>
                </p>
                <div className="mt-3 flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1 font-semibold text-cyan-300">
                    <CloudRain className="h-3.5 w-3.5" /> {d.rainChanceEnsemble != null ? `${d.rainChanceEnsemble}% chuva` : "—"}
                  </span>
                  <span className="flex items-center gap-1 tabular-nums text-zinc-500">
                    <Wind className="h-3.5 w-3.5" /> {d.windMax != null ? Math.round(d.windMax) : "—"} km/h
                  </span>
                </div>
                <div className="mt-3 flex items-center justify-between border-t border-zinc-800 pt-2 text-[11px]">
                  <span className="text-zinc-500">Certeza do dia</span>
                  <span className={`font-black tabular-nums ${certColor(d.confidence)}`}>
                    {d.confidence ?? "—"}%{d.confidenceLabel ? ` • ${d.confidenceLabel}` : ""}
                  </span>
                </div>
                <p className="mt-2 text-[11px] font-semibold text-cyan-400 opacity-70 group-hover:opacity-100">Ver 24 horas →</p>
              </button>
            ))}
          </div>

          <div className="mt-6 rounded-xl border border-cyan-900/60 bg-cyan-950/20 p-5">
            <p className="flex items-center gap-2 text-sm font-black uppercase tracking-wide text-cyan-300">
              <Info className="h-4 w-4" /> Como calculamos a certeza
            </p>
            <ul className="mt-2 list-disc space-y-1.5 pl-5 text-xs leading-relaxed text-cyan-100/70">
              <li>Cada hora é comparada entre os <strong>5 modelos</strong> (ECMWF, GFS, ICON, JMA e GEM): se todos prevêem a mesma temperatura, a certeza sobe.</li>
              <li>A <strong>chance de chuva</strong> é a fração dos <strong>{data.ensembleMembers} cenários</strong> em que chove naquela hora, não um palpite.</li>
              <li>Quanto mais os cenários e modelos concordam, maior a certeza. Divergência alta derruba o índice e sinaliza incerteza.</li>
              <li>Atualizamos a previsão a cada 15 minutos. A certeza cai naturalmente conforme o horário se afasta no tempo.</li>
            </ul>
          </div>
        </>
      )}

      {selectedDay && data && (
        <DayDetail
          day={selectedDay}
          hours={selectedHours}
          nowHour={nowHour}
          index={selected ?? 0}
          total={days.length}
          onPrev={goPrev}
          onNext={goNext}
          onClose={close}
        />
      )}
    </div>
  );
}
