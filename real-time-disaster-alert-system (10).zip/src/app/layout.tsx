import type { Metadata } from "next";
import type { ReactNode } from "react";
import Header from "@/components/Header";
import PublicAlertListener from "@/components/PublicAlertListener";
import ConsentBanner from "@/components/ConsentBanner";
import PwaRegister from "@/components/PwaRegister";
import { ShieldCheck } from "lucide-react";
import "./globals.css";

// Renderização por requisição: necessária para o Next aplicar o nonce da CSP
// nos scripts da página (HTML pré-renderizado não recebe nonce).
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "VIGIA — Alerta Antecipado de Desastres | O cidadão sabe primeiro",
  description:
    "Sistema de alerta antecipado de desastres: terremotos, enchentes, tempestades, incêndios e vulcões detectados por satélite e sensores, com notificação instantânea ao cidadão.",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [
      { url: "/vigia-icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/vigia-icon.svg", type: "image/svg+xml" },
    ],
    apple: "/vigia-icon-192.png",
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "VIGIA",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="min-h-screen bg-zinc-950 font-sans text-zinc-50 antialiased">
        <Header />
        <PublicAlertListener />
        <PwaRegister />
        <ConsentBanner />
        <main>{children}</main>
        <footer className="border-t border-zinc-800 bg-zinc-950">
          <div className="mx-auto flex max-w-[1600px] flex-col gap-3 px-4 py-6 text-xs text-zinc-500 sm:px-6 md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-emerald-500" />
              <span>
                <strong className="text-zinc-300">VIGIA</strong> — rede aberta de alerta antecipado. Fontes em tempo real:
                USGS, NASA EONET, Open-Meteo e RainViewer.
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
              <p>Em emergência real, ligue 193 (Bombeiros) ou 199 (Defesa Civil). Este sistema não substitui os canais oficiais.</p>
              <a href="/privacidade" className="text-zinc-300 underline underline-offset-2 hover:text-white">Privacidade</a>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
