export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  const g = globalThis as typeof globalThis & { __vigiaPoller?: boolean };
  if (g.__vigiaPoller) return;
  g.__vigiaPoller = true;

  const { ingestAll, seedFallbackAlerts } = await import("./lib/ingest");
  const { cleanupExpiredSiteVisits } = await import("./lib/visit-retention");

  const boot = async () => {
    try {
      const result = await ingestAll();
      if (result.newAlerts === 0) {
        // Se as fontes externas falharem, garante conteúdo da rede de sensores
        const existing = await seedFallbackAlerts();
        if (existing > 0) {
          const { latestAlerts } = await import("./lib/ingest");
          const { broadcast } = await import("./lib/emitter");
          for (const a of await latestAlerts(10)) broadcast({ kind: "alert", data: a });
        }
      }
    } catch (err) {
      console.error("[VIGIA] erro na ingestão inicial:", err);
      try {
        await seedFallbackAlerts();
      } catch { /* banco ainda indisponível */ }
    }
  };

  // Primeira ingestão poucos segundos após o boot
  setTimeout(boot, 2500);
  // Retenção de IP/analytics: limpeza ao iniciar e no máximo a cada 6 horas.
  const cleanup = () => cleanupExpiredSiteVisits().catch((err) => console.error("[VIGIA] limpeza de acessos falhou:", err));
  setTimeout(cleanup, 5000);
  setInterval(cleanup, 6 * 60 * 60 * 1000);
  // Varredura contínua: novos eventos globais a cada 45 segundos
  setInterval(() => {
    ingestAll().catch((err) => console.error("[VIGIA] ingestão periódica falhou:", err));
  }, 45_000);
}
