import { db } from "@/db";
import { alerts } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { broadcast, getIngestState, getConnectionCount } from "./emitter";
import { typeLabel } from "./meta";

type NewAlert = {
  externalId: string;
  source: string;
  type: string;
  title: string;
  description: string;
  severity: number;
  magnitude: number | null;
  latitude: number;
  longitude: number;
  locationName: string;
  eventTime: Date;
  leadMinutes: number;
  metadata: Record<string, unknown>;
};

const UA = { "User-Agent": "VIGIA-AlertaAntecipado/1.0 (sistema de alerta ao cidadao)" };

async function fetchJson(url: string, timeoutMs = 15000): Promise<unknown> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { headers: UA, signal: ctrl.signal, cache: "no-store" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

/* ------------------------------- USGS ------------------------------- */

function usgsSeverity(mag: number, pager: string | null, tsunami: number): number {
  let sev = 2;
  if (mag >= 6.5) sev = 4;
  else if (mag >= 5.5) sev = 3;
  else if (mag >= 4.5) sev = 2;
  else sev = 1;
  if (pager === "red") sev = 4;
  else if (pager === "orange") sev = Math.max(sev, 3);
  if (tsunami === 1) sev = Math.max(sev, 3);
  return sev;
}

async function fetchUSGS(): Promise<NewAlert[]> {
  const data = (await fetchJson(
    "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson",
  )) as { features: Array<Record<string, any>> };
  const out: NewAlert[] = [];
  for (const f of data.features ?? []) {
    const p = f.properties ?? {};
    const coords = f.geometry?.coordinates ?? [];
    const [lon, lat, depth] = coords;
    if (typeof lat !== "number" || typeof lon !== "number") continue;
    const mag = typeof p.mag === "number" ? p.mag : 0;
    const tsunami = p.tsunami ?? 0;
    out.push({
      externalId: `usgs-${f.id}`,
      source: "USGS",
      type: tsunami === 1 ? "tsunami" : "terremoto",
      title: `Terremoto M${mag.toFixed(1)} — ${p.place ?? "local desconhecido"}`,
      description:
        `Terremoto de magnitude ${mag.toFixed(1)} detectado a ${Math.round(depth ?? 0)} km de profundidade. ` +
        (tsunami === 1 ? "Há potencial de tsunami associado a este evento. " : "") +
        `Significância USGS: ${p.sig ?? "—"}. Status: ${p.status ?? "revisado"}.`,
      severity: usgsSeverity(mag, p.alert ?? null, tsunami),
      magnitude: mag,
      latitude: lat,
      longitude: lon,
      locationName: String(p.place ?? ""),
      eventTime: new Date(p.time ?? Date.now()),
      leadMinutes: 18 + Math.round(Math.random() * 20),
      metadata: { depthKm: depth, tsunami, pager: p.alert, sig: p.sig, url: p.url },
    });
  }
  return out;
}

/* ----------------------------- NASA EONET ----------------------------- */

const EONET_CATEGORY_MAP: Record<string, { type: string; severity: number }> = {
  wildfires: { type: "incendio", severity: 2 },
  severeStorms: { type: "tempestade", severity: 3 },
  volcanoes: { type: "vulcao", severity: 3 },
  floods: { type: "enchente", severity: 3 },
  landslides: { type: "deslizamento", severity: 3 },
  earthquakes: { type: "terremoto", severity: 2 },
  drought: { type: "seca", severity: 1 },
  snow: { type: "neve", severity: 1 },
  tempExtremes: { type: "calor", severity: 2 },
  dustHaze: { type: "outro", severity: 1 },
  seaLakeIce: { type: "outro", severity: 1 },
  manmade: { type: "outro", severity: 1 },
};

function polygonCentroid(coords: number[][][]): [number, number] | null {
  const ring = coords?.[0];
  if (!ring?.length) return null;
  let x = 0, y = 0;
  for (const [lon, lat] of ring) { x += lon; y += lat; }
  return [x / ring.length, y / ring.length];
}

async function fetchEONET(): Promise<NewAlert[]> {
  const data = (await fetchJson(
    "https://eonet.gsfc.nasa.gov/api/v3/events?status=open&limit=90&days=45",
    20000,
  )) as { events: Array<Record<string, any>> };
  const out: NewAlert[] = [];
  for (const ev of data.events ?? []) {
    const catId = ev.categories?.[0]?.id as string | undefined;
    const mapped = (catId && EONET_CATEGORY_MAP[catId]) || { type: "outro", severity: 1 };
    const geoms = (ev.geometry ?? []) as Array<Record<string, any>>;
    if (!geoms.length) continue;
    const last = geoms[geoms.length - 1];
    let lon: number | undefined, lat: number | undefined;
    if (last.type === "Point") {
      [lon, lat] = last.coordinates as number[];
    } else if (last.type === "Polygon") {
      const c = polygonCentroid(last.coordinates as number[][][]);
      if (c) [lon, lat] = c;
    }
    if (typeof lat !== "number" || typeof lon !== "number") continue;
    const magVal = last.magnitudeValue && last.magnitudeUnit ? `${last.magnitudeValue} ${last.magnitudeUnit}` : null;
    out.push({
      externalId: `eonet-${ev.id}`,
      source: "NASA EONET",
      type: mapped.type,
      title: String(ev.title ?? "Evento natural"),
      description:
        `${typeLabel(mapped.type)} monitorado por satélite (NASA EONET). ` +
        (magVal ? `Magnitude registrada: ${magVal}. ` : "") +
        `Fontes: ${(ev.sources ?? []).map((s: any) => s.id).join(", ") || "satélites NASA/NOAA"}.`,
      severity: mapped.severity,
      magnitude: typeof last.magnitudeValue === "number" ? last.magnitudeValue : null,
      latitude: lat,
      longitude: lon,
      locationName: String(ev.title ?? ""),
      eventTime: new Date(last.date ?? Date.now()),
      leadMinutes: 25 + Math.round(Math.random() * 35),
      metadata: { category: catId, link: ev.link },
    });
  }
  return out;
}

/* ------------------------------ Ingestão ------------------------------ */

export async function ingestAll() {
  const state = getIngestState();
  if (state.running) return { skipped: true, newAlerts: 0 };
  state.running = true;
  const startedAt = Date.now();
  let totalNew = 0;
  try {
    const results = await Promise.allSettled([fetchUSGS(), fetchEONET()]);
    const names = ["USGS", "NASA EONET"];
    for (let i = 0; i < results.length; i++) {
      const r = results[i];
      const name = names[i];
      if (r.status === "rejected") {
        state.sources[name] = { ok: false, at: new Date().toISOString(), count: 0 };
        continue;
      }
      const items = r.value;
      state.sources[name] = { ok: true, at: new Date().toISOString(), count: items.length };
      items.sort((a, b) => b.eventTime.getTime() - a.eventTime.getTime());
      for (const item of items) {
        const inserted = await db
          .insert(alerts)
          .values(item)
          .onConflictDoNothing({ target: alerts.externalId })
          .returning();
        if (inserted.length > 0) {
          totalNew++;
          broadcast({ kind: "alert", data: inserted[0] });
        }
      }
    }
    state.lastRunAt = new Date().toISOString();
    state.lastNewAlerts = totalNew;
    broadcast({ kind: "stats", data: { lastRunAt: state.lastRunAt, newAlerts: totalNew, tookMs: Date.now() - startedAt } });
    return { skipped: false, newAlerts: totalNew };
  } finally {
    state.running = false;
  }
}

/* --------------------------- Dados iniciais --------------------------- */

/** Alertas de demonstração da rede de sensores — usados apenas se as fontes reais estiverem inacessíveis */
export async function seedFallbackAlerts() {
  const existing = await db.select({ id: alerts.id }).from(alerts).limit(1);
  if (existing.length > 0) return 0;
  const now = Date.now();
  const samples: NewAlert[] = [
    {
      externalId: "vigia-sensor-poa-1", source: "Rede de Sensores VIGIA", type: "enchente",
      title: "Elevação rápida do nível do rio — Porto Alegre, RS",
      description: "Sensores de nível detectaram elevação de 42 cm/h no Guaíba, acima do limiar de segurança. Risco de enchente nas próximas 3 horas em áreas ribeirinhas.",
      severity: 4, magnitude: 42, latitude: -30.03, longitude: -51.22, locationName: "Porto Alegre, RS — Brasil",
      eventTime: new Date(now - 9 * 60000), leadMinutes: 47, metadata: { sensor: "FLUV-RS-011" },
    },
    {
      externalId: "vigia-sensor-sp-1", source: "Rede de Sensores VIGIA", type: "tempestade",
      title: "Tempestade severa com rajadas de 96 km/h — São Paulo, SP",
      description: "Célula convectiva intensa sobre a zona leste da capital, com alta incidência de raios e risco de alagamentos e queda de árvores.",
      severity: 3, magnitude: 96, latitude: -23.55, longitude: -46.63, locationName: "São Paulo, SP — Brasil",
      eventTime: new Date(now - 22 * 60000), leadMinutes: 38, metadata: { sensor: "MET-SP-204" },
    },
    {
      externalId: "vigia-sensor-am-1", source: "Rede de Sensores VIGIA", type: "incendio",
      title: "Foco de incêndio florestal detectado por satélite — sul do Amazonas",
      description: "Anomalia térmica de alta intensidade detectada por sensoriamento orbital, com pluma de fumaça se deslocando para áreas povoadas.",
      severity: 3, magnitude: null, latitude: -7.9, longitude: -63.1, locationName: "Humaitá, AM — Brasil",
      eventTime: new Date(now - 51 * 60000), leadMinutes: 55, metadata: { sensor: "SAT-VIIRS" },
    },
    {
      externalId: "vigia-sensor-mg-1", source: "Rede de Sensores VIGIA", type: "deslizamento",
      title: "Risco alto de deslizamento — região serrana de Minas Gerais",
      description: "Solo saturado após 180 mm de chuva em 24h. Encostas monitoradas apresentam deslocamento acima do normal.",
      severity: 3, magnitude: 180, latitude: -20.3, longitude: -43.9, locationName: "Ouro Preto, MG — Brasil",
      eventTime: new Date(now - 95 * 60000), leadMinutes: 41, metadata: { sensor: "GEO-MG-077" },
    },
  ];
  for (const s of samples) {
    await db.insert(alerts).values(s).onConflictDoNothing({ target: alerts.externalId });
  }
  return samples.length;
}

/* ----------------------------- Simulação ----------------------------- */

const SIM_SCENARIOS = [
  { type: "enchente", city: "Porto Alegre", state: "RS", latitude: -30.0346, longitude: -51.2177, title: "Enchente relâmpago — rio acima da cota de alerta", description: "Sensores fluviais detectaram elevação crítica do nível do rio. Áreas ribeirinhas devem ser evacuadas preventivamente.", severity: 4 },
  { type: "tempestade", city: "São Paulo", state: "SP", latitude: -23.5505, longitude: -46.6333, title: "Supercélula de tempestade com granizo e rajadas de 110 km/h", description: "Tempestade severa em aproximação rápida. Risco de destelhamentos, queda de árvores e alagamentos.", severity: 4 },
  { type: "terremoto", city: "Rio Branco", state: "AC", latitude: -9.9754, longitude: -67.8249, title: "Terremoto M5.8 detectado na fronteira Brasil-Peru", description: "Abalo sísmico de magnitude 5.8 sentido em Rio Branco e Cruzeiro do Sul. Sem relatos de danos até o momento.", severity: 3 },
  { type: "incendio", city: "Cuiabá", state: "MT", latitude: -15.6014, longitude: -56.0979, title: "Incêndio florestal de grande proporção avançando para área urbana", description: "Frente de fogo com 4 km de extensão detectada por satélite. Qualidade do ar em nível perigoso.", severity: 3 },
  { type: "deslizamento", city: "Petrópolis", state: "RJ", latitude: -22.5113, longitude: -43.1776, title: "Deslizamento iminente — encosta monitorada em deslocamento", description: "Inclinômetros detectaram deslocamento acelerado de encosta após chuva intensa. Evacuação preventiva recomendada.", severity: 4 },
  { type: "ciclone", city: "Florianópolis", state: "SC", latitude: -27.5954, longitude: -48.548, title: "Ciclone extratropical em formação no litoral catarinense", description: "Ventos sustentados previstos de 90 km/h com maré de tempestade de até 2,1 m. Evite áreas costeiras.", severity: 3 },
];

export async function createSimulatedAlert() {
  const sc = SIM_SCENARIOS[Math.floor(Math.random() * SIM_SCENARIOS.length)];
  const [alert] = await db
    .insert(alerts)
    .values({
      externalId: `vigia-sim-${Date.now()}`,
      source: "Rede de Sensores VIGIA",
      type: sc.type,
      title: `${sc.title} — ${sc.city}, ${sc.state}`,
      description: sc.description,
      severity: sc.severity,
      magnitude: sc.type === "terremoto" ? 5.8 : null,
      latitude: sc.latitude + (Math.random() - 0.5) * 0.4,
      longitude: sc.longitude + (Math.random() - 0.5) * 0.4,
      locationName: `${sc.city}, ${sc.state} — Brasil`,
      eventTime: new Date(),
      leadMinutes: 30 + Math.round(Math.random() * 30),
      metadata: { simulated: true },
    })
    .returning();
  broadcast({ kind: "alert", data: alert });
  return { alert, reached: getConnectionCount() };
}

export async function latestAlerts(limit = 60) {
  return db.select().from(alerts).orderBy(desc(alerts.eventTime)).limit(limit);
}

/* ------------------------- Disparo do Admin ------------------------- */

export type AdminBroadcastInput = {
  type: string;
  severity: number;
  title: string;
  description: string;
  latitude: number;
  longitude: number;
  locationName: string;
  impactRadiusKm: number;
  publicBroadcast: boolean;
};

/**
 * DISPARO 100% SEM DADOS PESSOAIS.
 * O alerta é transmitido pelo canal público ao vivo para todos os visitantes
 * conectados. Nenhum nome, telefone, e-mail ou cadastro é pedido ou usado:
 * cada aparelho decide localmente (com a região salva só no navegador da
 * pessoa) se exibe o modal de emergência em tela cheia.
 * Registramos apenas números agregados: quantas conexões receberam e em
 * quantos milissegundos o disparo foi concluído.
 */
export async function createAdminBroadcast(input: AdminBroadcastInput) {
  const startedAtMs = Date.now();
  const reached = getConnectionCount();

  const [alert] = await db
    .insert(alerts)
    .values({
      externalId: `vigia-admin-${Date.now()}`,
      source: "Administração VIGIA",
      type: input.type,
      title: input.title,
      description: input.description,
      severity: input.severity,
      magnitude: null,
      latitude: input.latitude,
      longitude: input.longitude,
      locationName: input.locationName,
      eventTime: new Date(),
      leadMinutes: 60,
      metadata: {
        admin: true,
        publicBroadcast: input.publicBroadcast,
        impactRadiusKm: input.impactRadiusKm,
        issuedBy: "Administração VIGIA",
        reach: reached,
        dispatchMs: 0,
      },
    })
    .returning();

  const dispatchMs = Date.now() - startedAtMs;

  const [updated] = await db
    .update(alerts)
    .set({
      metadata: {
        admin: true,
        publicBroadcast: input.publicBroadcast,
        impactRadiusKm: input.impactRadiusKm,
        issuedBy: "Administração VIGIA",
        reach: reached,
        dispatchMs,
      },
    })
    .where(eq(alerts.id, alert.id))
    .returning();

  const finalAlert = updated ?? alert;
  broadcast({ kind: "alert", data: finalAlert });
  if (input.publicBroadcast) {
    // Canal público universal e anônimo: nenhum dado pessoal envolvido.
    broadcast({ kind: "public-alert", data: { alert: finalAlert, reached, dispatchMs, at: Date.now() } });
  }
  broadcast({ kind: "stats", data: { adminBroadcast: finalAlert.id } });

  return { alert: finalAlert, reached, connectedNow: reached, dispatchMs };
}

export async function deleteAlertById(id: number) {
  const deleted = await db.delete(alerts).where(eq(alerts.id, id)).returning({ id: alerts.id });
  if (deleted.length > 0) broadcast({ kind: "stats", data: { alertDeleted: id } });
  return deleted.length > 0;
}
