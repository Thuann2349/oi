export const SEVERITY = {
  1: { label: "Baixo", color: "#38bdf8", bg: "bg-sky-500", text: "text-sky-400", ring: "ring-sky-500/40" },
  2: { label: "Moderado", color: "#facc15", bg: "bg-yellow-400", text: "text-yellow-400", ring: "ring-yellow-400/40" },
  3: { label: "Alto", color: "#fb923c", bg: "bg-orange-400", text: "text-orange-400", ring: "ring-orange-400/40" },
  4: { label: "Extremo", color: "#ef4444", bg: "bg-red-500", text: "text-red-500", ring: "ring-red-500/40" },
} as const;

export type SeverityLevel = keyof typeof SEVERITY;

export function severityMeta(level: number) {
  return SEVERITY[Math.min(4, Math.max(1, level)) as SeverityLevel];
}

export const ALERT_TYPES: Record<string, { label: string }> = {
  terremoto: { label: "Terremoto" },
  tsunami: { label: "Tsunami" },
  vulcao: { label: "Vulcão" },
  incendio: { label: "Incêndio florestal" },
  tempestade: { label: "Tempestade severa" },
  enchente: { label: "Enchente" },
  deslizamento: { label: "Deslizamento" },
  ciclone: { label: "Ciclone" },
  seca: { label: "Seca" },
  neve: { label: "Neve / frio extremo" },
  calor: { label: "Onda de calor" },
  outro: { label: "Evento natural" },
};

export function typeLabel(type: string) {
  return ALERT_TYPES[type]?.label ?? "Evento natural";
}

export function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function timeAgoPt(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  const diffMs = Date.now() - d.getTime();
  const sec = Math.floor(diffMs / 1000);
  if (sec < 10) return "agora mesmo";
  if (sec < 60) return `há ${sec}s`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `há ${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `há ${h}h`;
  const days = Math.floor(h / 24);
  return `há ${days}d`;
}

export function formatDateTimePt(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}
