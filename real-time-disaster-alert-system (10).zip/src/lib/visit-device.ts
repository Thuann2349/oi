export type DeviceDetails = {
  deviceName: string;
  deviceType: "Celular" | "Tablet" | "Computador" | "Outro";
  browserName: string;
  browserVersion: string;
  osName: string;
  osVersion: string;
};

function version(ua: string, pattern: RegExp): string {
  return pattern.exec(ua)?.[1]?.replaceAll("_", ".") ?? "";
}

/** Extrai apenas características gerais do User-Agent; nunca persiste o texto bruto. */
export function parseVisitDevice(ua: string): DeviceDetails {
  const s = ua.slice(0, 1200);
  let browserName = "Outro navegador";
  let browserVersion = "";
  const browserRules: Array<[RegExp, string, RegExp]> = [
    [/SamsungBrowser\//, "Samsung Internet", /SamsungBrowser\/([\d.]+)/],
    [/EdgA?\//, "Microsoft Edge", /EdgA?\/([\d.]+)/],
    [/OPR\//, "Opera", /OPR\/([\d.]+)/],
    [/CriOS\//, "Chrome (iOS)", /CriOS\/([\d.]+)/],
    [/FxiOS\//, "Firefox (iOS)", /FxiOS\/([\d.]+)/],
    [/Firefox\//, "Firefox", /Firefox\/([\d.]+)/],
    [/Chrome\//, "Chrome", /Chrome\/([\d.]+)/],
    [/Version\/.*Safari\//, "Safari", /Version\/([\d.]+)/],
  ];
  for (const [match, name, re] of browserRules) {
    if (match.test(s)) {
      browserName = name;
      browserVersion = version(s, re);
      break;
    }
  }

  let osName = "Outro sistema";
  let osVersion = "";
  if (/iPhone|iPad|iPod/i.test(s)) {
    osName = "iOS";
    osVersion = version(s, /OS ([\d_]+)/);
  } else if (/Android/i.test(s)) {
    osName = "Android";
    osVersion = version(s, /Android ([\d.]+)/);
  } else if (/Windows NT 10\.0/i.test(s)) {
    osName = "Windows";
    osVersion = "10/11";
  } else if (/Windows NT 6\.3/i.test(s)) {
    osName = "Windows";
    osVersion = "8.1";
  } else if (/Windows NT 6\.1/i.test(s)) {
    osName = "Windows";
    osVersion = "7";
  } else if (/Mac OS X/i.test(s)) {
    osName = "macOS";
    osVersion = version(s, /Mac OS X ([\d_]+)/);
  } else if (/CrOS/i.test(s)) {
    osName = "ChromeOS";
    osVersion = version(s, /CrOS [^ ]+ ([\d.]+)/);
  } else if (/Linux/i.test(s)) {
    osName = "Linux";
  }

  let deviceType: DeviceDetails["deviceType"] = "Computador";
  let deviceName = "Computador";
  if (/iPad|Tablet/i.test(s)) {
    deviceType = "Tablet";
    deviceName = /iPad/i.test(s) ? "iPad" : "Tablet";
  } else if (/iPhone/i.test(s)) {
    deviceType = "Celular";
    deviceName = "iPhone";
  } else if (/Android/i.test(s)) {
    deviceType = "Celular";
    const model = /Android[^;)]*;\s*([^;)]+?)(?:\s+Build\/|\))/i.exec(s)?.[1]?.trim();
    deviceName = model && model.length > 1 && model.length < 80 && !/^wv$/i.test(model)
      ? model.replace(/^SM-/, "Samsung SM-")
      : "Android";
  } else if (/Windows Phone/i.test(s)) {
    deviceType = "Celular";
    deviceName = "Windows Phone";
  }

  return { deviceName, deviceType, browserName, browserVersion, osName, osVersion };
}
