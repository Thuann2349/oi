/* ------------------------------------------------------------------ */
/*  Biblioteca meteorológica: 5 modelos determinísticos (ECMWF, GFS,   */
/*  ICON, JMA, GEM) + 4 ensembles (143 cenários). O índice de certeza */
/*  é a concordância medida entre todos eles, hora a hora.            */
/* ------------------------------------------------------------------ */

export const WMO: Record<number, string> = {
  0: "Céu limpo", 1: "Quase limpo", 2: "Parcialmente nublado", 3: "Nublado",
  45: "Nevoeiro", 48: "Nevoeiro com geada", 51: "Garoa leve", 53: "Garoa", 55: "Garoa forte",
  61: "Chuva fraca", 63: "Chuva moderada", 65: "Chuva forte", 66: "Chuva congelante", 67: "Chuva congelante forte",
  71: "Neve fraca", 73: "Neve moderada", 75: "Neve forte", 77: "Granizo fino",
  80: "Pancadas fracas", 81: "Pancadas moderadas", 82: "Pancadas violentas",
  85: "Pancadas de neve", 86: "Pancadas de neve forte",
  95: "Tempestade", 96: "Tempestade com granizo", 99: "Tempestade com granizo forte",
};

/** Modelos determinísticos (dados hora a hora). */
export const MODELS = ["ecmwf_ifs025", "gfs_seamless", "icon_seamless", "jma_seamless", "gem_seamless"] as const;

export const MODEL_LABELS: Record<string, string> = {
  ecmwf_ifs025: "ECMWF",
  gfs_seamless: "GFS",
  icon_seamless: "ICON",
  jma_seamless: "JMA",
  gem_seamless: "GEM",
  best: "Automático",
};

export async function fetchJsonSafe(url: string, timeoutMs = 12000): Promise<any | null> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: ctrl.signal, cache: "no-store" });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
const avg = (arr: number[]) => arr.reduce((a, b) => a + b, 0) / Math.max(1, arr.length);

/* ------------------------------ Ensemble ------------------------------ */

export type EnsembleData = {
  times: string[];
  tempMembers: number[][];
  precipMembers: number[][];
  memberCount: number;
};

export function parseEnsemble(data: any): EnsembleData | null {
  const hourly = data?.hourly;
  if (!hourly?.time || !Array.isArray(hourly.time)) return null;
  const collect = (prefix: string): number[][] => {
    const out: number[][] = [];
    for (const key of Object.keys(hourly)) {
      if (key === prefix || key.startsWith(`${prefix}_member`)) {
        const arr = hourly[key];
        if (Array.isArray(arr)) out.push(arr.map((v: unknown) => (typeof v === "number" ? v : NaN)));
      }
    }
    return out;
  };
  const tempMembers = collect("temperature_2m");
  const precipMembers = collect("precipitation");
  if (tempMembers.length < 3) return null;
  return { times: hourly.time as string[], tempMembers, precipMembers, memberCount: tempMembers.length };
}

/** Junta vários ensembles (de modelos diferentes) num único conjunto de cenários. */
export function mergeEnsembles(list: EnsembleData[]): EnsembleData | null {
  if (!list.length) return null;
  const n = Math.min(...list.map((e) => e.times.length));
  const tempMembers: number[][] = [];
  const precipMembers: number[][] = [];
  for (const e of list) {
    for (const m of e.tempMembers) tempMembers.push(m.slice(0, n));
    for (const m of e.precipMembers) precipMembers.push(m.slice(0, n));
  }
  return { times: list[0].times.slice(0, n), tempMembers, precipMembers, memberCount: tempMembers.length };
}

/** Para cada horário alvo, devolve o índice correspondente na série de origem (-1 se não existir). */
export function alignIndex(src: string[], target: string[]): number[] {
  const map = new Map<string, number>();
  src.forEach((t, i) => map.set(t, i));
  return target.map((t) => map.get(t) ?? -1);
}

/** Estatísticas por hora do conjunto de cenários: dispersão de temperatura e % de cenários com chuva. */
export function hourlyEnsembleStats(ens: EnsembleData): { sd: (number | null)[]; wetPct: (number | null)[] } {
  const n = ens.times.length;
  const sd: (number | null)[] = [];
  const wetPct: (number | null)[] = [];
  for (let i = 0; i < n; i++) {
    const temps = ens.tempMembers.map((m) => m[i]).filter((v) => Number.isFinite(v));
    if (temps.length > 2) {
      const mu = avg(temps);
      sd.push(Math.sqrt(avg(temps.map((x) => (x - mu) ** 2))));
    } else {
      sd.push(null);
    }
    const pr = ens.precipMembers.map((m) => m[i]).filter((v) => Number.isFinite(v));
    wetPct.push(pr.length ? Math.round((100 * pr.filter((v) => v >= 0.1).length) / pr.length) : null);
  }
  return { sd, wetPct };
}

/** Amplitude (máx − mín) entre valores não nulos; null se houver menos de 2. */
export function spreadAt(values: Array<number | null | undefined>): number | null {
  const v = values.filter((x): x is number => typeof x === "number" && Number.isFinite(x));
  if (v.length < 2) return null;
  return Math.max(...v) - Math.min(...v);
}

/** Dispersão dos cenários: 0 °C → 100 % de concordância; 6 °C ou mais → 0 %. */
export function tempAgreementFromSd(sd: number): number {
  return clamp01(1 - sd / 6);
}

/** Amplitude entre os modelos: 0 °C → 100 %; 8 °C ou mais → 0 %. */
export function modelTempAgreement(spread: number): number {
  return clamp01(1 - spread / 8);
}

/**
 * Consenso de chuva na escala 0..1:
 * 0 = cenários divididos 50/50 (ninguém sabe se chove), 1 = todos concordam.
 */
export function rainConsensusFromPct(pct: number): number {
  const p = clamp01(pct / 100);
  return clamp01((Math.max(p, 1 - p) - 0.5) * 2);
}

/* -------------- Funções já usadas pela previsão do mapa -------------- */

export function ensembleAgreement(ens: EnsembleData, hours = 48) {
  const n = Math.min(hours, ens.times.length);
  let tSum = 0, tCount = 0, rSum = 0;
  for (let i = 0; i < n; i++) {
    const temps = ens.tempMembers.map((m) => m[i]).filter((v) => Number.isFinite(v));
    if (temps.length > 1) {
      const mean = avg(temps);
      const sd = Math.sqrt(avg(temps.map((t) => (t - mean) ** 2)));
      tSum += clamp01(1 - sd / 5);
      tCount++;
    }
    if (ens.precipMembers.length) {
      const wet = ens.precipMembers.filter((m) => (m[i] ?? 0) >= 0.1).length / ens.precipMembers.length;
      rSum += Math.max(wet, 1 - wet);
    }
  }
  return {
    tempAgreement: tCount ? tSum / tCount : null,
    rainConsensus: ens.precipMembers.length && n ? rSum / n : null,
  };
}

export function rainChanceNextHours(ens: EnsembleData, hours = 24): number | null {
  if (!ens.precipMembers.length) return null;
  const n = Math.min(hours, ens.times.length);
  if (!n) return null;
  let sum = 0;
  for (let i = 0; i < n; i++) {
    sum += ens.precipMembers.filter((m) => (m[i] ?? 0) >= 0.1).length / ens.precipMembers.length;
  }
  return Math.round((sum / n) * 100);
}

export function dailyRainChance(ens: EnsembleData): Record<string, number> {
  const byDay = new Map<string, number[]>();
  ens.times.forEach((t, i) => {
    const day = t.slice(0, 10);
    if (!byDay.has(day)) byDay.set(day, new Array(ens.precipMembers.length).fill(0));
    const sums = byDay.get(day)!;
    ens.precipMembers.forEach((m, mi) => { sums[mi] += m[i] ?? 0; });
  });
  const out: Record<string, number> = {};
  for (const [day, sums] of byDay) {
    const wet = sums.filter((s) => s >= 0.3).length;
    out[day] = Math.round((wet / Math.max(1, sums.length)) * 100);
  }
  return out;
}

export function dailyRainConsensus(ens: EnsembleData): Record<string, number> {
  const chances = dailyRainChance(ens);
  const out: Record<string, number> = {};
  for (const [day, pct] of Object.entries(chances)) {
    const p = pct / 100;
    out[day] = Math.max(p, 1 - p);
  }
  return out;
}

export function dailyEnsembleTempAgreement(ens: EnsembleData): Record<string, number> {
  const byDay = new Map<string, number[]>();
  ens.times.forEach((t, i) => {
    const temps = ens.tempMembers.map((m) => m[i]).filter((v) => Number.isFinite(v));
    if (temps.length < 3) return;
    const mean = avg(temps);
    const sd = Math.sqrt(avg(temps.map((x) => (x - mean) ** 2)));
    const day = t.slice(0, 10);
    const arr = byDay.get(day) ?? [];
    arr.push(clamp01(1 - sd / 5));
    byDay.set(day, arr);
  });
  const out: Record<string, number> = {};
  for (const [day, arr] of byDay) out[day] = avg(arr);
  return out;
}

export type ModelDailySeries = Record<string, { max: (number | null)[]; min: (number | null)[]; rain: (number | null)[] }>;

export function parseDailyByModel(daily: any): ModelDailySeries {
  const result: ModelDailySeries = {};
  if (!daily) return result;
  const grab = (varName: string, field: "max" | "min" | "rain") => {
    for (const key of Object.keys(daily)) {
      if (key === varName || key.startsWith(`${varName}_`)) {
        const model = key === varName ? "best" : key.slice(varName.length + 1);
        result[model] ??= { max: [], min: [], rain: [] };
        result[model][field] = (daily[key] as unknown[]).map((v) => (typeof v === "number" ? v : null));
      }
    }
  };
  grab("temperature_2m_max", "max");
  grab("temperature_2m_min", "min");
  grab("precipitation_sum", "rain");
  return result;
}

export function modelAgreementByDay(byModel: ModelDailySeries, days = 7): (number | null)[] {
  const models = Object.values(byModel);
  const out: (number | null)[] = [];
  for (let d = 0; d < days; d++) {
    const parts: number[] = [];
    const maxes = models.map((m) => m.max[d]).filter((v): v is number => typeof v === "number");
    if (maxes.length > 1) parts.push(clamp01(1 - (Math.max(...maxes) - Math.min(...maxes)) / 7));
    const mins = models.map((m) => m.min[d]).filter((v): v is number => typeof v === "number");
    if (mins.length > 1) parts.push(clamp01(1 - (Math.max(...mins) - Math.min(...mins)) / 7));
    const rains = models.map((m) => m.rain[d]).filter((v): v is number => typeof v === "number");
    if (rains.length > 1) {
      const spread = Math.max(...rains) - Math.min(...rains);
      parts.push(clamp01(1 - spread / (avg(rains) + 6)));
    }
    out.push(parts.length ? avg(parts) : null);
  }
  return out;
}

export function modelAgreementOverall(byModel: ModelDailySeries, days = 5): number | null {
  const perDay = modelAgreementByDay(byModel, days).filter((v): v is number => v != null);
  return perDay.length ? avg(perDay) : null;
}

/** Índice de certeza final (55–99). 99 é o máximo: nunca 100, pois previsão não tem certeza absoluta. */
export function combinedConfidence(parts: {
  ensembleTemp?: number | null;
  rainConsensus?: number | null;
  model?: number | null;
}): number | null {
  let w = 0, s = 0;
  const add = (v: number | null | undefined, weight: number) => {
    if (v != null && Number.isFinite(v)) { s += v * weight; w += weight; }
  };
  add(parts.ensembleTemp, 0.45);
  add(parts.rainConsensus, 0.2);
  add(parts.model, 0.35);
  if (!w) return null;
  return Math.max(35, Math.min(99, Math.round(100 * (s / w))));
}

export function confidenceLabel(conf: number | null): string {
  if (conf == null) return "indisponível";
  if (conf >= 92) return "Altíssima";
  if (conf >= 85) return "Alta";
  if (conf >= 75) return "Boa";
  if (conf >= 65) return "Moderada";
  return "Baixa";
}
