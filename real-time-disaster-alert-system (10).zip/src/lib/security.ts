import { NextResponse } from "next/server";

/* ------------------------------------------------------------------ */
/*  Blindagem: rate limiting, anti força-bruta, origem, validações.    */
/*  Tudo em memória (por processo) — sem coletar dados pessoais.       */
/* ------------------------------------------------------------------ */

type Bucket = { count: number; resetAt: number };
type FailRec = { fails: number; windowStart: number; lockedUntil: number };

type SecGlobal = typeof globalThis & {
  __vigiaRate?: Map<string, Bucket>;
  __vigiaLoginFails?: Map<string, FailRec>;
};

const g = globalThis as SecGlobal;
const rateMap: Map<string, Bucket> = (g.__vigiaRate ??= new Map());
const failMap: Map<string, FailRec> = (g.__vigiaLoginFails ??= new Map());

function prune(map: Map<string, { resetAt?: number; lockedUntil?: number; windowStart?: number }>) {
  if (map.size < 5000) return;
  const now = Date.now();
  for (const [k, v] of map) {
    const exp = Math.max(v.resetAt ?? 0, v.lockedUntil ?? 0, (v.windowStart ?? 0) + 3600_000);
    if (exp < now) map.delete(k);
  }
}

/** IP do cliente atrás do proxy; analytics só o persiste após consentimento explícito. */
export function clientIp(req: Request): string {
  const xff = req.headers.get("x-forwarded-for");
  if (xff) return xff.split(",")[0].trim().slice(0, 64);
  return (req.headers.get("x-real-ip") ?? "local").slice(0, 64);
}

/** Retorna true se a requisição está dentro do limite. */
export function rateLimit(scope: string, limit: number, windowMs: number): boolean {
  prune(rateMap as Map<string, { resetAt?: number }>);
  const now = Date.now();
  const b = rateMap.get(scope);
  if (!b || b.resetAt <= now) {
    rateMap.set(scope, { count: 1, resetAt: now + windowMs });
    return true;
  }
  if (b.count >= limit) return false;
  b.count++;
  return true;
}

/** Atalho: devolve a resposta 429 se excedeu, ou null se pode seguir. */
export function rateLimited(req: Request, scope: string, limit: number, windowMs = 60_000): NextResponse | null {
  const ip = clientIp(req);
  if (rateLimit(`${scope}:${ip}`, limit, windowMs)) return null;
  return NextResponse.json(
    { error: "Muitas requisições. Aguarde alguns segundos e tente novamente." },
    { status: 429, headers: { "Retry-After": "30" } },
  );
}

/* --------------------- Anti força-bruta do login --------------------- */

const LOGIN_MAX_FAILS = 6;
const LOGIN_WINDOW_MS = 10 * 60 * 1000;
const LOGIN_LOCK_MS = 10 * 60 * 1000;

/** Segundos restantes de bloqueio (0 = liberado). */
export function loginLockSeconds(ip: string): number {
  // Bloqueio global: protege contra botnets que trocam de IP a cada tentativa.
  const global = failMap.get(GLOBAL_LOGIN_KEY);
  const globalLeft = global ? Math.ceil((global.lockedUntil - Date.now()) / 1000) : 0;
  if (globalLeft > 0) return globalLeft;
  const rec = failMap.get(ip);
  if (!rec) return 0;
  const remaining = Math.ceil((rec.lockedUntil - Date.now()) / 1000);
  return remaining > 0 ? remaining : 0;
}

const GLOBAL_LOGIN_KEY = "__global_login__";
const GLOBAL_LOGIN_MAX_FAILS = 40;

function bumpFailure(key: string, maxFails: number) {
  const now = Date.now();
  const rec = failMap.get(key);
  if (!rec || now - rec.windowStart > LOGIN_WINDOW_MS) {
    failMap.set(key, { fails: 1, windowStart: now, lockedUntil: 0 });
    return;
  }
  rec.fails++;
  if (rec.fails >= maxFails) {
    rec.lockedUntil = now + LOGIN_LOCK_MS;
    rec.fails = 0;
    rec.windowStart = now;
  }
}

export function recordLoginFailure(ip: string): void {
  prune(failMap as Map<string, { lockedUntil?: number; windowStart?: number }>);
  bumpFailure(GLOBAL_LOGIN_KEY, GLOBAL_LOGIN_MAX_FAILS);
  const now = Date.now();
  const rec = failMap.get(ip);
  if (!rec || now - rec.windowStart > LOGIN_WINDOW_MS) {
    failMap.set(ip, { fails: 1, windowStart: now, lockedUntil: 0 });
    return;
  }
  rec.fails++;
  if (rec.fails >= LOGIN_MAX_FAILS) {
    rec.lockedUntil = now + LOGIN_LOCK_MS;
    rec.fails = 0;
    rec.windowStart = now;
  }
}

export function clearLoginFailures(ip: string): void {
  failMap.delete(ip);
}

/* --------------------------- CSRF / origem --------------------------- */

/** Se houver header Origin, ele precisa ser do próprio site. */
export function sameOriginOk(req: Request): boolean {
  const origin = req.headers.get("origin");
  if (!origin) return true;
  const host = req.headers.get("host");
  if (!host) return false;
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

export function originGuard(req: Request): NextResponse | null {
  if (sameOriginOk(req)) return null;
  return NextResponse.json({ error: "Origem não permitida." }, { status: 403 });
}

/** Corpo JSON grande demais (proteção anti-abuso). */
export function bodyTooLarge(req: Request, maxBytes = 32768): boolean {
  const len = Number(req.headers.get("content-length") ?? 0);
  return Number.isFinite(len) && len > maxBytes;
}

/* ---------------------------- Validações ---------------------------- */

/** lat/lon presentes, válidos e dentro do planeta, ou null. */
export function parseLatLon(searchParams: URLSearchParams): { lat: number; lon: number } | null {
  const rawLat = searchParams.get("lat");
  const rawLon = searchParams.get("lon");
  if (rawLat == null || rawLon == null || rawLat.trim() === "" || rawLon.trim() === "") return null;
  const lat = Number(rawLat);
  const lon = Number(rawLon);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
  if (lat < -90 || lat > 90 || lon < -180 || lon > 180) return null;
  return { lat, lon };
}

export function clampInt(value: unknown, min: number, max: number, fallback: number): number {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.round(n)));
}

/** Escapa HTML para contextos onde o Leaflet injeta HTML (tooltips). */
export function escapeHtml(s: string): string {
  return s
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}
