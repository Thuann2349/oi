import { lt } from "drizzle-orm";
import { db } from "@/db";
import { siteVisits } from "@/db/schema";

export const SITE_VISIT_RETENTION_DAYS = 30;
const CLEANUP_INTERVAL_MS = 6 * 60 * 60 * 1000;
type CleanupGlobal = typeof globalThis & { __vigiaVisitsCleanupAt?: number };

/** Retenção por data, sem guardar o user-agent bruto. */
export async function cleanupExpiredSiteVisits(force = false): Promise<number> {
  const g = globalThis as CleanupGlobal;
  const now = Date.now();
  if (!force && g.__vigiaVisitsCleanupAt && now - g.__vigiaVisitsCleanupAt < CLEANUP_INTERVAL_MS) return 0;
  g.__vigiaVisitsCleanupAt = now;
  const cutoff = new Date(now - SITE_VISIT_RETENTION_DAYS * 24 * 60 * 60 * 1000);
  const deleted = await db.delete(siteVisits).where(lt(siteVisits.createdAt, cutoff)).returning({ id: siteVisits.id });
  return deleted.length;
}
