import { EventEmitter } from "events";

export type StreamEvent =
  | { kind: "alert"; data: unknown }
  | { kind: "public-alert"; data: unknown }
  | { kind: "notification"; data: unknown }
  | { kind: "stats"; data: unknown }
  | { kind: "heartbeat"; data: { at: number } };

type GlobalWithEmitter = typeof globalThis & {
  __vigiaEmitter?: EventEmitter;
  __vigiaConnections?: number;
  __vigiaIngestState?: {
    lastRunAt: string | null;
    lastNewAlerts: number;
    sources: Record<string, { ok: boolean; at: string | null; count: number }>;
    running: boolean;
  };
};

const g = globalThis as GlobalWithEmitter;

if (!g.__vigiaEmitter) {
  g.__vigiaEmitter = new EventEmitter();
  g.__vigiaEmitter.setMaxListeners(200);
}

export const emitter: EventEmitter = g.__vigiaEmitter;

export function broadcast(event: StreamEvent) {
  emitter.emit("vigia", event);
}

/* ----- Conexões ao vivo com teto por IP e teto global (anti-exaustão) ----- */

const MAX_CONNECTIONS_PER_IP = 6;
const MAX_CONNECTIONS_GLOBAL = 1500;

type ConnGlobal = typeof globalThis & { __vigiaConnByIp?: Map<string, number> };

function connMap(): Map<string, number> {
  const gg = globalThis as ConnGlobal;
  if (!gg.__vigiaConnByIp) gg.__vigiaConnByIp = new Map();
  return gg.__vigiaConnByIp;
}

/** Tenta registrar uma conexão SSE. Retorna false se excedeu o teto. */
export function tryAcquireConnection(ip: string): boolean {
  if ((g.__vigiaConnections ?? 0) >= MAX_CONNECTIONS_GLOBAL) return false;
  const map = connMap();
  const current = map.get(ip) ?? 0;
  if (current >= MAX_CONNECTIONS_PER_IP) return false;
  map.set(ip, current + 1);
  g.__vigiaConnections = (g.__vigiaConnections ?? 0) + 1;
  return true;
}

export function releaseConnection(ip: string) {
  const map = connMap();
  const current = map.get(ip) ?? 0;
  if (current <= 1) map.delete(ip);
  else map.set(ip, current - 1);
  g.__vigiaConnections = Math.max(0, (g.__vigiaConnections ?? 0) - 1);
}

export function getConnectionCount() {
  return g.__vigiaConnections ?? 0;
}

export function getIngestState() {
  if (!g.__vigiaIngestState) {
    g.__vigiaIngestState = {
      lastRunAt: null,
      lastNewAlerts: 0,
      sources: {},
      running: false,
    };
  }
  return g.__vigiaIngestState;
}
