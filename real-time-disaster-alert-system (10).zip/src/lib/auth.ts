import { createHash, randomBytes, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";

export const ADMIN_COOKIE = "vigia_admin";

type AuthGlobal = typeof globalThis & { __vigiaEphemeralKey?: string };

/**
 * Chave de acesso do painel admin.
 * - Produção: definida pela variável ADMIN_KEY no servidor (nunca um padrão público).
 * - Se ADMIN_KEY não existir em produção, gera uma chave aleatória por boot e
 *   imprime no log do servidor — jamais usa valor conhecido.
 * - Desenvolvimento local: vigia2024.
 */
export function adminKey(): string {
  const fromEnv = process.env.ADMIN_KEY;
  if (fromEnv && fromEnv.trim().length >= 8) return fromEnv.trim();
  if (process.env.NODE_ENV !== "production") return "vigia2024";
  const g = globalThis as AuthGlobal;
  if (!g.__vigiaEphemeralKey) {
    g.__vigiaEphemeralKey = randomBytes(16).toString("hex");
    console.warn(
      "[VIGIA] ADMIN_KEY não definida no ambiente. Chave de admin gerada para este boot:",
      g.__vigiaEphemeralKey,
    );
  }
  return g.__vigiaEphemeralKey;
}

export function adminToken(): string {
  return createHash("sha256").update(`vigia-admin:${adminKey()}`).digest("hex");
}

/** Comparação em tempo constante (anti timing attack). */
export function isValidKey(key: string): boolean {
  if (!key || key.length > 200) return false;
  const a = createHash("sha256").update(key).digest();
  const b = createHash("sha256").update(adminKey()).digest();
  return timingSafeEqual(a, b);
}

export async function isAdmin(): Promise<boolean> {
  const store = await cookies();
  const value = store.get(ADMIN_COOKIE)?.value ?? "";
  const expected = adminToken();
  if (value.length !== expected.length) return false;
  try {
    return timingSafeEqual(Buffer.from(value), Buffer.from(expected));
  } catch {
    return false;
  }
}
